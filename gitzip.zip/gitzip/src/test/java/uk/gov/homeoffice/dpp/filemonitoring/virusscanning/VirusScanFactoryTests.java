package uk.gov.homeoffice.dpp.filemonitoring.virusscanning;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.filemonitoring.FTPTestBuilder;
import uk.gov.homeoffice.dpp.filemonitoring.steps.StepSpecification;
import uk.gov.homeoffice.dpp.filemonitoring.virusscanning.UnixVirusScan;
import uk.gov.homeoffice.dpp.filemonitoring.virusscanning.VirusScan;
import uk.gov.homeoffice.dpp.filemonitoring.virusscanning.VirusScanFactory;
import uk.gov.homeoffice.dpp.filemonitoring.virusscanning.WindowsVirusScan;

/**
 * Created by C.Barnes on 13/04/2017.
 */
public class VirusScanFactoryTests extends FTPTestBuilder {

    @Test
    public void GetWindowsVirusScannerTest()
    {
        VirusScanFactory vsFact = new VirusScanFactory("Windows");

        StepSpecification stepDef =  createDefaultVirusScanningStepSpec("Windows");
        VirusScan result = vsFact.getVirusScanner(stepDef);

        if(result == null)
            Assert.fail("Did not get the expected VirusScanner. Expected: WindowsVirusScan Found: Null");

        Assert.assertEquals("Did not get the expected VirusScanner", WindowsVirusScan.class, result.getClass());
    }

    @Test
    public void GetUnixVirusScannerTest()
    {
        VirusScanFactory vsFact = new VirusScanFactory("Unix");

        StepSpecification stepDef =  createDefaultVirusScanningStepSpec("Unix");
        VirusScan result = vsFact.getVirusScanner(stepDef);

        if(result == null)
            Assert.fail("Did not get the expected VirusScanner. Expected: UnixVirusScan Found: Null");

        Assert.assertEquals("Did not get the expected VirusScanner", UnixVirusScan.class, result.getClass());
    }

    @Test
    public void GetNullVirusScannerTest()
    {
        VirusScanFactory vsFact = new VirusScanFactory(null);

        StepSpecification stepDef =  createDefaultVirusScanningStepSpec("Windows");
        VirusScan result = vsFact.getVirusScanner(stepDef);



        Assert.assertEquals("Did not get the expected VirusScanner", null, result);
    }

    @Test
    public void GetUnknownVirusScannerTest()
    {
        VirusScanFactory vsFact = new VirusScanFactory("Anything");

        StepSpecification stepDef =  createDefaultVirusScanningStepSpec("Anything");
        VirusScan result = vsFact.getVirusScanner(stepDef);



        Assert.assertEquals("Did not get the expected VirusScanner", null, result);
    }

}
