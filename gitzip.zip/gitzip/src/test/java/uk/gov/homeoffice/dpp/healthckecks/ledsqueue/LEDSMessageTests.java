package uk.gov.homeoffice.dpp.healthckecks.ledsqueue;

import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;
import uk.gov.homeoffice.dpp.healthchecks.ledsqueue.LEDSMessage;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPFile;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;

import java.util.Date;

/**
 * Created by C.Barnes on 18/05/2017.
 */
public class LEDSMessageTests {

    @Transactional
    @Test
    public void extractInfoIntoJSONTest()
    {
        Date received= new Date();
        DPPFile file = new DPPFile(received, new Date(), new Date(), "origFilePath", "currentFilePath", "SUCCESS", "filename", "12345", 100, "checksum", "999","3");

        JSONObject expJSONObj = new JSONObject();
        expJSONObj.put("GUID","12345");
        expJSONObj.put("OrigFileName", "filename");
        expJSONObj.put("ForceAgency", "999");
        expJSONObj.put("ReceivedDateTime", file.getReceived());
        expJSONObj.put("Priority", "3");
        expJSONObj.put("FileType", "");
        expJSONObj.put("ForceSystem", "");
        expJSONObj.put("MessageCount", "");
        expJSONObj.put("TransactionList", "");
        expJSONObj.put("Recipient", "");

        String expMessage = expJSONObj.toString();

        LEDSMessage message = new LEDSMessage(file);

        String result = message.extractInfoIntoJSON();

        Assert.assertEquals(expMessage, result);

    }

    @Transactional
    @Test
    public void extractInfoWithStatsIntoJSONTest()
    {
        Date received= new Date();
        DPPFile file = new DPPFile(received, new Date(), new Date(), "origFilePath", "currentFilePath", "SUCCESS", "filename", "12345", 100, "checksum", "999","3");
        UpdategramStats stats = new UpdategramStats(file.getId());
        stats.setBatchType("BatchType");
        stats.setMessages(5);
        stats.setTransactionList("TransactionList");
        stats.setRecipient("Recipient");


        JSONObject expJSONObj = new JSONObject();
        expJSONObj.put("GUID","12345");
        expJSONObj.put("OrigFileName", "filename");
        expJSONObj.put("ForceAgency", "999");
        expJSONObj.put("ReceivedDateTime", file.getReceived());
        expJSONObj.put("Priority", "3");
        expJSONObj.put("FileType", "BatchType");
        expJSONObj.put("ForceSystem", "");
        expJSONObj.put("MessageCount", 5);
        expJSONObj.put("TransactionList", "TransactionList");
        expJSONObj.put("Recipient", "Recipient");

        String expMessage = expJSONObj.toString();

        LEDSMessage message = new LEDSMessage(file, stats);

        String result = message.extractInfoIntoJSON();

        Assert.assertEquals(expMessage, result);
    }

}
