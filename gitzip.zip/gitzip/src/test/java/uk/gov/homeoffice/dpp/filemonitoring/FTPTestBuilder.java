package uk.gov.homeoffice.dpp.filemonitoring;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.gov.homeoffice.dpp.CentralTestConfiguration;
import uk.gov.homeoffice.dpp.TestConfigurations.TestFTPManagerConfiguration;
import uk.gov.homeoffice.dpp.YamlFileApplicationContextInitializer;
import uk.gov.homeoffice.dpp.filemonitoring.steps.StepSpecification;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

/**
 * Created by M.Koskinas on 02/03/2017.
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = CentralTestConfiguration.class, initializers = YamlFileApplicationContextInitializer.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@TestPropertySource(locations="classpath:testProperties.yml")
public abstract class FTPTestBuilder {

    @Value("${ftpManager.logging_config.log_directory}")
    private String logDir;

    @Value("${ftpManager.logging_config.log_name}")
    private String logName;

    //protected final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

    protected Path logFile;

    @Before
    public void setUp()
    {
        logFile = Paths.get(logDir + "//" + logName);

    }

    @After
    public void tearDown()
    {

    }

    public void areAllMetadataAttributesTheSame(FileMetadata file1, FileMetadata file2)
    {
        Assert.assertEquals(file1.getCurrentPath(), file2.getCurrentPath());
        Assert.assertEquals(file1.getGuid(), file2.getGuid());
        Assert.assertEquals(file1.getLandingDate(), file2.getLandingDate());
        Assert.assertEquals(file1.getOriginalFileName(), file2.getOriginalFileName());
        Assert.assertEquals(file1.getOriginalFilePath(), file2.getOriginalFilePath());
        Assert.assertEquals(file1.getOriginalFileSize(), file2.getOriginalFileSize());
        Assert.assertEquals(file1.getVSstart(), file2.getVSstart());
        Assert.assertEquals(file1.getVSfinish(), file2.getVSfinish());
    }

    public StepSpecification createDefaultVirusScanningStepSpec(String windowsOrUnix)
    {
        StepSpecification stepSpec = new StepSpecification();
        stepSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("quarantine_location", "/quarantine/location");
        properties.put("report_location", "/report/location");
        properties.put("Windows/Unix", windowsOrUnix);
        properties.put("virusscan_path", "virus/scan/path");
        properties.put("generate_xmlreport", "False");
        properties.put("generate_textreport", "False");
        stepSpec.setProperties(properties);

        return stepSpec;
    }
}
