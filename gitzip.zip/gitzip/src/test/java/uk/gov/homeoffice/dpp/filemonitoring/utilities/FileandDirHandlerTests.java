package uk.gov.homeoffice.dpp.filemonitoring.utilities;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FTPTestBuilder;
import uk.gov.homeoffice.dpp.filemonitoring.steps.UnTarStep;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by C.Barnes on 31/03/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {FTPManagerConfiguration.class})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class FileandDirHandlerTests extends FTPTestBuilder {

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Test
    public void CreateTemporaryFolderStructureWhenFoldersAlreadyExistTest() throws IOException {
        Path tmp = tempFolder.newFolder("Test").toPath();

        FTPManagerConfiguration.setTemp_storage(tmp.toString());

        tmp = tempFolder.newFolder("Test", "TempStorage").toPath();

        FTPManagerConfiguration.setTemp_storage_name(tmp.getFileName().toString());

        boolean result = FileandDirHandler.createTemporaryFolderStructure();

        Assert.assertTrue(result);

    }

    @Test
    public void CreateTemporaryFolderStructureTest() throws IOException {
        Path tmp = tempFolder.newFolder("Test").toPath();

        FTPManagerConfiguration.setTemp_storage(tmp.toString());

        FTPManagerConfiguration.setTemp_storage_name("TempStorage");

        boolean result = FileandDirHandler.createTemporaryFolderStructure();

        Assert.assertTrue(result);
        Assert.assertTrue(FTPManagerConfiguration.getTempStoragePath().toFile().exists());
    }

    @Test
    public void CreateTemporaryFolderStructureWhenItAlreadyExistsButItIsntADirTest() throws IOException {
        Path tmp = tempFolder.newFolder("Test").toPath();

        FTPManagerConfiguration.setTemp_storage(tmp.toString());

        tmp = tempFolder.newFile("Test/TempStorage.txt").toPath();

        FTPManagerConfiguration.setTemp_storage_name(tmp.getFileName().toString());

        boolean result = FileandDirHandler.createTemporaryFolderStructure();

        Assert.assertFalse(result);
    }

    @Test
    public void CreateTarTempFolderTest() throws IOException {
        Path tmp = tempFolder.newFolder("Test").toPath();

        FTPManagerConfiguration.setTemp_storage(tmp.toString());

        tmp = tempFolder.newFolder("Test", "TempStorage").toPath();

        FTPManagerConfiguration.setTemp_storage_name(tmp.getFileName().toString());

        boolean result = FileandDirHandler.createTarTempFolder();

        Assert.assertTrue(result);
        Assert.assertTrue(Paths.get(tmp.toString() + "/" + UnTarStep.TEMP_UNTAR_NAME).toFile().exists());
    }

    @Test
    public void CreateTarTempFolderWhenItAlreadyExistsTest() throws IOException {
        Path tmp = tempFolder.newFolder("Test").toPath();

        FTPManagerConfiguration.setTemp_storage(tmp.toString());

        tmp = tempFolder.newFolder("Test", "TempStorage").toPath();

        FTPManagerConfiguration.setTemp_storage_name(tmp.getFileName().toString());

        tmp = tempFolder.newFolder("Test", "TempStorage", UnTarStep.TEMP_UNTAR_NAME).toPath();



        boolean result = FileandDirHandler.createTarTempFolder();

        Assert.assertTrue(result);
        Assert.assertTrue(Paths.get(tempFolder.getRoot().getPath() + "/Test/TempStorage/" + UnTarStep.TEMP_UNTAR_NAME).toFile().exists());
    }

    @Test
    public void DeleteDirectoryAndAllContentsWhenNoFilesTest() throws IOException {
        tempFolder.newFolder("Test", "Layer1", "Layer2", "Layer3");
        tempFolder.newFolder("Test", "Layer1", "Layer2", "Layer31");

        Path dirToDelete = Paths.get(tempFolder.getRoot().getPath() + "/Test/Layer1/Layer2");

        boolean result = FileandDirHandler.deleteDirectoryAndAllContentsExceptFiles(dirToDelete);

        Assert.assertTrue(result);
        Assert.assertTrue(!dirToDelete.toFile().exists());
    }

    @Test
    public void DeleteDirectoryAndAllContentsWhenFilesExistWithin() throws IOException {
        tempFolder.newFolder("Test", "Layer1", "Layer2", "Layer3");
        tempFolder.newFolder("Test", "Layer1", "Layer2", "Layer31");
        tempFolder.newFolder("Test", "Layer1", "Layer2", "Layer32");
        Path file = tempFolder.newFile("Test/Layer1/Layer2/Layer32/NotToBeDeleted.txt").toPath();

        Path dirToDelete = Paths.get(tempFolder.getRoot().getPath() + "/Test/Layer1/Layer2");

        boolean result = FileandDirHandler.deleteDirectoryAndAllContentsExceptFiles(dirToDelete);

        Assert.assertFalse(result);
        Assert.assertTrue(file.toFile().exists());
        Assert.assertFalse(Paths.get(dirToDelete.toString() + "/Layer31").toFile().exists());
    }

    @Test
    public void DeleteFileTest() throws IOException {
        tempFolder.newFolder("Test");
        Path fileToDel = tempFolder.newFile("Test/Test.txt").toPath();

        boolean result = FileandDirHandler.deleteFile(fileToDel);

        Assert.assertTrue(result);
        Assert.assertFalse(fileToDel.toFile().exists());

    }

    @Test
    public void PassFolderIntoDeleteAFileTest() throws IOException {
        tempFolder.newFolder("Test");
        Path pathToDel = tempFolder.newFolder("Test", "ActuallyAFolder").toPath();

        boolean result = FileandDirHandler.deleteFile(pathToDel);

        Assert.assertFalse(result);
        Assert.assertTrue(pathToDel.toFile().exists());
    }



}
