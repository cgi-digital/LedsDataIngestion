package uk.gov.homeoffice.dpp.healthckecks;

import mockit.Expectations;
import mockit.Mocked;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.homeoffice.dpp.configuration.HealthChecksConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.healthchecks.HealthChecksPipeline;
import uk.gov.homeoffice.dpp.healthchecks.ledsqueue.LEDSQueue;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPFile;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;
import uk.gov.homeoffice.dpp.healthchecks.persistence.services.DPPFileService;

import java.io.File;
import java.util.List;

/**
 * Created by M.Koskinas on 02/03/2017.
 */
public class HealthChecksPipelineTest extends HCTestBuilder {

    @Autowired
    HealthChecksPipeline healthChecksPipeline;

    @Autowired
    DPPFileService fileService;

    private ClassLoader classLoader = getClass().getClassLoader();

    @Test
    public void createPipelineTest()
    {
        Assert.assertTrue(healthChecksPipeline.getSteps().size() == HealthChecksConfiguration.checks.size());
    }

    @Test
    public void runChecksFromPipelineTest(@Mocked LEDSQueue ledsQueue)
    {
        new Expectations(LEDSQueue.class)
        {
            {
                ledsQueue.send((DPPFile) any, (UpdategramStats) any);
            }
        };

        File file = new File(classLoader.getResource("XSDTestFiles/RecordBatch.xml").getFile());
        healthChecksPipeline.runHealthChecks(createMetadata(file.getName(),file.getAbsolutePath()));

        List<DPPFile> files = fileService.getFileByFilename("RecordBatch.xml");

        Assert.assertEquals(files.size(),1);
        Assert.assertTrue(files.get(0).getFilename().equals("RecordBatch.xml"));
        Assert.assertTrue(files.get(0).getStatus().equals("PROCESSED"));
    }



    @Test
    public void pipelineDeduplicationTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/AttachmentBatch.xml").getFile());
        healthChecksPipeline.runHealthChecks(createMetadata(file.getName(),file.getAbsolutePath()));

        healthChecksPipeline.runHealthChecks(createMetadata(file.getName(),file.getAbsolutePath()));

        List<DPPFile> files = fileService.getFileByFilename("AttachmentBatch.xml");

        Assert.assertEquals(files.size(),2);
        Assert.assertTrue(files.get(0).getFilename().equals("AttachmentBatch.xml"));
        Assert.assertFalse(files.get(0).getStatus().equals("DUPLICATE"));
        Assert.assertTrue(files.get(1).getFilename().equals("AttachmentBatch.xml"));
        Assert.assertTrue(files.get(1).getStatus().equals("DUPLICATE"));
    }

    @Test
    public void pipelineVirusTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/Virus.xml").getFile());

        FileMetadata metadata = createMetadata(file.getName(),file.getAbsolutePath());
        metadata.setState(FileMetadata.STATE_VIRUS);
        metadata.setErrorMessage(FileMetadata.VIRUS_MESSAGE);

        healthChecksPipeline.runHealthChecks(metadata);

        List<DPPFile> files = fileService.getFileByFilename("Virus.xml");
        Assert.assertEquals(files.size(),1);
        Assert.assertTrue(files.get(0).getStatus().equals("FAILED"));
    }
}
