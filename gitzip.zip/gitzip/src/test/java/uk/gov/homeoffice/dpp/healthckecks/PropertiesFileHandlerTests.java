//package uk.gov.homeoffice.dpp.healthckecks;
//
//import org.junit.Assert;
//import org.junit.Test;
//import uk.gov.homeoffice.dpp.healthchecks.properties.FileProperties;
//import uk.gov.homeoffice.dpp.healthchecks.properties.PropertiesFileHandler;
//
//import java.io.File;
//import java.io.IOException;
//
///**
// * Created by M.Koskinas on 12/04/2017.
// */
//public class PropertiesFileHandlerTests extends FITestBuilder {
//
//    private ClassLoader classLoader = getClass().getClassLoader();
//
//    @Test
//    public void getPropertiesTest() throws IOException {
//        FileProperties properties = PropertiesFileHandler.getProperties(new File(classLoader.getResource("XSDTestFiles/AttachmentBatch.xml.properties").getFile()));
//
//        Assert.assertTrue(properties.getOriginalFileLocation().equals("/home/force_id/AttachmentBatch.xml"));
//        Assert.assertTrue(properties.getFilename().equals("AttachmentBatch.xml"));
//        Assert.assertTrue(properties.getFileGUID().equals("5a613aa2-6d53-42b9-a14d-4b4b23dc5a94"));
//        Assert.assertTrue(properties.getForceID().equals("999"));
//        Assert.assertTrue(properties.getReceivedMachineName().equals("centos-dev-02.datalynx.local"));
//        Assert.assertTrue(properties.getReceivedMachineIP().equals("192.168.114.223"));
//        Assert.assertTrue(properties.getFileSize().equals("3041"));
//        Assert.assertTrue(properties.getFtpArrivalTime().equals("Tue Apr 25 14:11:02 BST 2017"));
//        Assert.assertTrue(properties.getVirusScannedStartTime().equals("Tue Apr 25 15:26:09 BST 2017"));
//        Assert.assertTrue(properties.getVirusScannedEndTime().equals("Tue Apr 25 15:26:12 BST 2017"));
//        Assert.assertTrue(properties.getState().equals("SUCCESSFUL"));
//        Assert.assertTrue(properties.getErrorMessage().equals("NONE"));
//
//    }
//
//    @Test
//    public void arePropertiesPopulatedTest() throws IOException {
//        FileProperties properties = PropertiesFileHandler.getProperties(new File(classLoader.getResource("XSDTestFiles/AttachmentBatch.xml.properties").getFile()));
//        Assert.assertTrue(PropertiesFileHandler.arePropertiesPopulated(properties));
//
//        properties = PropertiesFileHandler.getProperties(new File(classLoader.getResource("XSDTestFiles/AttachmentBatchError.properties").getFile()));
//        Assert.assertFalse(PropertiesFileHandler.arePropertiesPopulated(properties));
//    }
//}
