package uk.gov.homeoffice.dpp.filemonitoring;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Created by C.Barnes on 19/04/2017.
 */
public class FileMetadataTests extends FTPTestBuilder {

    @Test
    public void generatePropertyFileContentTest() throws UnknownHostException {
        Path curLoc = Paths.get("/current/location/test.txt");
        String forceID = "F999";
        String priorityLevel = "3";
        FileMetadata testfile = new FileMetadata(curLoc, forceID, "3");
        String origLoc = "original/location";
        UUID guid = UUID.randomUUID();
        String fileName = "TestName";
        InetAddress ipAddress = InetAddress.getByName("0.0.0.0");
        Date landingDate = new Date();
        Date vsStart = new Date();
        Date vsFinish = new Date();
        long fileSize = 200;

        testfile.setOriginalFilePath(origLoc);
        testfile.setGuid(guid);
        testfile.setOriginalFileName(fileName);
        testfile.setIpAddress(ipAddress);
        testfile.setLandingDate(landingDate);
        testfile.setVSstart(vsStart);
        testfile.setVSfinish(vsFinish);
        testfile.setOriginalFileSize(fileSize);
        testfile.setState(FileMetadata.STATE_SUCCESFUL);
        testfile.setErrorMessage(FileMetadata.SUCCESFUL_MESSAGE);

        List<String> result = testfile.generatePropertyFileContent();

        Assert.assertTrue("Different number of attributes in the properties file than expected", result.size() == 12);
        Assert.assertTrue("Did not contain the originalFileLocation attribute as expected.", result.contains("originalFileLocation: " + origLoc));
        Assert.assertTrue("Did not contain the FileName attribute as expected.", result.contains("filename: " + fileName));
        Assert.assertTrue("Did not contain the guid attribute as expected.", result.contains("fileguid: " + guid));
        Assert.assertTrue("Did not contain the forceID attribute as expected.", result.contains("forceID: " + forceID));
        Assert.assertTrue("Did not contain the priorityLevel attribute as expected.", result.contains("priorityLevel: " + priorityLevel));
        Assert.assertTrue("Did not contain the ipAddress attribute as expected.", result.contains("ReceivedMachineName/IP: " + ipAddress));
        Assert.assertTrue("Did not contain the fileSize attribute as expected.", result.contains("filesize: " + fileSize));
        Assert.assertTrue("Did not contain the landingTime attribute as expected.", result.contains("landedTime: " + landingDate));
        Assert.assertTrue("Did not contain the VSStart attribute as expected.", result.contains("VSStart: " + vsStart));
        Assert.assertTrue("Did not contain the VSFinish attribute as expected.", result.contains("VSFinish: " + vsFinish));
        Assert.assertTrue("Did not contain the State attribute as expected.", result.contains("State: SUCCESSFUL"));
        Assert.assertTrue("Did not contain the ErrorMessage attribute as expected.", result.contains("ErrorMessage: NONE"));



    }

    @Test
    public void generatePropertyFileContentWhenVirusTest() throws UnknownHostException {
        Path curLoc = Paths.get("/current/location/test.txt");
        String forceID = "F999";
        String priorityLevel = "3";
        FileMetadata testfile = new FileMetadata(curLoc, forceID, "3");
        String origLoc = "original/location";
        UUID guid = UUID.randomUUID();
        String fileName = "TestName";
        InetAddress ipAddress = InetAddress.getByName("0.0.0.0");
        Date landingDate = new Date();
        Date vsStart = new Date();
        Date vsFinish = new Date();
        long fileSize = 200;

        testfile.setOriginalFilePath(origLoc);
        testfile.setGuid(guid);
        testfile.setOriginalFileName(fileName);
        testfile.setIpAddress(ipAddress);
        testfile.setLandingDate(landingDate);
        testfile.setVSstart(vsStart);
        testfile.setVSfinish(vsFinish);
        testfile.setOriginalFileSize(fileSize);

        testfile.setState(FileMetadata.STATE_VIRUS);
        testfile.setErrorMessage(FileMetadata.VIRUS_MESSAGE);
        List<String> result = testfile.generatePropertyFileContent();

        Assert.assertTrue("Different number of attributes in the properties file than expected", result.size() == 12);
        Assert.assertTrue("Did not contain the originalFileLocation attribute as expected.", result.contains("originalFileLocation: " + origLoc));
        Assert.assertTrue("Did not contain the FileName attribute as expected.", result.contains("filename: " + fileName));
        Assert.assertTrue("Did not contain the guid attribute as expected.", result.contains("fileguid: " + guid));
        Assert.assertTrue("Did not contain the forceID attribute as expected.", result.contains("forceID: " + forceID));
        Assert.assertTrue("Did not contain the priorityLevel attribute as expected.", result.contains("priorityLevel: " + priorityLevel));
        Assert.assertTrue("Did not contain the ipAddress attribute as expected.", result.contains("ReceivedMachineName/IP: " + ipAddress));
        Assert.assertTrue("Did not contain the fileSize attribute as expected.", result.contains("filesize: " + fileSize));
        Assert.assertTrue("Did not contain the landingTime attribute as expected.", result.contains("landedTime: " + landingDate));
        Assert.assertTrue("Did not contain the VSStart attribute as expected.", result.contains("VSStart: " + vsStart));
        Assert.assertTrue("Did not contain the VSFinish attribute as expected.", result.contains("VSFinish: " + vsFinish));
        Assert.assertTrue("Did not contain the State attribute as expected.", result.contains("State: VIRUS"));
        Assert.assertTrue("Did not contain the ErrorMessage attribute as expected.", result.contains("ErrorMessage: File failed virus scanning"));



    }

}
