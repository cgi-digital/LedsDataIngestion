package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.healthchecks.checks.CategoryOneCheckResult;
import uk.gov.homeoffice.dpp.healthchecks.checks.UpdategramHandler;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;

import java.io.File;
import java.util.List;

/**
 * Created by M.Koskinas on 21/04/2017.
 */
public class GPMSListCheckTests extends HCTestBuilder
{

    private ClassLoader classLoader = getClass().getClassLoader();

    @Test
    public void runCheckTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/GPMSListCheckTests/RecordBatch.xml").getFile());
        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("centos-dev-02.datalynx.local/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_1000_020_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_1000_020_2".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_1000_020_3".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_1000_020_4".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/GPMSListCheckTests/RecordBatchInvalidGPMS3.xml").getFile());
        results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("centos-dev-02.datalynx.local"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_1000_020_4".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }
    }

    @Test
    public void GPMSListPopulatedNegativeTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/GPMSListCheckTests/RecordBatchInvalid1.xml").getFile());
        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("Centos-DEV-02/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++) {
            if ("C_ALL_1000_020_1".equals(results.get(r).getCheckName())) {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/GPMSListCheckTests/RecordBatchFAIL.xml").getFile());
        results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("centos-dev-02.datalynx.local/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++) {
            if ("C_ALL_1000_020_1".equals(results.get(r).getCheckName())) {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }
    }

    @Test
    public void GPMSListValidValueNegativeTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/GPMSListCheckTests/RecordBatchInvalid2.xml").getFile());
        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("centos-dev-02.datalynx.local/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++) {
            if ("C_ALL_1000_020_2".equals(results.get(r).getCheckName())) {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }
    }

    @Test
    public void GPMSListInvalidClassificationNegativeTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/GPMSListCheckTests/RecordBatchInvalid3.xml").getFile());
        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("centos-dev-02.datalynx.local/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++) {
            if ("C_ALL_1000_020_3".equals(results.get(r).getCheckName())) {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }
    }

    @Test
    public void GPMSListValueAgainstFTPSServerChannelNegativeTest() //validateGPMSListValueAgainstFTPSServerChannel
    {
        File file = new File(classLoader.getResource("XSDTestFiles/GPMSListCheckTests/RecordBatchInvalid4.xml").getFile());
        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("centos-dev-02.datalynx.local"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++) {
            if ("C_ALL_1000_020_4".equals(results.get(r).getCheckName())) {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }
    }


}
