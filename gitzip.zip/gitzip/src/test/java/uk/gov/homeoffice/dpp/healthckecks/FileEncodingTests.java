package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.healthchecks.checks.CategoryOneCheckResult;
import uk.gov.homeoffice.dpp.healthchecks.checks.UpdategramHandler;

import java.io.File;
import java.util.List;

/**
 * Created by M.Koskinas on 18/05/2017.
 */
public class FileEncodingTests extends HCTestBuilder
{
    private ClassLoader classLoader = getClass().getClassLoader();

    @Test
    public void validateFileEncodingTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/FileEncodingTests/RecordBatch.xml").getFile());
        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file);

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("HC-0012".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/FileEncodingTests/RecordBatchINVALID.xml").getFile());
        results = UpdategramHandler.executeChecks(file);

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("HC-0012".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/FileEncodingTests/RecordBatchMISSING.xml").getFile());
        results = UpdategramHandler.executeChecks(file);

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("HC-0011".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }

    }
}
