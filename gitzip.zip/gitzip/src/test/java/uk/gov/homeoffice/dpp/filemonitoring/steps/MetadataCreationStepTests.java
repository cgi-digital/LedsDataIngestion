package uk.gov.homeoffice.dpp.filemonitoring.steps;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FTPTestBuilder;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

/**
 * Created by C.Barnes on 22/03/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {FTPManagerConfiguration.class})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class MetadataCreationStepTests extends FTPTestBuilder {

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Test
    public void CreateMetadataForFileTest() throws IOException {
        File metaLoc = tempFolder.newFolder("Output").toPath()
                .resolve("test.txt")
                .toFile();

        tempFolder.newFile("Output/test.txt");

        FileMetadata fileMetadata = new FileMetadata(metaLoc.toPath(), "F999", "3");
        fileMetadata.setOriginalFilePath(metaLoc.getPath());
        fileMetadata.setGuid(UUID.randomUUID());

        StepSpecification mcSpec = new StepSpecification();
        mcSpec.setStatus(true);
        MetadataCreationStep metaCreate = new MetadataCreationStep(mcSpec);

        StepResult result = metaCreate.runStep(fileMetadata);
        StepResult expResult = new StepResult(true, null,
                fileMetadata);

        Assert.assertEquals(expResult.isSuccess(), result.isSuccess());
        Assert.assertEquals(expResult.getErrorCode(), result.getErrorCode());
        Assert.assertEquals(expResult.getCurrentFiles(), result.getCurrentFiles());
    }

    @Test
    @Ignore
    public void CheckMetadataFileExistsTest() throws IOException {
        File metaLoc = tempFolder.newFolder("Output").toPath()
                .resolve("test.txt")
                .toFile();

        tempFolder.newFile("Output/test.txt");

        FileMetadata fileMetadata = new FileMetadata(metaLoc.toPath(), "F999", "3");
        fileMetadata.setOriginalFilePath(metaLoc.getPath());
        fileMetadata.setGuid(UUID.randomUUID());

        StepSpecification mcSpec = new StepSpecification();
        mcSpec.setStatus(true);
        MetadataCreationStep metaCreate = new MetadataCreationStep(mcSpec);
        metaCreate.runStep(fileMetadata);

        Path expPropFile = Paths.get(metaLoc.getParent() + "/" + fileMetadata.getGuid().toString() + ".txt.properties");

        Assert.assertTrue(Files.exists(expPropFile));
    }

    @Test
    @Ignore
    public void MetadataCreationStepReturnsCorrectMetadataAttrTest() throws IOException {
        File metaLoc = tempFolder.newFolder("Output").toPath()
                .resolve("test.txt")
                .toFile();

        tempFolder.newFile("Output/test.txt");

        FileMetadata fileMetadata = new FileMetadata(metaLoc.toPath(), "F999", "3");
        UUID fileGuid = UUID.randomUUID();
        InetAddress ipaddress = InetAddress.getByName("0.0.0.0");
        fileMetadata.setOriginalFilePath(metaLoc.getPath());
        fileMetadata.setGuid(fileGuid);
        fileMetadata.setIpAddress(ipaddress);

        StepSpecification mcSpec = new StepSpecification();
        mcSpec.setStatus(true);
        MetadataCreationStep metaCreate = new MetadataCreationStep(mcSpec);

        metaCreate.runStep(fileMetadata);

        Path expCurrentPath = Paths.get(metaLoc.getParent() + "/" + fileMetadata.getGuid().toString() + ".txt");

        Assert.assertEquals(expCurrentPath, fileMetadata.getCurrentPath());
        Assert.assertEquals("test.txt", fileMetadata.getOriginalFileName());
        Assert.assertEquals(ipaddress, fileMetadata.getIpAddress());
        Assert.assertEquals(0, fileMetadata.getOriginalFileSize());
        Assert.assertEquals(fileGuid, fileMetadata.getGuid());
        Assert.assertEquals(null, fileMetadata.getLandingDate());
        Assert.assertEquals(metaLoc.getPath(), fileMetadata.getOriginalFilePath());
        Assert.assertEquals(null, fileMetadata.getVSstart());
        Assert.assertEquals(null, fileMetadata.getVSfinish());


    }

    @Test
    @Ignore //Is not checked properly in the code
    public void TryToCreateMetadataForNonExistantFileTest() {

    }

    @Test
    public void MetadataStepReturnsCorrectNameTest() {
        StepSpecification mcSpec = new StepSpecification();
        mcSpec.setStatus(true);
        MetadataCreationStep metaCreate = new MetadataCreationStep(mcSpec);

        Assert.assertEquals("metadata_creation", metaCreate.getName());
    }

}
