package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.healthchecks.checks.CategoryOneCheckResult;
import uk.gov.homeoffice.dpp.healthchecks.checks.UpdategramHandler;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;

import java.io.File;
import java.util.List;

/**
 * Created by M.Koskinas on 21/04/2017.
 */
public class RecordTypeListCheckTests extends HCTestBuilder
{

    private ClassLoader classLoader = getClass().getClassLoader();

    @Test
    public void runCheckTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/RecordTypeListCheckTests/RecordBatch.xml").getFile());
        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("Centos-DEV-02/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_0030_020_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_0030_020_2".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_1000_110_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/RecordTypeListCheckTests/RecordBatchOCGFlag.xml").getFile());
        results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("Centos-DEV-02/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_OCG_001".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_OCG_002".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_OCG_003".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_FLAG_001".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_FLAG_002".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_FLAG_003".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/RecordTypeListCheckTests/RecordBatchOCGInvalid.xml").getFile());
        results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("Centos-DEV-02/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_OCG_001".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
            else if("C_ALL_OCG_002".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
            else if("C_ALL_OCG_003".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/RecordTypeListCheckTests/RecordBatchFlagInvalid.xml").getFile());
        results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("Centos-DEV-02/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_FLAG_001".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
            else if("C_ALL_FLAG_002".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
            else if("C_ALL_FLAG_003".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/RecordTypeListCheckTests/AttachmentBatch.xml").getFile());
        results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("Centos-DEV-02/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_1000_110_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
        }


        file = new File(classLoader.getResource("XSDTestFiles/RecordTypeListCheckTests/RecordBatchInvalid2.xml").getFile());
        results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("Centos-DEV-02/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_0030_020_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
            else if("C_ALL_0030_020_2".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }


        file = new File(classLoader.getResource("XSDTestFiles/RecordTypeListCheckTests/RecordBatchInvalid3.xml").getFile());
        results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("Centos-DEV-02/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++) {
            if ("C_ALL_1000_110_1".equals(results.get(r).getCheckName())) {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }
    }

}
