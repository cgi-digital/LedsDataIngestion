package uk.gov.homeoffice.dpp.fileingest;

import mockit.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.springframework.context.ApplicationContext;
import uk.gov.homeoffice.dpp.configuration.FileIngestConfiguration;
import uk.gov.homeoffice.dpp.configuration.forces.ForceLandingLocation;
import uk.gov.homeoffice.dpp.configuration.priorities.PriorityProperties;
import uk.gov.homeoffice.dpp.filemonitoring.FTPManagerPipeline;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by C.Barnes on 17/07/2017.
 */
public class DirProcessorTests {

    @Injectable
    ApplicationContext appContext;

    @Tested
    DirProcessor dirProcessor;

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Before
    public void beforeDirProcessorTests()
    {
        FileIngestConfiguration.setMinFileAge(2);

        ForceLandingLocation fll = new ForceLandingLocation();
        fll.setPriority(3);
        fll.setLocation(tempFolder.getRoot().getAbsolutePath());
        PriorityProperties priority = new PriorityProperties();
        priority.setAutoCollect(true);
        priority.setFilesPerLoop(2);
        priority.setMaxFileAge(5);
        dirProcessor = new DirProcessor(fll, priority, "forceID");}

    @Test
    public void processDirectoryWhenFileTooNewTest() throws IOException {
        tempFolder.newFile("file1").setLastModified(new Date().getTime());


        boolean result = dirProcessor.processDirectory();

        Assert.assertFalse("Should not have picked up any files", result);
    }

    @Test
    public void processDirectoryWithValidFileTest(@Mocked FTPManagerPipeline ftpManager) throws IOException {
        File file1 = tempFolder.newFile("file1");
        Calendar time = Calendar.getInstance();
        time.add(Calendar.MINUTE, -3);
        file1.setLastModified(time.getTimeInMillis());

        new Expectations(){
            {
                appContext.getBean("FTPManagerPipeline");
                result = ftpManager;

                ftpManager.runSteps(anyString, "forceID", "3");
            }
        };

        boolean result = dirProcessor.processDirectory();

        Assert.assertTrue("Should have picked up a file", result);
    }

    @Test
    public void processDirectoryWhenAllFilesHaveExceededMaxAgeTest(@Mocked FTPManagerPipeline ftpManager) throws IOException {
        Calendar time = Calendar.getInstance();
        time.add(Calendar.HOUR, -10);

        File file1 = tempFolder.newFile("file1");
        file1.setLastModified(time.getTimeInMillis());

        File file2 = tempFolder.newFile("file2");
        file2.setLastModified(time.getTimeInMillis());

        File file3 = tempFolder.newFile("file3");
        file3.setLastModified(time.getTimeInMillis());

        new NonStrictExpectations(){
            {
                appContext.getBean("FTPManagerPipeline");
                result = ftpManager; times = 3;

                ftpManager.runSteps(anyString, "forceID", "3"); times = 3;
            }
        };

        boolean result = dirProcessor.processDirectory();

        Assert.assertTrue("Should have picked up a file", result);
    }

    @Test
    public void processDirectoryToGrabCorrectNumberOfFiles(@Mocked FTPManagerPipeline ftpManager) throws IOException {
        Calendar time = Calendar.getInstance();
        time.add(Calendar.MINUTE, -10);

        File file1 = tempFolder.newFile("file1");
        file1.setLastModified(time.getTimeInMillis());

        File file2 = tempFolder.newFile("file2");
        file2.setLastModified(time.getTimeInMillis());

        File file3 = tempFolder.newFile("file3");
        file3.setLastModified(time.getTimeInMillis());

        new NonStrictExpectations(){
            {
                appContext.getBean("FTPManagerPipeline");
                result = ftpManager; times = 2;

                ftpManager.runSteps(anyString, "forceID", "3"); times = 2;
            }
        };

        boolean result = dirProcessor.processDirectory();

        Assert.assertTrue("Should have picked up a file", result);
    }

    @Test
    public void processDirectoryRecursively(@Mocked FTPManagerPipeline ftpManager) throws IOException {
        Calendar time = Calendar.getInstance();
        time.add(Calendar.MINUTE, -10);

        File file1 = tempFolder.newFile("file1");
        file1.setLastModified(time.getTimeInMillis());

        File folder = tempFolder.newFolder("folder1");
        File file4 = tempFolder.newFile("folder1/file4");
        time.add(Calendar.MINUTE, -20);
        file4.setLastModified(time.getTimeInMillis());

        new NonStrictExpectations(){
            {
                appContext.getBean("FTPManagerPipeline");
                result = ftpManager; times = 2;

                ftpManager.runSteps(anyString, "forceID", "3"); times = 2;
            }
        };

        boolean result = dirProcessor.processDirectory();

        Assert.assertTrue("Should have picked up a file", result);
    }

}
