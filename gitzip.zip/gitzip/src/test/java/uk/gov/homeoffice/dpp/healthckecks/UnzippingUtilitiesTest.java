package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.healthchecks.functions.UnzippingUtilities;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by M.Koskinas on 22/03/2017.
 */
public class UnzippingUtilitiesTest {

    private String txtFileName = "sampleFile.xml";
    private String zipFileName = "sampleFile.zip";
    private String zFileName = "zZipped.xml.z";
    private String gzipFileName = "gZipped.xml.gz";
    private String nestedFileName = "nested/F999_03-09-2011T10-51-20_000002-LDI-185.zip";
    private String unixZFileName = "F999_03-09-2011T10-51-20_000002-LDI-396.xml.Z";

    private ClassLoader classLoader = getClass().getClassLoader();


    @Test
    public void unzippingZipTest() throws IOException {

        File zipFile = new File(classLoader.getResource(zipFileName).getFile());
        FileMetadata metadata = FileMetadata.createEmptyMetadata();
        metadata.setOriginalFileName(zipFile.getName());
        List<String> filepaths = UnzippingUtilities.unzip(zipFile, metadata);

        Assert.assertEquals(filepaths.get(0),(zipFile.getPath()+".unzipped"+File.separator+"sampleFile.xml"));

        File directory = new File(zipFile.getPath()+".unzipped");
        String[] files = directory.list();

        Assert.assertEquals(files[0],"sampleFile.xml");

        //cleanup
        for(String s: files)
        {
            File currentFile = new File(directory.getPath(),s);
            currentFile.delete();
        }
        directory.delete();
    }

    @Test
    public void unzippingGZTest() throws IOException {

        File zipFile = new File(classLoader.getResource(gzipFileName).getFile());
        FileMetadata metadata = FileMetadata.createEmptyMetadata();
        metadata.setOriginalFileName(zipFile.getName());
        List<String> filepaths = UnzippingUtilities.unzip(zipFile, metadata);

        Assert.assertEquals(filepaths.get(0),(zipFile.getPath()+".unzipped"+File.separator+"gZipped.xml"));

        File directory = new File(zipFile.getPath()+".unzipped");
        String[] files = directory.list();

        Assert.assertEquals(files[0],"gZipped.xml");

        //cleanup
        for(String s: files)
        {
            File currentFile = new File(directory.getPath(),s);
            currentFile.delete();
        }
        directory.delete();
    }

    @Test
    public void unzippingZTest() throws IOException {

        File zipFile = new File(classLoader.getResource(zFileName).getFile());
        FileMetadata metadata = FileMetadata.createEmptyMetadata();
        metadata.setOriginalFileName(zipFile.getName());
        List<String> filepaths = UnzippingUtilities.unzip(zipFile, metadata);

        Assert.assertEquals(filepaths.get(0),(zipFile.getPath()+".unzipped"+File.separator+"zZipped.xml"));

        File directory = new File(zipFile.getPath()+".unzipped");
        String[] files = directory.list();

        Assert.assertEquals(files[0],"zZipped.xml");

        //cleanup
        for(String s: files)
        {
            File currentFile = new File(directory.getPath(),s);
            currentFile.delete();
        }
        directory.delete();
    }

    @Test
    public void unzippingUnixZTest() throws IOException {

        File zipFile = new File(classLoader.getResource(unixZFileName).getFile());
        FileMetadata metadata = FileMetadata.createEmptyMetadata();
        metadata.setOriginalFileName(zipFile.getName());
        List<String> filepaths = UnzippingUtilities.unzip(zipFile, metadata);

        Assert.assertEquals(filepaths.get(0),(zipFile.getPath()+".unzipped"+File.separator+"F999_03-09-2011T10-51-20_000002-LDI-396.xml"));

        File directory = new File(zipFile.getPath()+".unzipped");
        String[] files = directory.list();

        Assert.assertEquals(files[0],"F999_03-09-2011T10-51-20_000002-LDI-396.xml");

        //cleanup
        for(String s: files)
        {
            File currentFile = new File(directory.getPath(),s);
            currentFile.delete();
        }
        directory.delete();
    }

    @Test
    public void isZippedTest() throws IOException {

        File txtFile = new File(classLoader.getResource(txtFileName).getFile());
        File zipFile = new File(classLoader.getResource(zipFileName).getFile());
        File gzipFile = new File(classLoader.getResource(gzipFileName).getFile());
        File zFile = new File(classLoader.getResource(zFileName).getFile());
        File ZFile = new File(classLoader.getResource(unixZFileName).getFile());

        boolean nonZipped = UnzippingUtilities.isZipped(txtFile.getAbsolutePath());
        boolean zipped = UnzippingUtilities.isZipped(zipFile.getAbsolutePath());
        boolean gZipped = UnzippingUtilities.isZipped(gzipFile.getAbsolutePath());
        boolean zZipped = UnzippingUtilities.isZipped(zFile.getAbsolutePath());
        boolean ZZiped = UnzippingUtilities.isZipped(ZFile.getAbsolutePath());

        Assert.assertTrue(zipped);
        Assert.assertTrue(gZipped);
        Assert.assertTrue(zZipped);
        Assert.assertFalse(nonZipped);
        Assert.assertTrue(ZZiped);
    }

    @Test
    public void unzipNestedDirectoriesTest() throws IOException {
        File zipFile = new File(classLoader.getResource(nestedFileName).getFile());
        FileMetadata metadata = FileMetadata.createEmptyMetadata();
        metadata.setOriginalFileName(zipFile.getName());
        List<String> filepaths = UnzippingUtilities.unzip(zipFile, metadata);

        Assert.assertTrue(filepaths.isEmpty());

        File directory = new File(zipFile.getPath()+".unzipped");

        //cleanup
        directory.delete();
    }
}
