package uk.gov.homeoffice.dpp.fileingest;

import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.gov.homeoffice.dpp.CentralTestConfiguration;
import uk.gov.homeoffice.dpp.TestConfigurations.TestForceConfiguration;
import uk.gov.homeoffice.dpp.YamlFileApplicationContextInitializer;
import uk.gov.homeoffice.dpp.configuration.forces.ForceLandingLocation;
import uk.gov.homeoffice.dpp.configuration.forces.ForceProperties;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by M.Koskinas on 02/03/2017.
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {CentralTestConfiguration.class}, initializers = YamlFileApplicationContextInitializer.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@TestPropertySource(locations="classpath:testProperties.yml")
public abstract class FITestBuilder {


    @Before
    public void setUp()
    {


    }

    @After
    public void tearDown()
    {
        //System.setOut(null);
    }

    protected Map<String, ForceProperties> createForceProperties()
    {
        Map<String, ForceProperties> forceProperties = new HashMap<>();
        ForceProperties force1Prop = createForceProperty(999);
        ForceProperties force2Prop = createForceProperty(998);
        forceProperties.put("force1", force1Prop);
        forceProperties.put("force2", force2Prop);

        return forceProperties;
    }

    private ForceProperties createForceProperty(int forceID)
    {
        ForceLandingLocation force1Loc1 = new ForceLandingLocation();
        force1Loc1.setLocation("Force_" + forceID + "\\request\\urgent_updategram");
        force1Loc1.setPriority(3);
        ForceLandingLocation force1Loc2 = new ForceLandingLocation();
        force1Loc2.setLocation("Force_" + forceID + "\\request\\updategram");
        force1Loc2.setPriority(1);
        ForceLandingLocation force1Loc3 = new ForceLandingLocation();
        force1Loc3.setLocation("Force_" + forceID + "\\request\\bulk_updategram");
        force1Loc3.setPriority(5);
        Map<String, ForceLandingLocation> landingLocs1 = new HashMap<>();
        landingLocs1.put("location1", force1Loc1);
        landingLocs1.put("location2", force1Loc2);
        landingLocs1.put("location3", force1Loc3);
        ForceProperties force1Prop = new ForceProperties();
        force1Prop.setIngest(landingLocs1);
        force1Prop.setUpdategramResponse("Force_" + forceID + "\\response");
        force1Prop.setForceID(Integer.toString(forceID));

        return force1Prop;
    }
}
