package uk.gov.homeoffice.dpp.filemonitoring.steps;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FTPTestBuilder;

import java.util.HashMap;

/**
 * Created by C.Barnes on 20/03/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {FTPManagerConfiguration.class})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE, classes = {StepFactory.class})
public class StepFactoryTests extends FTPTestBuilder {

    @Test
    @Ignore
    public void CreatesVirusScanningStepTest()
    {
        StepSpecification vsSpec = new StepSpecification();
        vsSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("quarantine_location", "/testing/");
        vsSpec.setProperties(properties);
        Step newStep = StepFactory.createStep("virus_scanning", vsSpec);

        Assert.assertEquals(VirusScanningStep.class, newStep.getClass());
    }

    @Test
    public void CreatesFileForwardingStepTest(){
        StepSpecification ffSpec = new StepSpecification();
        ffSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("destination_dir", "/testing/");
        ffSpec.setProperties(properties);
        Step newStep = StepFactory.createStep("file_forwarding", ffSpec);

        Assert.assertEquals(FileForwardingStep.class, newStep.getClass());
    }

    @Test
    public void CreatesMetadataCreationStepTest(){
        StepSpecification mcSpec = new StepSpecification();
        mcSpec.setStatus(true);
        Step newStep = StepFactory.createStep("metadata_creation", mcSpec);

        Assert.assertEquals(MetadataCreationStep.class, newStep.getClass());
    }

    @Test
    public void CreatesRenameToFinishedStepTest(){
        StepSpecification rfSpec = new StepSpecification();
        rfSpec.setStatus(true);
        Step newStep = StepFactory.createStep("rename_to_finished", rfSpec);

        Assert.assertEquals(RenameToFinishedStep.class, newStep.getClass());
    }

    @Test
    public void InvalidNamePassedIntoStepCreationTest()
    {
        StepSpecification spec = new StepSpecification();
        spec.setStatus(true);
        Step newStep = StepFactory.createStep("InvalidName", spec);

        Assert.assertNull(newStep);
    }

    @Test
    public void CreatesUntarringStepTest()
    {
        StepSpecification utSpec = new StepSpecification();
        utSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("temp_storage", "/testing/");
        utSpec.setProperties(properties);
        Step newStep = StepFactory.createStep("untarring", utSpec);

        Assert.assertEquals(UnTarStep.class, newStep.getClass());
    }

}
