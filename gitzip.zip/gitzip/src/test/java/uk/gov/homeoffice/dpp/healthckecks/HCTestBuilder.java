package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.gov.homeoffice.dpp.CentralTestConfiguration;
import uk.gov.homeoffice.dpp.TestConfigurations.TestHealthChecksConfiguration;
import uk.gov.homeoffice.dpp.configuration.HealthChecksConfiguration;
import uk.gov.homeoffice.dpp.YamlFileApplicationContextInitializer;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.healthchecks.persistence.services.DPPFileService;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.UUID;

/**
 * Created by M.Koskinas on 02/03/2017.
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = CentralTestConfiguration.class, initializers = YamlFileApplicationContextInitializer.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE, classes = {DPPFileService.class})
@TestPropertySource(locations="classpath:testProperties.yml")
public abstract class HCTestBuilder {

    @Value("${healthChecks.logging_config.log_directory}")
    private String logDir;

    @Value("${healthChecks.logging_config.log_name}")
    private String logName;

    @Value("${healthChecks.logging_config.error_log_name}")
    private String errorLogName;

    //protected final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

    protected Path logFile;
    protected Path errorLogFile;

    @Before
    public void setUp()
    {
        logFile = Paths.get(logDir + "//" + logName);
        errorLogFile = Paths.get(logDir + "//" + errorLogName);

        emptyDiskFS(new File(HealthChecksConfiguration.filestore.getLocation()));
    }

    protected FileMetadata createMetadata(String filename, String path)
    {
        FileMetadata metadata = FileMetadata.createEmptyMetadata();
        metadata.setOriginalFilePath("home/force_id/"+filename);
        metadata.setOriginalFileName(filename);
        metadata.setGuid(UUID.randomUUID());
        metadata.setForceID("999");
        metadata.setPriorityLevel("3");
        metadata.setFinalLocation(path);
        metadata.setReceivedMachineName("centos-dev-02.datalynx.local");
        metadata.setReceivedMachineIP("192.168.114.223");
        metadata.setOriginalFileSize(3041);
        metadata.setLandingDate(new Date());
        metadata.setVSstart(new Date());
        metadata.setVSfinish(new Date());
        metadata.setState(FileMetadata.STATE_SUCCESFUL);
        metadata.setErrorMessage("NONE");

        return metadata;
    }

    private static boolean emptyDiskFS(File directory)
    {
        if(Files.exists(Paths.get(directory.getAbsolutePath())) && directory.isDirectory())
        {
            String[] children = directory.list();
            for (int i = 0 ; i < children.length ; i++)
            {
                emptyDiskFS(new File(directory, children[i]));
            }
        }
        return directory.delete();
    }

    protected FileMetadata createFileMetadataWithServerName(String serverNameIP)
    {
        FileMetadata metadata = FileMetadata.createEmptyMetadata();
        metadata.setReceivedMachineName(serverNameIP);
        return metadata;
    }

    @After
    public void tearDown()
    {
        //System.setOut(null);
    }
}
