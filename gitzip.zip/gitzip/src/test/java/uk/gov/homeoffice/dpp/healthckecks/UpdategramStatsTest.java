package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.homeoffice.dpp.healthchecks.HealthChecksPipeline;
import uk.gov.homeoffice.dpp.healthchecks.persistence.services.DPPFileService;
import uk.gov.homeoffice.dpp.healthchecks.persistence.services.UpdategramStatsService;

import java.io.File;

/**
 * Created by M.Koskinas on 13/06/2017.
 */
public class UpdategramStatsTest extends HCTestBuilder
{
    @Autowired
    HealthChecksPipeline healthChecksPipeline;

    @Autowired
    DPPFileService fileService;

    @Autowired
    UpdategramStatsService updategramStatsService;

    private ClassLoader classLoader = getClass().getClassLoader();

    @Test
    public void calculateStatsTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/StatsEventBatch.xml.properties").getFile());

//        healthChecksPipeline.runHealthChecks(file.getPath());
//        DPPFile dppFile = fileService.getFileByFilename("StatsEventBatch.xml").get(0);
//        UpdategramStats stats = updategramStatsService.findByFileid(dppFile.getId());
//
//        Assert.assertTrue(stats.getBatchType().equals("EventBatch"));
//        Assert.assertTrue(stats.getPublisher().equals("10"));
//        Assert.assertTrue(stats.getRecipient().equals("PND-DATA-TAKE-ON"));
//        Assert.assertTrue(stats.getTransactionList().equals("Transaction"));
//        Assert.assertTrue(stats.getSecurityChannel().equals("PSNP-P"));
//        Assert.assertTrue(stats.getProtectiveMarking().equals("GPMS Restricted"));
//        Assert.assertTrue(stats.getGpmsList().equals("2"));
//        Assert.assertEquals(stats.getMessages(),10);
//        Assert.assertEquals(stats.getRecords(),10);


    }
}
