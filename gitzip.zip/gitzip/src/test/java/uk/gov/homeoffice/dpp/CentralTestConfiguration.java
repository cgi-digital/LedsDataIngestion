package uk.gov.homeoffice.dpp;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Created by C.Barnes on 13/07/2017.
 * Used to scan and register all the individual config classes
 */
@Configuration
@ComponentScan
public class CentralTestConfiguration {


}
