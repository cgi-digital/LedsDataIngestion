package uk.gov.homeoffice.dpp.TestConfigurations;;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import uk.gov.homeoffice.dpp.configuration.priorities.PriorityProperties;

/**
 * Created by C.Barnes on 12/07/2017.
 */
@Configuration
@Import({PriorityProperties.class})
@PropertySource("classpath:/testProperties.yml")
public class TestPriorityConfiguration {
}
