package uk.gov.homeoffice.dpp.filemonitoring.steps;

import mockit.Expectations;
import mockit.Mocked;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FTPTestBuilder;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.filemonitoring.virusscanning.VirusScan;
import uk.gov.homeoffice.dpp.filemonitoring.virusscanning.VirusScan.VirusScanResultType;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/**
 * Created by C.Barnes on 21/03/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {FTPManagerConfiguration.class})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class VirusScanningStepTests extends FTPTestBuilder {

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Test
    public void VirusScanAFileTest(@Mocked VirusScan virusScan)
    {
        Path testFile = Paths.get("/testing/testfile.zip");
        FileMetadata fileMetadata = new FileMetadata(testFile, "F999", "3");

        StepSpecification defStepSpec = createDefaultVirusScanningStepSpec("Windows");
        VirusScanningStep virusScanningStep = new VirusScanningStep(defStepSpec);

        Map<VirusScanResultType, Integer> expVirusScanResult = new HashMap<>();
        expVirusScanResult.put(VirusScanResultType.POSSIBLY_INFECTED, 0);
        expVirusScanResult.put(VirusScanResultType.NOT_SCANNED, 0);
        expVirusScanResult.put(VirusScanResultType.CLEAN, 1);

        new Expectations(){
            {
                virusScan.runVirusScan((Path) any);
                result = new ArrayList<String>();
            }
            {
                virusScan.returnResultSummary();
                result = expVirusScanResult;
            }
        };


        StepResult result = virusScanningStep.runStep(fileMetadata);
        StepResult expResult = new StepResult(true, null, fileMetadata);

        Assert.assertEquals(expResult.isSuccess(), result.isSuccess());
        Assert.assertEquals(expResult.getErrorCode(), result.getErrorCode());
        Assert.assertEquals(expResult.getCurrentFiles(), result.getCurrentFiles());
    }


    @Test
    public void VirusScanAnInfectedFileTest(@Mocked VirusScan virusScan) throws IOException {
        Path testFile = Paths.get("/testing/testfile.zip");
        FileMetadata fileMetadata = new FileMetadata(testFile, "F999", "3");
        fileMetadata.setOriginalFilePath("/original/filepath");
        fileMetadata.setIpAddress(InetAddress.getByName("0.0.0.0"));

        StepSpecification defStepSpec = createDefaultVirusScanningStepSpec("Windows");
        VirusScanningStep virusScanningStep = new VirusScanningStep(defStepSpec);

        Map<VirusScanResultType, Integer> expVirusScanResult = new HashMap<>();
        expVirusScanResult.put(VirusScanResultType.POSSIBLY_INFECTED, 1);
        expVirusScanResult.put(VirusScanResultType.NOT_SCANNED, 0);
        expVirusScanResult.put(VirusScanResultType.CLEAN, 0);

        new Expectations(Files.class){
            {
                virusScan.runVirusScan((Path) any);
                result = new ArrayList<String>();
            }
            {
                virusScan.returnResultSummary();
                result = expVirusScanResult;
            }
            {
                Files.delete((Path) any);
            }
        };


        StepResult result = virusScanningStep.runStep(fileMetadata);
        StepResult expResult = new StepResult(false, "1", fileMetadata);

        Assert.assertEquals(expResult.isSuccess(), result.isSuccess());
        Assert.assertEquals(expResult.getErrorCode(), result.getErrorCode());
        Assert.assertEquals(expResult.getCurrentFiles(), result.getCurrentFiles());
        Assert.assertTrue("State of file was not set to VIRUS", result.getCurrentFiles().get(0).getState().equals(FileMetadata.STATE_VIRUS));
        Assert.assertTrue("Expected virus error message was not there", result.getCurrentFiles().get(0).getErrorMessage().equals(FileMetadata.VIRUS_MESSAGE));
    }

    @Test
    public void VirusScanAnUnscannableFileTest(@Mocked VirusScan virusScan) throws IOException {
        Path testFile = Paths.get("/testing/testfile.zip");
        FileMetadata fileMetadata = new FileMetadata(testFile, "F999", "3");
        fileMetadata.setOriginalFilePath("/original/filepath");

        StepSpecification defStepSpec = createDefaultVirusScanningStepSpec("Windows");
        VirusScanningStep virusScanningStep = new VirusScanningStep(defStepSpec);

        Map<VirusScanResultType, Integer> expVirusScanResult = new HashMap<>();
        expVirusScanResult.put(VirusScanResultType.POSSIBLY_INFECTED, 0);
        expVirusScanResult.put(VirusScanResultType.NOT_SCANNED, 1);
        expVirusScanResult.put(VirusScanResultType.CLEAN, 0);

        new Expectations(Files.class){
            {
                virusScan.runVirusScan((Path) any);
                result = new ArrayList<String>();
            }
            {
                virusScan.returnResultSummary();
                result = expVirusScanResult;
            }
            {
                Files.move((Path) any, (Path) any);
            }
            {
                Files.delete((Path) any);
            }

        };


        StepResult result = virusScanningStep.runStep(fileMetadata);
        StepResult expResult = new StepResult(false, "1", fileMetadata);

        Assert.assertEquals(expResult.isSuccess(), result.isSuccess());
        Assert.assertEquals(expResult.getErrorCode(), result.getErrorCode());
        Assert.assertEquals(expResult.getCurrentFiles(), result.getCurrentFiles());
        Assert.assertTrue("State of file was not set to VIRUS", result.getCurrentFiles().get(0).getState().equals(FileMetadata.STATE_VIRUS));
        Assert.assertTrue("Expected virus error message was not there", result.getCurrentFiles().get(0).getErrorMessage().equals(FileMetadata.VIRUS_MESSAGE));
    }

    @Test
    @Ignore
    public void VirusScanStepReturnsCorrectMetadataAttrTest() throws IOException {
        File input = tempFolder.newFile("test.txt");

        Date before = new Date();
        FileMetadata fileMetadata = new FileMetadata(input.toPath(), "F999", "3");

        StepSpecification stepSpec = new StepSpecification();
        stepSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("quarantine_location", "/testing/");
        stepSpec.setProperties(properties);

        VirusScanningStep vscan = new VirusScanningStep(stepSpec);
        vscan.runStep(fileMetadata);

        Date after = new Date();

        Assert.assertTrue(fileMetadata.getVSstart().after(before) || fileMetadata.getVSstart().equals(before));
        Assert.assertTrue(fileMetadata.getVSfinish().before(after) || fileMetadata.getVSfinish().equals(after));
        Assert.assertTrue(fileMetadata.getVSstart().before(fileMetadata.getVSfinish()) || fileMetadata.getVSstart().equals(fileMetadata.getVSfinish()));
    }

    @Test
    @Ignore
    public void VirusScanStepReturnsCorrectNameTest()
    {
        StepSpecification stepSpec = new StepSpecification();
        stepSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("quarantine_location", "/testing/");
        stepSpec.setProperties(properties);

        VirusScanningStep vscan = new VirusScanningStep(stepSpec);

        Assert.assertEquals("virus_scanning", vscan.getName());
    }

    @Test
    @Ignore //Currently method is not in use
    public void QuarantineAFileTest()
    {
        Assert.fail();
    }

}
