package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.healthchecks.checks.CategoryOneCheckResult;
import uk.gov.homeoffice.dpp.healthchecks.checks.UpdategramHandler;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;

import java.io.File;
import java.util.List;

/**
 * Created by M.Koskinas on 21/04/2017.
 */
public class BatchHeaderTests extends HCTestBuilder
{

    private ClassLoader classLoader = getClass().getClassLoader();

    @Test
    public void publisherAndRecipientNegativeTests()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/BatchHeaderTests/emptyValues.xml").getFile());
        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("Centos-DEV-02/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_0010_020_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
            else if("C_ALL_0010_010_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/BatchHeaderTests/InvalidPublisher.xml").getFile());
        results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("Centos-DEV-02/IP"), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_0010_010_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }
    }

    @Test
    public void publisherAndRecipienteTests() {
        File file = new File(classLoader.getResource("XSDTestFiles/BatchHeaderTests/valid.xml").getFile());
        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file, createFileMetadataWithServerName("Centos-DEV-02/IP"), new UpdategramStats());

        for (int r = 0; r < results.size(); r++) {
            if ("C_ALL_0010_020_1".equals(results.get(r).getCheckName())) {
                Assert.assertTrue(results.get(r).isSuccess());
            } else if ("C_ALL_0010_010_1".equals(results.get(r).getCheckName())) {
                Assert.assertTrue(results.get(r).isSuccess());
            }
        }
    }

}
