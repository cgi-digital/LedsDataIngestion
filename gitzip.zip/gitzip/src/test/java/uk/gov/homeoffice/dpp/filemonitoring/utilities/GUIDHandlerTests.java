package uk.gov.homeoffice.dpp.filemonitoring.utilities;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FTPTestBuilder;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

/**
 * Created by C.Barnes on 24/03/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {FTPManagerConfiguration.class})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class GUIDHandlerTests extends FTPTestBuilder {

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Test
    public void GenerateAGUIDTest()
    {
        Assert.assertEquals(UUID.class, GUIDHandler.guidGenerator().getClass());
    }

    @Test
    public void GenerateAGUIDAsAStringTest()
    {
        Assert.assertEquals(String.class, GUIDHandler.guidGeneratorAsString().getClass());
    }

    @Test
    public void GenerateUniqueGUIDTest()
    {
        UUID first = GUIDHandler.guidGenerator();
        UUID second = GUIDHandler.guidGenerator();

        Assert.assertNotEquals(first.toString(), second.toString());
    }

    @Test
    public void RenameAFileToGUIDTest() throws IOException {
        UUID guid = UUID.randomUUID();

        Path file = tempFolder.newFile("test.testing.txt").toPath();

        Path result = GUIDHandler.renameFileToGuid(file, guid);
        Path expResult = Paths.get(file.getParent().toString() + "/" + guid + ".txt");

        Assert.assertEquals(expResult.toString(), result.toString());
    }

}
