package uk.gov.homeoffice.dpp.fileingest;

import mockit.*;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import uk.gov.homeoffice.dpp.configuration.FileIngestConfiguration;
import uk.gov.homeoffice.dpp.configuration.forces.ForceProperties;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by C.Barnes on 10/07/2017.
 */
public class DirPollerTests extends FITestBuilder {

    @Injectable
    ApplicationContext appContext;

    @Tested
    private DirPoller dirPoller;

    @Before
    public void beforeTests()
    {
        Map<String, ForceProperties> forcePropertiesMap = new HashMap<>();
        forcePropertiesMap = createForceProperties();

        dirPoller = new DirPoller(forcePropertiesMap, FileIngestConfiguration.getMinFileAge());
    }

    @Test
    public void pollProcessingTest(@Mocked DirProcessor dirProcessor) throws InterruptedException {

        new NonStrictExpectations(){
            {
                appContext.getBean(anyString, any, any, anyString);
                result = dirProcessor; times = 4;


                dirProcessor.processDirectory();
                result = true;
                times = 4;
            }
        };

        dirPoller.poll();

    }

    @Test
    public void pollProcessingOrderTest(@Mocked DirProcessor dirProcessor)
    {
        new Expectations() {
            {
                appContext.getBean(anyString, dirPoller.getDirsToPoll().get(1).getDirPath(), any, any);
                result = dirProcessor;

                dirProcessor.processDirectory();
                result = true;
            }
            {
                appContext.getBean(anyString, dirPoller.getDirsToPoll().get(4).getDirPath(), any, any);
                result = dirProcessor;

                dirProcessor.processDirectory();
                result = true;
            }
            {
                appContext.getBean(anyString, dirPoller.getDirsToPoll().get(0).getDirPath(), any, any);
                result = dirProcessor;

                dirProcessor.processDirectory();
                result = true;
            }
            {
                appContext.getBean(anyString, dirPoller.getDirsToPoll().get(3).getDirPath(), any, any);
                result = dirProcessor;

                dirProcessor.processDirectory();
                result = true;
            }
        };

        dirPoller.poll();


    }

}
