package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.healthchecks.checks.UpdategramHandler;
import uk.gov.homeoffice.dpp.healthchecks.checks.CategoryOneCheckResult;

import java.io.File;
import java.util.List;

/**
 * Created by M.Koskinas on 21/04/2017.
 */
public class ForceAgencyCheckTests extends HCTestBuilder
{

    private ClassLoader classLoader = getClass().getClassLoader();

    @Test
    public void runCheckTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/RecordBatch.xml").getFile());
        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file);

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_0010_010_2".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_0030_030_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/ForceAgencyCheckTests/AttachmentBatchInvalid.xml").getFile());
        results = UpdategramHandler.executeChecks(file);

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_0010_010_2".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
            else if("C_ALL_0030_030_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
        }

//        file = new File(classLoader.getResource("XSDTestFiles/ForceAgencyCheckTests/AttachmentBatchInvalid2.xml").getFile());
//        results = UpdategramHandler.executeChecks(file, FileProperties.createEmptyMetadata());
//        boolean firstErrorDetected =false;
//
//
//        for(int r = 0 ; r < results.size() ; r++)
//        {
//            if("C_ALL_0010_010_2".equals(results.get(r).getCheckName()))
//            {
//                Assert.assertTrue(results.get(r).isSuccess());
//            }
//            else if("C_ALL_1000_M030_1".equals(results.get(r).getCheckName()) && !firstErrorDetected)
//            {
//                Assert.assertFalse(results.get(r).isSuccess());
//                firstErrorDetected = true;
//            }
//            else if("C_ALL_0030_030_1".equals(results.get(r).getCheckName()))
//            {
//                Assert.assertFalse(results.get(r).isSuccess());
//            }
//        }
    }
}
