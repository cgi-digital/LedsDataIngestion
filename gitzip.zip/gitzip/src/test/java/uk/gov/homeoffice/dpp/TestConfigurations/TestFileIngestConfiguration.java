package uk.gov.homeoffice.dpp.TestConfigurations;;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import uk.gov.homeoffice.dpp.configuration.FileIngestConfiguration;

/**
 * Created by C.Barnes on 08/03/2017.
 */
@Configuration
@Import({FileIngestConfiguration.class})
@PropertySource("classpath:/testProperties.yml")
public class TestFileIngestConfiguration {


    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        PropertySourcesPlaceholderConfigurer placeholderConfigurer = new PropertySourcesPlaceholderConfigurer();
        placeholderConfigurer.setLocation(new ClassPathResource("testProperties.yml"));
        return placeholderConfigurer;
    }


}
