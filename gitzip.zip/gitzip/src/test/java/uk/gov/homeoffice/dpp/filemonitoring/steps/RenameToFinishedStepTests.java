package uk.gov.homeoffice.dpp.filemonitoring.steps;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.gov.homeoffice.dpp.DotFinishedHandler;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FTPTestBuilder;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;

/**
 * Created by C.Barnes on 20/03/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {FTPManagerConfiguration.class})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE, classes = {RenameToFinishedStep.class})
public class RenameToFinishedStepTests extends FTPTestBuilder {



    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Test
    public void RenameAFileToDotFinishedTest() throws IOException {
        File input = tempFolder.newFile("test.txt");

        FileMetadata fileMetadata = new FileMetadata(input.toPath(), "F999", "3");
        fileMetadata.setOriginalFilePath(input.getPath());

        StepSpecification stepSpec = new StepSpecification();
        stepSpec.setStatus(true);
        RenameToFinishedStep rename = new RenameToFinishedStep(stepSpec);

        StepResult result = rename.runStep(fileMetadata);
        StepResult expectedResult = new StepResult(true, null, fileMetadata);


        Assert.assertEquals(expectedResult.isSuccess(), result.isSuccess());
        Assert.assertEquals(expectedResult.getCurrentFiles(), result.getCurrentFiles());
        Assert.assertEquals(expectedResult.getErrorCode(), result.getErrorCode());

    }

    @Test
    public void TryToRenameAFileThatDoesNotExistTest()
    {
        FileMetadata fileMetadata = new FileMetadata(Paths.get("/null/"), "999", "3");
        fileMetadata.setOriginalFilePath("/null/");

        StepSpecification stepSpec = new StepSpecification();
        stepSpec.setStatus(true);
        RenameToFinishedStep rename = new RenameToFinishedStep(stepSpec);

        StepResult result = rename.runStep(fileMetadata);
        StepResult expectedResult = new StepResult(false, DotFinishedHandler.errorCode, fileMetadata);


        Assert.assertEquals(expectedResult.isSuccess(), result.isSuccess());
        Assert.assertEquals(expectedResult.getCurrentFiles(), result.getCurrentFiles());
        Assert.assertEquals(expectedResult.getErrorCode(), result.getErrorCode());
    }

    @Test
    public void RenameToFinishedStepReturnsCorrectMetadataAttrTest() throws IOException {
        File input = tempFolder.newFile("test.txt");

        FileMetadata fileMetadata = new FileMetadata(input.toPath(), "F999", "3");
        fileMetadata.setOriginalFilePath(input.getPath());
        FileMetadata expFileMetadata = new FileMetadata(Paths.get(input.getPath() + ".finished"), "F999", "3");
        expFileMetadata.setOriginalFilePath(input.getPath());

        StepSpecification stepSpec = new StepSpecification();
        stepSpec.setStatus(true);
        RenameToFinishedStep rename = new RenameToFinishedStep(stepSpec);

        rename.runStep(fileMetadata);
        areAllMetadataAttributesTheSame(fileMetadata, expFileMetadata);
    }

    @Test
    public void RenameToFinishedStepReturnsCorrectNameTest()
    {
        StepSpecification stepSpec = new StepSpecification();
        stepSpec.setStatus(true);
        RenameToFinishedStep rename = new RenameToFinishedStep(stepSpec);

        Assert.assertEquals("rename_to_finished", rename.getName());
    }

    @Test
    @Ignore
    public void RenameToFinishedStepSetsModifiedTimeTest() throws IOException {
        File input = tempFolder.newFile("test.txt");
        FileTime origFileTime = Files.getLastModifiedTime(Paths.get(input.getPath()));

        FileMetadata fileMetadata = new FileMetadata(input.toPath(), "F999", "3");
        fileMetadata.setOriginalFilePath(input.getPath());

        StepSpecification stepSpec = new StepSpecification();
        stepSpec.setStatus(true);
        RenameToFinishedStep rename = new RenameToFinishedStep(stepSpec);

        rename.runStep(fileMetadata);
        FileTime expFileTime = Files.getLastModifiedTime(Paths.get(input.getPath() + ".finished"));

        Assert.assertTrue("The file modified times are the same when it should have been changed", origFileTime != expFileTime);
        Assert.assertTrue("Updated file modified time is older than the original time", expFileTime.compareTo(origFileTime) >= 0);

    }

    @Test
    @Ignore //Currently unsure as to how to cause this exception
    public void TryToRenameAFileThatCannotBeRenamed()
    {
        Assert.fail();
    }

}
