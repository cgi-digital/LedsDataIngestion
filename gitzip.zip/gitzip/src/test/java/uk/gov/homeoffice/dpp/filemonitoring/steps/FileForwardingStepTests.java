package uk.gov.homeoffice.dpp.filemonitoring.steps;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FTPTestBuilder;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.HashMap;

/**
 * Created by C.Barnes on 22/03/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {FTPManagerConfiguration.class})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class FileForwardingStepTests extends FTPTestBuilder {


    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Test
    public void ForwardingAFileTest() throws IOException {
        File file = tempFolder.newFolder("Start").toPath()
                .resolve("test.txt")
                .toFile();

        tempFolder.newFile("Start/test.txt");
        tempFolder.newFile("Start/test.txt.properties");

        String destination = tempFolder.newFolder("Destination").getPath();

        FileMetadata fileMetadata = new FileMetadata(file.toPath(), "F999", "3");
        //FileMetadata expFileMetadata = new FileMetadata(Paths.get(destination + "/" + file.getName()));

        StepSpecification ffSpec = new StepSpecification();
        ffSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("destination_dir", destination);
        ffSpec.setProperties(properties);

        FileForwardingStep fileForward = new FileForwardingStep(ffSpec);
        StepResult result = fileForward.runStep(fileMetadata);
        StepResult expResult = new StepResult(true, null, fileMetadata);

        Assert.assertEquals(expResult.isSuccess(), result.isSuccess());
        Assert.assertEquals(expResult.getErrorCode(), result.getErrorCode());
        Assert.assertEquals(expResult.getCurrentFiles(), result.getCurrentFiles());

    }

    @Test
    public void ForwardAFileStepReturnsCorrectMetadataAttrTest() throws IOException {
        File file = tempFolder.newFolder("Start").toPath()
                .resolve("test.txt")
                .toFile();

        tempFolder.newFile("Start/test.txt");
        tempFolder.newFile("Start/test.txt.properties");

        String destination = tempFolder.newFolder("Destination").getPath();

        FileMetadata fileMetadata = new FileMetadata(file.toPath(), "F999", "3");

        FileMetadata expFileMetadata = new FileMetadata(Paths.get(destination + "/3/" + file.getName()), "F999", "3");


        StepSpecification ffSpec = new StepSpecification();
        ffSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("destination_dir", destination);
        ffSpec.setProperties(properties);

        FileForwardingStep fileForward = new FileForwardingStep(ffSpec);
        fileForward.runStep(fileMetadata);

        areAllMetadataAttributesTheSame(fileMetadata, expFileMetadata);
    }

    @Test
    public void TryingToForwardAFileWithNoPropertiesFileTest() throws IOException {
        File file = tempFolder.newFolder("Start").toPath()
                .resolve("test.txt")
                .toFile();

        tempFolder.newFile("Start/test.txt");

        String destination = tempFolder.newFolder("Destination").getPath();

        FileMetadata fileMetadata = new FileMetadata(file.toPath(), "F999", "3");

        StepSpecification ffSpec = new StepSpecification();
        ffSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("destination_dir", destination);
        ffSpec.setProperties(properties);

        FileForwardingStep fileForward = new FileForwardingStep(ffSpec);
        StepResult result = fileForward.runStep(fileMetadata);
        StepResult expResult = new StepResult(false, "1", fileMetadata);

        Assert.assertEquals(expResult.isSuccess(), result.isSuccess());
        Assert.assertEquals(expResult.getErrorCode(), result.getErrorCode());
        Assert.assertEquals(expResult.getCurrentFiles(), result.getCurrentFiles());
    }

    @Test
    public void FileForwardingStepReturnsTheCorrectName()
    {
        StepSpecification ffSpec = new StepSpecification();
        ffSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("destination_dir", "/testing/");
        ffSpec.setProperties(properties);

        FileForwardingStep fileForward = new FileForwardingStep(ffSpec);

        Assert.assertEquals("file_forwarding", fileForward.getName());
    }

}
