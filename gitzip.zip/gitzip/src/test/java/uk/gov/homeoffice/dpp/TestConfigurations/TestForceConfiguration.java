package uk.gov.homeoffice.dpp.TestConfigurations;;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import uk.gov.homeoffice.dpp.configuration.forces.ForcesConfiguration;

/**
 * Created by C.Barnes on 10/07/2017.
 */
@Configuration
@Import({ForcesConfiguration.class})
@PropertySource("classpath:/testProperties.yml")
public class TestForceConfiguration {



}
