package uk.gov.homeoffice.dpp.filemonitoring.utilities;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.gov.homeoffice.dpp.DotFinishedHandler;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FTPTestBuilder;

/**
 * Created by C.Barnes on 20/03/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {FTPManagerConfiguration.class})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE, classes = {DotFinishedHandler.class})
public class DotFinishedHandlerTests extends FTPTestBuilder {

    @Test
    public void CorrectlyAppendsDotFinishedToEndOfStringTest()
    {
        String origString = "/test/testing.txt";
        String newString = DotFinishedHandler.appendDotFinished(origString);

        Assert.assertEquals("/test/testing.txt.finished", newString);
    }

    @Test
    public void CorrectlyRemoveDotFinishedFromEndOfStringTest()
    {
        String origString = "/test/testing.txt.finished";
        String newString = DotFinishedHandler.removeDotFinished(origString);

        Assert.assertEquals("/test/testing.txt", newString);
    }

    @Test
    public void LeaveStringUnalteredIfTryingToRemoveDotFinishedWhenItIsntThereTest()
    {
        String origString = "/test/testing.txt";
        String newString = DotFinishedHandler.removeDotFinished(origString);

        Assert.assertEquals(origString, newString);
    }

}
