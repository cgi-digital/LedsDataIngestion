//package uk.gov.homeoffice.dpp.healthckecks.MessageScanning;
//
//import mockit.*;
//import org.apache.commons.io.FileUtils;
//import org.junit.Assert;
//import org.junit.Rule;
//import org.junit.Test;
//import org.junit.rules.TemporaryFolder;
//import org.springframework.context.ApplicationContext;
//import uk.gov.homeoffice.dpp.healthchecks.messagescanning.MessageProcessing;
//import uk.gov.homeoffice.dpp.healthchecks.HealthChecksPipeline;
//import uk.gov.homeoffice.dpp.healthckecks.TestBuilder;
//
//import java.io.File;
//import java.io.IOException;
//import java.nio.file.Files;
//import java.nio.file.InvalidPathException;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.nio.file.attribute.FileTime;
//import java.util.Arrays;
//import java.util.Calendar;
//import java.util.List;
//
///**
// * Created by C.Barnes on 24/04/2017.
// */
//public class MessageProcessingTests extends TestBuilder {
//
//
//
//    @Injectable
//    private ApplicationContext applicationContext;
//
//    @Tested
//    private MessageProcessing messageProcessing = new MessageProcessing();
//
//    @Rule
//    public TemporaryFolder tempFolder = new TemporaryFolder();
//
//    @Test
//    public void processMessageListWithValidProcessesTest(@Mocked HealthChecksPipeline pipeline) throws IOException {
//        File message1 = tempFolder.newFile("1234.process.testmessage1");
//        List<String> message1Cont = Arrays.asList(MessageProcessing.FILE_TO_PROCESS_PROP + "test/location/of/file/to/process");
//        FileUtils.writeLines(message1, message1Cont);
//
//        File message2 = tempFolder.newFile("1234.process.testmessage2");
//        List<String> message2Cont = Arrays.asList(MessageProcessing.FILE_TO_PROCESS_PROP + "test/location/of/file/to/process");
//        FileUtils.writeLines(message2, message2Cont);
//
//        File[] fileList = new File[]{message1, message2};
//
//        new Expectations(2, File.class) {
//            {
//                File f = new File(anyString);
//                f.exists();
//                result = true;
//            }
//            {
//                applicationContext.getBean(anyString);
//                result = pipeline;
//            }
//            {
//                pipeline.runHealthChecks(anyString);
//
//            }
//
//        };
//
//        boolean result = messageProcessing.processMessageList(fileList);
//
//
//        Assert.assertTrue(result);
//        Assert.assertFalse(message1.exists());
//        Assert.assertFalse(message2.exists());
//
//    }
//
//    @Test
//    public void processMessageListWithExitMessageTest(@Mocked HealthChecksPipeline pipeline) throws IOException {
//        File message1 = tempFolder.newFile("1234.exit");
//
//        File message2 = tempFolder.newFile("1234.process.testmessage2");
//        List<String> message2Cont = Arrays.asList(MessageProcessing.FILE_TO_PROCESS_PROP + "test/location/of/file/to/scan2");
//        FileUtils.writeLines(message2, message2Cont);
//
//        File[] fileList = new File[]{message1, message2};
//
//        new Expectations( File.class) {
//            {
//                File f = new File(anyString);
//                f.exists();
//                result = true;
//            }
//            {
//                applicationContext.getBean(anyString);
//                result = pipeline;
//            }
//            {
//                pipeline.runHealthChecks(anyString);
//
//            }
//
//        };
//
//        boolean result = messageProcessing.processMessageList(fileList);
//
//
//        Assert.assertFalse(result);
//        Assert.assertFalse(message1.exists());
//        Assert.assertFalse(message2.exists());
//
//    }
//
//    @Test
//    public void processMessageListWithUnknownMessageTest(@Mocked HealthChecksPipeline pipeline) throws IOException {
//        File message1 = tempFolder.newFile("1234.fawnef.kwejef");
//        List<String> message1Cont = Arrays.asList(MessageProcessing.FILE_TO_PROCESS_PROP + "test/location/of/file/to/scan2");
//        FileUtils.writeLines(message1, message1Cont);
//
//        File message2 = tempFolder.newFile("1234.process.testmessage2");
//        List<String> message2Cont = Arrays.asList(MessageProcessing.FILE_TO_PROCESS_PROP + "test/location/of/file/to/scan2");
//        FileUtils.writeLines(message2, message2Cont);
//
//        File[] fileList = new File[]{message1, message2};
//
//        new Expectations( File.class) {
//            {
//                File f = new File(withSubstring(Paths.get("test/location/of/file/to/scan2").toString()));
//                f.exists();
//                result = true;
//            }
//            {
//                applicationContext.getBean(anyString);
//                result = pipeline;
//            }
//            {
//                pipeline.runHealthChecks(anyString);
//
//            }
//
//        };
//
//        boolean result = messageProcessing.processMessageList(fileList);
//
//        Path expectedErrorFolder = Paths.get(message1.getParent() + "/" + MessageProcessing.ERROR_FOLDER);
//
//        Assert.assertTrue(result);
//        Assert.assertEquals(1, expectedErrorFolder.toFile().list().length);
//        Assert.assertFalse(message1.exists());
//        Assert.assertFalse(message2.exists());
//
//    }
//
//    @Test
//    public void processMessageListWithExitMessageAndInvalidMessageTest(@Mocked HealthChecksPipeline pipeline) throws IOException {
//        File message1 = tempFolder.newFile("1234.exit");
//
//        File message2 = tempFolder.newFile("1234.process.testmessage2");
//
//
//        File[] fileList = new File[]{message1, message2};
//
////        new Expectations( File.class) {
////            {
////                File f = new File(anyString);
////                f.exists();
////                result = true;
////            }
////
////        };
//
//        boolean result = messageProcessing.processMessageList(fileList);
//
//        Path expectedErrorFolder = Paths.get(message1.getParent() + "/" + MessageProcessing.ERROR_FOLDER);
//
//        Assert.assertFalse(result);
//        Assert.assertEquals(1, expectedErrorFolder.toFile().list().length);
//        Assert.assertFalse(message1.exists());
//        Assert.assertFalse(message2.exists());
//
//    }
//
//    @Test
//    public void processMessageListWithNotEnoughParametersTest(@Mocked HealthChecksPipeline pipeline) throws IOException {
//
//        File message1 = tempFolder.newFile("1234.process.testmessage1");
//
//
//        File message2 = tempFolder.newFile("1234.process.testmessage2");
//        List<String> message2Cont = Arrays.asList(MessageProcessing.FILE_TO_PROCESS_PROP + "test/location/of/file/to/scan2");
//        FileUtils.writeLines(message2, message2Cont);
//
//        File[] fileList = new File[]{message1, message2};
//
//        new Expectations(  File.class) {
//            {
//                File f = new File(withSubstring(Paths.get("test/location/of/file/to/scan2").toString()));
//                f.exists();
//                result = true;
//
//                applicationContext.getBean(anyString);
//                result = pipeline; minTimes = 0;
//
//                pipeline.runHealthChecks(anyString); minTimes = 0;
//            }
//        };
//
//        boolean result = messageProcessing.processMessageList(fileList);
//
//        Path expectedErrorFolder = Paths.get(message1.getParent() + "/" + MessageProcessing.ERROR_FOLDER);
//
//
//        Assert.assertTrue(result);
//        Assert.assertEquals(1, expectedErrorFolder.toFile().list().length);
//        Assert.assertFalse(message1.exists());
//        Assert.assertFalse(message2.exists());
//
//    }
//
//    @Test
//    public void processMessageListWithNonExistantMessageTest(@Mocked HealthChecksPipeline pipeline) throws IOException {
//
//        File message1 = tempFolder.newFile("1234.process.testmessage1");
//        List<String> message1Cont = Arrays.asList(MessageProcessing.FILE_TO_PROCESS_PROP + "test/location/of/file/to/scan");
//        FileUtils.writeLines(message1, message1Cont);
//
//
//        File message2 = new File(message1.getParent() + "/1234.process.testmessage2");
//
//
//        File[] fileList = new File[]{message1, message2};
//
//        new Expectations(  File.class) {
//            {
//
//                File f = new File(withSubstring(Paths.get("test/location/of/file/to/scan").toString()));
//                f.exists();
//                result = true;
//
//                applicationContext.getBean(anyString);
//                result = pipeline; minTimes = 0;
//
//                pipeline.runHealthChecks(anyString); minTimes = 0;
//
//            }
//        };
//
//        boolean result = messageProcessing.processMessageList(fileList);
//
//        Path expectedErrorFolder = Paths.get(message1.getParent() + "/" + MessageProcessing.ERROR_FOLDER);
//
//
//        Assert.assertTrue(result);
//        Assert.assertFalse(expectedErrorFolder.toFile().exists());
//        Assert.assertFalse(message1.exists());
//        Assert.assertFalse(message2.exists());
//
//    }
//
//    @Test
//    public void processMessageListWithIOExceptionTest(@Mocked HealthChecksPipeline pipeline) throws IOException {
//
//        File message1 = tempFolder.newFile("1234.process.testmessage1");
//        List<String> message1Cont = Arrays.asList(MessageProcessing.FILE_TO_PROCESS_PROP + "test/location/of/file/to/scan");
//        FileUtils.writeLines(message1, message1Cont);
//
//
//        File message2 = tempFolder.newFile("1234.process.testmessage2");
//        List<String> message2Cont = Arrays.asList(MessageProcessing.FILE_TO_PROCESS_PROP + "test/location/of/file/to/scan2");
//        FileUtils.writeLines(message2, message2Cont);
//
//        File[] fileList = new File[]{message1, message2};
//
//        new Expectations( File.class){
//            {
//
//                File f = new File(withSubstring(Paths.get("test/location/of/file/to/scan").toString()));
//                f.exists();
//                result = new IOException();
//
//            }
//            {
//                File f = new File(withSubstring(Paths.get("test/location/of/file/to/scan2").toString()));
//                f.exists();
//                result = true;
//
//                applicationContext.getBean(anyString);
//                result = pipeline;
//
//                pipeline.runHealthChecks(anyString);
//            }
//        };
//
//        boolean result = messageProcessing.processMessageList(fileList);
//
//        Path expectedErrorFolder = Paths.get(message1.getParent() + "/" + MessageProcessing.ERROR_FOLDER);
//
//
//        Assert.assertTrue(result);
//        Assert.assertEquals(1, expectedErrorFolder.toFile().list().length);
//        Assert.assertFalse(message1.exists());
//        Assert.assertFalse(message2.exists());
//
//    }
//
//    @Test
//    public void processMessageListWithInvalidPathExceptionTest(@Mocked HealthChecksPipeline pipeline) throws IOException {
//
//        File message1 = tempFolder.newFile("1234.process.testmessage1");
//        List<String> message1Cont = Arrays.asList(MessageProcessing.FILE_TO_PROCESS_PROP + "test/location/of/file/to/scan");
//        FileUtils.writeLines(message1, message1Cont);
//
//
//        File message2 = tempFolder.newFile("1234.process.testmessage2");
//        List<String> message2Cont = Arrays.asList(MessageProcessing.FILE_TO_PROCESS_PROP + "test/location/of/file/to/scan2");
//        FileUtils.writeLines(message2, message2Cont);
//
//        File[] fileList = new File[]{message1, message2};
//
//        new Expectations( File.class){
//            {
//
//                File f = new File(withSubstring(Paths.get("test/location/of/file/to/scan").toString()));
//                f.exists();
//                result = new InvalidPathException(anyString, anyString);
//
//                File f2 = new File(anyString);
//                f2.exists();
//                result = false;
//
//            }
//            {
//
//                File f = new File(Paths.get("test/location/of/file/to/scan2").toString());
//                f.exists();
//                result = true;
//
//                applicationContext.getBean(anyString);
//                result = pipeline;
//
//                pipeline.runHealthChecks(anyString);
//            }
//        };
//
//        boolean result = messageProcessing.processMessageList(fileList);
//
//        Path expectedErrorFolder = Paths.get(message1.getParent() + "/" + MessageProcessing.ERROR_FOLDER);
//
//
//        Assert.assertTrue(result);
//        Assert.assertEquals(1, expectedErrorFolder.toFile().list().length);
//        Assert.assertFalse(message1.exists());
//        Assert.assertFalse(message2.exists());
//
//    }
//
//    @Test
//    public void sortByOldestFirstTest() throws IOException {
//        File file1 = tempFolder.newFile("file1");
//        Calendar c1 = Calendar.getInstance();
//        c1.set(2014, Calendar.MARCH, 20);
//        Files.setLastModifiedTime(file1.toPath(), FileTime.fromMillis(c1.getTimeInMillis()));
//
//        File file2 = tempFolder.newFile("file2");
//        Calendar c2= Calendar.getInstance();
//        c2.set(2014, Calendar.JULY, 20);
//        Files.setLastModifiedTime(file2.toPath(), FileTime.fromMillis(c2.getTimeInMillis()));
//
//        File file3 = tempFolder.newFile("file3");
//        Calendar c3= Calendar.getInstance();
//        c3.set(2010, Calendar.JULY, 20);
//        Files.setLastModifiedTime(file3.toPath(), FileTime.fromMillis(c3.getTimeInMillis()));
//
//        File[] fileList = new File[] {file1, file2, file3};
//
//        File[] resultFileList = Deencapsulation.invoke(messageProcessing, "sortByOldestFirst", (Object) fileList);
//
//        File[] expFileList = new File[] {file3, file1, file2};
//
//
//        Assert.assertArrayEquals(expFileList, resultFileList);
//    }
//
//}
