package uk.gov.homeoffice.dpp.filemonitoring.steps;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FTPTestBuilder;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by C.Barnes on 23/03/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {FTPManagerConfiguration.class})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class UnTarStepTests extends FTPTestBuilder {

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Before
    public void BeforeUntarring() throws IOException {
        Path outputFolder =  tempFolder.newFolder("Output").toPath();
        //tempFolder.newFolder("Output", "TestTar");
        FTPManagerConfiguration.setTemp_storage(outputFolder.toString());
        outputFolder = tempFolder.newFolder("Output", "TempStorage").toPath();
        FTPManagerConfiguration.setTemp_storage_name(outputFolder.getFileName().toString());

    }

    @Test
    public void UntarFileTest() throws IOException {
        Path outputFolder =  tempFolder.newFolder("Output", "TempStorage", "TempTar").toPath();
//        tempFolder.newFolder("Output", "TestTar");
//        ApplicationConfiguration.setTemp_storage(outputFolder.toString());

        File testFile = new File(this.getClass().getClassLoader().getResource("Test.tar").getFile());

        FileMetadata fileMetadata = new FileMetadata(Paths.get(testFile.getPath()), "F999", "3");

        StepSpecification utSpec = new StepSpecification();
        utSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("temp_storage", outputFolder.toString());
        utSpec.setProperties(properties);

        UnTarStep untar = new UnTarStep(utSpec);
        //untar.setTempStorage(Paths.get(ApplicationConfiguration.getTempStoragePath().toString() + "/TestTar"));

        StepResult result = untar.runStep(fileMetadata);
        ArrayList<FileMetadata> expFiles = new ArrayList<>();
        expFiles.add(new FileMetadata(Paths.get(outputFolder.toString() + "/Test123/Update1/TestDoc1.txt"), "F999", "3"));
        expFiles.add(new FileMetadata(Paths.get(outputFolder.toString() + "/Test123/Update3/TestDoc2.txt"), "F999", "3"));
        StepResult expResult = new StepResult(true, null, expFiles);

        Assert.assertEquals(expResult.isSuccess(), result.isSuccess());
        Assert.assertEquals(expResult.getErrorCode(), result.getErrorCode());
        Assert.assertEquals(expResult.getCurrentFiles().size(), result.getCurrentFiles().size());
    }

    @Test
    public void UntarringStepDuplicatesCorrectMetadataTest() throws IOException {

        Path outputFolder =  tempFolder.newFolder("Output", "TempStorage", "TempTar").toPath();

        File testFile = new File(this.getClass().getClassLoader().getResource("Test.tar").getFile());

        Date found = new Date();
        Date start = new Date();
        Date finish = new Date();

        FileMetadata fileMetadata = new FileMetadata(Paths.get(testFile.getPath()), "F999", "3");
        fileMetadata.setOriginalFilePath("/test1/");
        fileMetadata.setVSstart(start);
        fileMetadata.setVSfinish(finish);
        fileMetadata.setLandingDate(found);

        StepSpecification utSpec = new StepSpecification();
        utSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("temp_folder_name", outputFolder.getFileName().toString());
        utSpec.setProperties(properties);

        UnTarStep untar = new UnTarStep(utSpec);
        //untar.setTempStorage(Paths.get(ApplicationConfiguration.getTempStoragePath().toString() + "/TestTar"));

        StepResult result = untar.runStep(fileMetadata);

        FileMetadata resultMetadata = result.getCurrentFiles().get(0);

        Path expPath = Paths.get(outputFolder.toString() + "/Test123/Update1/TestDoc1.txt");

        Assert.assertEquals(expPath.toString(), resultMetadata.getCurrentPath().toString());
        Assert.assertEquals(fileMetadata.getOriginalFilePath(), resultMetadata.getOriginalFilePath());
        Assert.assertEquals(fileMetadata.getLandingDate(), resultMetadata.getLandingDate());
        Assert.assertEquals(fileMetadata.getVSstart(), resultMetadata.getVSstart());
        Assert.assertEquals(fileMetadata.getVSfinish(), resultMetadata.getVSfinish());
    }

    @Test
    public void TryToUnTarNonExistentFileTest()
    {
        FileMetadata fileMetadata = new FileMetadata(Paths.get("/nonexistent/file"), "F999", "3");

        StepSpecification utSpec = new StepSpecification();
        utSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("temp_storage", "/testing/");
        utSpec.setProperties(properties);

        UnTarStep untar = new UnTarStep(utSpec);

        StepResult result = untar.runStep(fileMetadata);
        StepResult expResult = new StepResult(false, "3", fileMetadata);

        Assert.assertEquals(expResult.isSuccess(), result.isSuccess());
        Assert.assertEquals(expResult.getErrorCode(), result.getErrorCode());
        Assert.assertEquals(expResult.getCurrentFiles(), result.getCurrentFiles());
    }

    @Test
    public void UnTarStepReturnCorrectName()
    {
        StepSpecification utSpec = new StepSpecification();
        utSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("temp_storage", "/testing/");
        utSpec.setProperties(properties);

        UnTarStep untar = new UnTarStep(utSpec);

        Assert.assertEquals("untarring", untar.getName());
    }

}
