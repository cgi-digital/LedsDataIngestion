package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.healthchecks.checks.CategoryOneCheckResult;
import uk.gov.homeoffice.dpp.healthchecks.checks.ElementChecks;

/**
 * Created by M.Koskinas on 02/03/2017.
 */
public class ChannelDistinctionTest extends HCTestBuilder {


    @Test
    public void validateFTPSServerChannelsDistinctionTest()
    {
        CategoryOneCheckResult result = ElementChecks.validateFTPSServerChannelsDistinctions();
        Assert.assertTrue(result.isSuccess());
    }


}
