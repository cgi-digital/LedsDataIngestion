package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.healthchecks.checks.UpdategramHandler;
import uk.gov.homeoffice.dpp.healthchecks.checks.CategoryOneCheckResult;

import java.io.File;
import java.util.List;

/**
 * Created by M.Koskinas on 18/05/2017.
 */
public class AssociationRoleChecksTests extends HCTestBuilder
{
    private ClassLoader classLoader = getClass().getClassLoader();

    @Test
    public void validateAssociationRoleTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/AssociationRoleChecksTests/RecordBatchWithAssociation.xml").getFile());
        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file);

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_1000_100_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            if("C_ALL_1000_100_2".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/AssociationRoleChecksTests/RecordBatchWithAssociationInvalid.xml").getFile());
        results = UpdategramHandler.executeChecks(file);

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_1000_100_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/AssociationRoleChecksTests/RecordBatchWithAssociationInvalid2.xml").getFile());
        results = UpdategramHandler.executeChecks(file);

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_1000_100_2".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }
    }
}
