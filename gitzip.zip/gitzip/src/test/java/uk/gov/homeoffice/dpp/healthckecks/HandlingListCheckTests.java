package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.healthchecks.checks.CategoryOneCheckResult;
import uk.gov.homeoffice.dpp.healthchecks.checks.UpdategramHandler;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;

import java.io.File;
import java.util.List;

/**
 * Created by M.Koskinas on 21/04/2017.
 */
public class HandlingListCheckTests extends HCTestBuilder
{

    private ClassLoader classLoader = getClass().getClassLoader();

    @Test
    public void runCheckTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/HandlingListCheckTests/RecordBatch.xml").getFile());
        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file, FileMetadata.createEmptyMetadata(), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_1000_M010_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_1000_M020_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/HandlingListCheckTests/RecordBatchPandC.xml").getFile());
        results = UpdategramHandler.executeChecks(file, FileMetadata.createEmptyMetadata(), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_1000_M010_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_1000_M020_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/HandlingListCheckTests/RecordBatchInvalid.xml").getFile());
        results = UpdategramHandler.executeChecks(file, FileMetadata.createEmptyMetadata(), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_1000_M010_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
            else if("C_ALL_1000_M020_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/HandlingListCheckTests/RecordBatchInvalid2.xml").getFile());
        results = UpdategramHandler.executeChecks(file, FileMetadata.createEmptyMetadata(), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_1000_010_2".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/HandlingListCheckTests/RecordBatchInvalid3.xml").getFile());
        results = UpdategramHandler.executeChecks(file, FileMetadata.createEmptyMetadata(), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_1000_010_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/HandlingListCheckTests/RecordBatchInvalid4.xml").getFile());
        results = UpdategramHandler.executeChecks(file, FileMetadata.createEmptyMetadata(), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_1000_010_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }
    }
}
