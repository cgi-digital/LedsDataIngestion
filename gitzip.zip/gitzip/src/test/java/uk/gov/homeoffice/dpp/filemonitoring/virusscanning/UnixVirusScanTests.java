package uk.gov.homeoffice.dpp.filemonitoring.virusscanning;

import mockit.Expectations;
import mockit.Mocked;
import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.filemonitoring.FTPTestBuilder;
import uk.gov.homeoffice.dpp.filemonitoring.steps.StepSpecification;
import uk.gov.homeoffice.dpp.filemonitoring.virusscanning.UnixVirusScan;
import uk.gov.homeoffice.dpp.filemonitoring.virusscanning.VirusScan;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by C.Barnes on 12/04/2017.
 */
public class UnixVirusScanTests extends FTPTestBuilder {
    @Test
    public void RunVirusScanTest(@Mocked final ProcessBuilder pb, @Mocked final Process proc) throws IOException, InterruptedException {
        Path testFile = Paths.get("/testing/testfile.zip");

        StepSpecification defStepSpec = createDefaultVirusScanningStepSpec("Unix");
        UnixVirusScan unixVirus = new UnixVirusScan(defStepSpec);

        byte[] expectedInputStream = "This is the\nInput Stream".getBytes();
        byte[] expectedErrorStream = "This one is the\nError Stream".getBytes();
        final InputStream inputStream = new ByteArrayInputStream(expectedInputStream);
        final InputStream errorStream = new ByteArrayInputStream(expectedErrorStream);


        new Expectations() {
            {
                new ProcessBuilder((List<String>) any);
                pb.start();
                result = proc;
            }
            {
                proc.getInputStream();
                result = inputStream;}
            {
                proc.getErrorStream();
                result = errorStream;}
            {
                proc.waitFor();
                result = 0;
            }
        };

        List<String> result = unixVirus.runVirusScan(testFile);

        List<String> expResults = new ArrayList<>();
        expResults.add("This is the");
        expResults.add("Input Stream");
        expResults.add("This one is the");
        expResults.add("Error Stream");

        Assert.assertTrue("Not returning the expected input stream and error stream", expResults.equals(result));
    }

    @Test
    public void ReturnResultSummaryTest()
    {
        StepSpecification defStepSpec = createDefaultVirusScanningStepSpec("Unix");
        UnixVirusScan unixVirus = new UnixVirusScan(defStepSpec);

        List<String> virusScanOutput = new ArrayList<>();
        virusScanOutput.add("Possibly Infected:...... 1");
        virusScanOutput.add("Not Scanned:....... 2");
        virusScanOutput.add("Clean:........ 3");

        unixVirus.setVsOutput(virusScanOutput);

        Map<VirusScan.VirusScanResultType, Integer> result =  unixVirus.returnResultSummary();

        Map<VirusScan.VirusScanResultType, Integer> expResult = new HashMap<>();
        expResult.put(VirusScan.VirusScanResultType.POSSIBLY_INFECTED, 1);
        expResult.put(VirusScan.VirusScanResultType.NOT_SCANNED, 2);
        expResult.put(VirusScan.VirusScanResultType.CLEAN, 3);

        Assert.assertTrue("Did not gather the expected virus scan results from given input", result.equals(expResult));
    }

    @Test
    public void ReturnResultSummaryWhenVirusScanResultIsEmptyTest()
    {
        StepSpecification defStepSpec = createDefaultVirusScanningStepSpec("Unix");
        UnixVirusScan unixVirus = new UnixVirusScan(defStepSpec);

        Map<VirusScan.VirusScanResultType, Integer> result =  unixVirus.returnResultSummary();

        Assert.assertTrue("Should have given a null return", result == null);
    }

    @Test
    public void ReturnResultSummaryWhenLargeVirusScanResultTest()
    {
        StepSpecification defStepSpec = createDefaultVirusScanningStepSpec("Unix");
        UnixVirusScan unixVirus = new UnixVirusScan(defStepSpec);

        List<String> virusScanOutput = new ArrayList<>();
        for(int i = 0; i < 50; i++)
        {
            virusScanOutput.add("awelfjowaeijfowiejf");
        }
        virusScanOutput.add("Possibly Infected:...... 1");
        virusScanOutput.add("Not Scanned:....... 2");
        virusScanOutput.add("Clean:........ 3");

        unixVirus.setVsOutput(virusScanOutput);

        Map<VirusScan.VirusScanResultType, Integer> result =  unixVirus.returnResultSummary();

        Map<VirusScan.VirusScanResultType, Integer> expResult = new HashMap<>();
        expResult.put(VirusScan.VirusScanResultType.POSSIBLY_INFECTED, 1);
        expResult.put(VirusScan.VirusScanResultType.NOT_SCANNED, 2);
        expResult.put(VirusScan.VirusScanResultType.CLEAN, 3);

        Assert.assertTrue("Did not gather the expected virus scan results from given input", result.equals(expResult));
    }

    @Test
    public void CreateVirusScanCommandWithNoReportGenerationTest(){
        Path testFile = Paths.get("This/Is/A/Test/File.zip");

        String virusScanPath = "/virusScan/Path";
        String reportLoc = "/report/location";
        String quarantineLoc = "/quarantine/location";

        StepSpecification stepSpec = new StepSpecification();
        stepSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("quarantine_location", quarantineLoc);
        properties.put("report_location", reportLoc);
        properties.put("Windows/Unix", "Unix");
        properties.put("virusscan_path", virusScanPath);
        properties.put("generate_xmlreport", "False");
        properties.put("generate_textreport", "False");
        stepSpec.setProperties(properties);

        UnixVirusScan unixVirus = new UnixVirusScan(stepSpec);


        ProcessBuilder result = unixVirus.createVirusScanCommand(testFile);

        List<String> expCommands = new ArrayList<>();
        expCommands.add(Paths.get(virusScanPath).toString());
        expCommands.add("--unzip");
        expCommands.add("-m");
        expCommands.add(Paths.get(quarantineLoc).toString());
        expCommands.add("--summary");
        expCommands.add(testFile.toString());

        Assert.assertTrue("The resulting command was not as expected", result.command().equals(expCommands));
    }

    @Test
    public void CreateVirusScanCommandWithXMLReportGenerationTest(){
        Path testFile = Paths.get("This/Is/A/Test/File.zip");

        String virusScanPath = "/virusScan/Path";
        String reportLoc = "/report/location";
        String quarantineLoc = "/quarantine/location";

        StepSpecification stepSpec = new StepSpecification();
        stepSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("quarantine_location", quarantineLoc);
        properties.put("report_location", reportLoc);
        properties.put("Windows/Unix", "Unix");
        properties.put("virusscan_path", virusScanPath);
        properties.put("generate_xmlreport", "True");
        properties.put("generate_textreport", "False");
        stepSpec.setProperties(properties);

        UnixVirusScan unixVirus = new UnixVirusScan(stepSpec);


        ProcessBuilder result = unixVirus.createVirusScanCommand(testFile);

        List<String> expCommands = new ArrayList<>();
        Path wholeXMLReportPath = Paths.get(reportLoc + "/" + testFile.getFileName().toString() + ".xml");

        expCommands.add(Paths.get(virusScanPath).toString());
        expCommands.add("--unzip");
        expCommands.add("--rptall");
        expCommands.add("--rptcor");
        expCommands.add("--rpterr");
        expCommands.add("--xmlpath");
        expCommands.add(wholeXMLReportPath.toString());
        expCommands.add("-m");
        expCommands.add(Paths.get(quarantineLoc).toString());
        expCommands.add("--summary");
        expCommands.add(testFile.toString());

        Assert.assertTrue("The resulting command was not as expected", result.command().equals(expCommands));
    }

    @Test
    public void CreateVirusScanCommandWithTextReportGenerationTest(){
        Path testFile = Paths.get("This/Is/A/Test/File.zip");

        String virusScanPath = "/virusScan/Path";
        String reportLoc = "/report/location";
        String quarantineLoc = "/quarantine/location";

        StepSpecification stepSpec = new StepSpecification();
        stepSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("quarantine_location", quarantineLoc);
        properties.put("report_location", reportLoc);
        properties.put("Windows/Unix", "Unix");
        properties.put("virusscan_path", virusScanPath);
        properties.put("generate_xmlreport", "False");
        properties.put("generate_textreport", "True");
        stepSpec.setProperties(properties);

        UnixVirusScan unixVirus = new UnixVirusScan(stepSpec);


        ProcessBuilder result = unixVirus.createVirusScanCommand(testFile);

        List<String> expCommands = new ArrayList<>();
        Path wholeTextReportPath = Paths.get(reportLoc + "/" + testFile.getFileName().toString() + ".report");

        expCommands.add(Paths.get(virusScanPath).toString());
        expCommands.add("--unzip");
        expCommands.add("--rptall");
        expCommands.add("--rptcor");
        expCommands.add("--rpterr");
        expCommands.add("--report");
        expCommands.add(wholeTextReportPath.toString());
        expCommands.add("-m");
        expCommands.add(Paths.get(quarantineLoc).toString());
        expCommands.add("--summary");
        expCommands.add(testFile.toString());

        Assert.assertTrue("The resulting command was not as expected", result.command().equals(expCommands));
    }

    @Test
    public void CreateVirusScanCommandWithAllReportGenerationTest(){
        Path testFile = Paths.get("This/Is/A/Test/File.zip");

        String virusScanPath = "/virusScan/Path";
        String reportLoc = "/report/location";
        String quarantineLoc = "/quarantine/location";

        StepSpecification stepSpec = new StepSpecification();
        stepSpec.setStatus(true);
        HashMap<String, String> properties = new HashMap<>();
        properties.put("quarantine_location", quarantineLoc);
        properties.put("report_location", reportLoc);
        properties.put("Windows/Unix", "Unix");
        properties.put("virusscan_path", virusScanPath);
        properties.put("generate_xmlreport", "True");
        properties.put("generate_textreport", "True");
        stepSpec.setProperties(properties);

        UnixVirusScan unixVirus = new UnixVirusScan(stepSpec);


        ProcessBuilder result = unixVirus.createVirusScanCommand(testFile);

        List<String> expCommands = new ArrayList<>();
        Path wholeTextReportPath = Paths.get(reportLoc + "/" + testFile.getFileName().toString() + ".report");
        Path wholeXMLReportPath = Paths.get(reportLoc + "/" + testFile.getFileName().toString() + ".xml");

        expCommands.add(Paths.get(virusScanPath).toString());
        expCommands.add("--unzip");
        expCommands.add("--rptall");
        expCommands.add("--rptcor");
        expCommands.add("--rpterr");
        expCommands.add("--xmlpath");
        expCommands.add(wholeXMLReportPath.toString());
        expCommands.add("--report");
        expCommands.add(wholeTextReportPath.toString());
        expCommands.add("-m");
        expCommands.add(Paths.get(quarantineLoc).toString());
        expCommands.add("--summary");
        expCommands.add(testFile.toString());

        Assert.assertTrue("The resulting command was not as expected", result.command().equals(expCommands));
    }
}
