package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.healthchecks.xmlparser.XMLParser;

import java.io.File;

/**
 * Created by M.Koskinas on 10/04/2017.
 */
public class XMLParserTests extends HCTestBuilder
{
    private ClassLoader classLoader = getClass().getClassLoader();
    private XMLParser xmlParser = new XMLParser();

    @Test
    public void getFileTypeTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/AttachmentBatch.xml").getFile());
        String fileType = xmlParser.getFileType(file);
        Assert.assertTrue(fileType.equals(XMLParser.ATTATCHMENTBATCH_TAG));

        file = new File(classLoader.getResource("XSDTestFiles/EventBatch.xml").getFile());
        fileType = xmlParser.getFileType(file);
        Assert.assertTrue(fileType.equals(XMLParser.EVENTBATCH_TAG));

        file = new File(classLoader.getResource("XSDTestFiles/RecordBatch.xml").getFile());
        fileType = xmlParser.getFileType(file);
        Assert.assertTrue(fileType.equals(XMLParser.RECORDBATCH_TAG));

        file = new File(classLoader.getResource("XSDTestFiles/CLMS_Context.xml").getFile());
        fileType = xmlParser.getFileType(file);
        Assert.assertTrue(fileType.equals(XMLParser.CLMS_CONTEXT_TAG));

        file = new File(classLoader.getResource("XSDTestFiles/CLMS_ContextMap.xml").getFile());
        fileType = xmlParser.getFileType(file);
        Assert.assertTrue(fileType.equals(XMLParser.CLMS_CONTEXTMAP_TAG));

        //Errors
        file = new File(classLoader.getResource("XSDTestFiles/CLMS_Context_TypeError.xml").getFile());
        fileType = xmlParser.getFileType(file);
        Assert.assertTrue(fileType == null);

        file = new File(classLoader.getResource("XSDTestFiles/CLMS_ContextMap_TypeError.xml").getFile());
        fileType = xmlParser.getFileType(file);
        Assert.assertTrue(fileType == null);

        file = new File(classLoader.getResource("XSDTestFiles/TypeError.xml").getFile());
        fileType = xmlParser.getFileType(file);
        Assert.assertTrue(fileType == null);
    }

    @Test
    public void validateFileTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/AttachmentBatch.xml").getFile());
        Assert.assertTrue(xmlParser.validateFile(file,XMLParser.ATTATCHMENTBATCH_TAG));

        file = new File(classLoader.getResource("XSDTestFiles/EventBatch.xml").getFile());
        Assert.assertTrue(xmlParser.validateFile(file,XMLParser.EVENTBATCH_TAG));

        file = new File(classLoader.getResource("XSDTestFiles/RecordBatch.xml").getFile());
        Assert.assertTrue(xmlParser.validateFile(file,XMLParser.RECORDBATCH_TAG));

        file = new File(classLoader.getResource("XSDTestFiles/CLMS_Context.xml").getFile());
        Assert.assertTrue(xmlParser.validateFile(file,XMLParser.CLMS_CONTEXT_TAG));

        file = new File(classLoader.getResource("XSDTestFiles/CLMS_ContextMap.xml").getFile());
        Assert.assertTrue(xmlParser.validateFile(file,XMLParser.CLMS_CONTEXTMAP_TAG));

        //Errors
        file = new File(classLoader.getResource("XSDTestFiles/RecordBatchDataError.xml").getFile());
        Assert.assertFalse(xmlParser.validateFile(file,XMLParser.RECORDBATCH_TAG));

        file = new File(classLoader.getResource("XSDTestFiles/EventBatchDataError.xml").getFile());
        Assert.assertFalse(xmlParser.validateFile(file,XMLParser.EVENTBATCH_TAG));
    }

}
