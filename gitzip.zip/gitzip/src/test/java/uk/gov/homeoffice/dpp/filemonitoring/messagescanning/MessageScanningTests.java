package uk.gov.homeoffice.dpp.filemonitoring.messagescanning;

import mockit.Expectations;
import mockit.Injectable;
import mockit.Mocked;
import mockit.Tested;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.springframework.context.ApplicationContext;
import uk.gov.homeoffice.dpp.filemonitoring.messagescanning.MessageProcessing;
import uk.gov.homeoffice.dpp.filemonitoring.messagescanning.MessageScanning;

import java.io.File;
import java.io.IOException;

/**
 * Created by C.Barnes on 21/04/2017.
 */
public class MessageScanningTests {

    @Injectable
    private ApplicationContext applicationContext;

    @Tested
    private MessageScanning messageScanning = new MessageScanning();

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Test(timeout = 1000)
    public void startScanningWithExitTriggerTest(@Mocked MessageProcessing msgProc) throws IOException {

        File message1 = tempFolder.newFile("1234.exit");

        File message2 = tempFolder.newFile("1234.process.testmessage2");

        File message3 = tempFolder.newFile("4321.process.testmessage");


        new Expectations(File.class){
            {
                applicationContext.getBean(anyString);
                result = msgProc; times = 1;
            }
            {
                msgProc.processMessageList((File[]) any);
                result = false; times = 1;
            }

        };

        messageScanning.startScanning(new File(message1.getParent()), "1234");
    }

    @Test(timeout = 1000)
    public void startScanningWithGoTriggerTest(@Mocked MessageProcessing msgProc) throws IOException {

        File message1 = tempFolder.newFile("ALL.exit");

        File message2 = tempFolder.newFile("1234.process.testmessage2");

        File message3 = tempFolder.newFile("4321.process.testmessage");


        new Expectations(File.class){
            {
                applicationContext.getBean(anyString);
                result = msgProc; times = 1;
            }
            {
                msgProc.processMessageList((File[]) any);
                result = false; times = 1;
            }

        };

        messageScanning.startScanning(new File(message1.getParent()), "1234");
    }


}
