package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.healthchecks.checks.CategoryOneCheckResult;
import uk.gov.homeoffice.dpp.healthchecks.checks.UpdategramHandler;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;

import java.io.File;
import java.util.List;

/**
 * Created by M.Koskinas on 21/04/2017.
 */
public class MessageHeaderCheckTests extends HCTestBuilder
{

    private ClassLoader classLoader = getClass().getClassLoader();

    @Test
    public void runCheckTest()
    {
        File file = new File(classLoader.getResource("XSDTestFiles/MessageHeaderTests/RecordBatch.xml").getFile());
        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file, FileMetadata.createEmptyMetadata(), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_0020_040_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
            else if("C_ALL_0020_030_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertTrue(results.get(r).isSuccess());
            }
        }

        file = new File(classLoader.getResource("XSDTestFiles/MessageHeaderTests/RecordBatchInvalid.xml").getFile());
        results = UpdategramHandler.executeChecks(file,FileMetadata.createEmptyMetadata(), new UpdategramStats());

        for(int r = 0 ; r < results.size() ; r++)
        {
            if("C_ALL_0020_040_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
            else if("C_ALL_0020_030_1".equals(results.get(r).getCheckName()))
            {
                Assert.assertFalse(results.get(r).isSuccess());
            }
        }
    }
}
