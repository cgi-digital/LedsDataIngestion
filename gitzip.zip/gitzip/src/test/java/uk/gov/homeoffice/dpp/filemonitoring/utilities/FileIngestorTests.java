package uk.gov.homeoffice.dpp.filemonitoring.utilities;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FTPTestBuilder;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by C.Barnes on 03/04/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {FTPManagerConfiguration.class})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class FileIngestorTests  extends FTPTestBuilder {

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    FileMetadata meta;
    Path tempLoc, file;

    @Before
    public void BeforeFileIngestorTests() throws IOException {
        tempFolder.newFolder("Testing");
        tempLoc = tempFolder.newFolder("Testing", "temp").toPath();
        file = tempFolder.newFile("Testing/test.txt").toPath();
        FTPManagerConfiguration.setTemp_storage(tempLoc.getParent().toString());
        FTPManagerConfiguration.setTemp_storage_name(tempLoc.getFileName().toString());

        meta = new FileMetadata(file, "F999", "3");
    }


    @Test
    public void PrepareFileForLoadingTest()
    {
        boolean result = FileIngestor.prepareFileForLoading(meta);

        Assert.assertTrue(result);
        Assert.assertTrue(Paths.get(tempLoc.toString() + "/" + meta.getCurrentPath().getFileName().toString()).toFile().exists());
    }

    @Test
    public void PrepareFileForLoadingAndCheckGUIDHasBeenPopulatedAndRenamedTest()
    {
        FileIngestor.prepareFileForLoading(meta);

        Assert.assertTrue(meta.getGuid() != null);
        Assert.assertEquals(meta.getGuid().toString() + ".txt", meta.getCurrentPath().getFileName().toString());
    }

    @Test
    public void PrepareFileForLoadingWithNonExistingFileTest()
    {
        FileMetadata nonExistantFile = new FileMetadata(Paths.get("/Does/Not/Exist"), "F999", "3");

        boolean result = FileIngestor.prepareFileForLoading(nonExistantFile);

        Assert.assertFalse(result);
    }

    @Test
    public void LogInitialMetadataTest() throws UnknownHostException {
        Date before = new Date();
        FileIngestor.populateInitialMetadata(meta);

        InetAddress thisIPAddress = InetAddress.getLocalHost();

        Assert.assertEquals(file.toString(), meta.getOriginalFilePath());
        Assert.assertTrue(meta.getLandingDate().after(before) || meta.getLandingDate().toString().equals(before.toString()));
        Assert.assertEquals(thisIPAddress, meta.getIpAddress());
    }

    @Test
    public void LogInitialMetadataWhenValuesAlreadyExistTest() throws UnknownHostException {
        Calendar date = Calendar.getInstance();
        date.set(Calendar.YEAR, 1994);
        date.set(Calendar.MONTH, 6);
        date.set(Calendar.DAY_OF_MONTH, 20);
        Date past = date.getTime();
        meta.setLandingDate(past);

        String originalFilePath = "This/Should/Not/Change";
        meta.setOriginalFilePath(originalFilePath);

        InetAddress expAddress = InetAddress.getByName("0.0.0.0");
        meta.setIpAddress(expAddress);

        FileIngestor.populateInitialMetadata(meta);

        Assert.assertEquals(0, past.compareTo(meta.getLandingDate()));
        Assert.assertEquals(originalFilePath, meta.getOriginalFilePath());
        Assert.assertEquals(expAddress, meta.getIpAddress());

    }

}
