package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.healthchecks.functions.FileStatsUtilities;

import java.io.File;
import java.io.IOException;

/**
 * Created by M.Koskinas on 23/03/2017.
 */
public class FileStatsUtilitiesTest {

    private String txtFileName = "sampleFile.xml";
    private ClassLoader classLoader = getClass().getClassLoader();

    @Test
    public void getFileSizeTest()
    {
        File file = new File(classLoader.getResource(txtFileName).getFile());
        long size = FileStatsUtilities.getFileSize(file);

        Assert.assertEquals(size,9);
    }

    @Test
    public void getFileChecksumTest() throws IOException {
        File file = new File(classLoader.getResource(txtFileName).getFile());

        String checksum = FileStatsUtilities.getFileChecksum(file);

        Assert.assertEquals(checksum,"2e1e0edc92942f1a943cd14987cd87a84afebc95");
    }
}
