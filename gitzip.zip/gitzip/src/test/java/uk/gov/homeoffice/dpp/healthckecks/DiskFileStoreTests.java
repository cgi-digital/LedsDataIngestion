package uk.gov.homeoffice.dpp.healthckecks;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.homeoffice.dpp.configuration.HealthChecksConfiguration;
import uk.gov.homeoffice.dpp.healthchecks.filestore.DiskFileStore;
import uk.gov.homeoffice.dpp.healthchecks.filestore.FileStore;
import uk.gov.homeoffice.dpp.healthchecks.filestore.FileStoreFactory;
import uk.gov.homeoffice.dpp.healthchecks.filestore.FileStoreSpecification;

import java.io.File;
import java.io.IOException;

/**
 * Created by M.Koskinas on 30/05/2017.
 */
public class DiskFileStoreTests extends HCTestBuilder
{
    private ClassLoader classLoader = getClass().getClassLoader();

    @Test
    public void fileStoreFactoryTest() throws IOException {
        FileStoreSpecification specification = new FileStoreSpecification();
        specification.setLocation(HealthChecksConfiguration.filestore.getLocation());

        specification.setType("disk");

        FileStore store = FileStoreFactory.createFileStore(specification);
        Assert.assertTrue(store.getClass().isAssignableFrom(DiskFileStore.class));

        specification.setType("invalidType");
        store = FileStoreFactory.createFileStore(specification);
        Assert.assertTrue(store.getClass().isAssignableFrom(DiskFileStore.class));
    }

    @Test
    public void diskFileStoringTest() throws IOException {

        FileStoreSpecification specification = new FileStoreSpecification();
        specification.setLocation(HealthChecksConfiguration.filestore.getLocation());
        specification.setType("disk");

        FileStore store = FileStoreFactory.createFileStore(specification);

        File file = new File(classLoader.getResource("XSDTestFiles/RecordBatch.xml").getFile());

        String finalLocation = store.storeFile(file,null,true);
        File touchedFile = new File(HealthChecksConfiguration.filestore.getLocation()+File.separator+file.getName());
        Assert.assertTrue(touchedFile.exists());
        Assert.assertTrue(finalLocation!=null);

        finalLocation = store.storeFile(file,"subdir",true);
        Assert.assertTrue(touchedFile.exists());
        Assert.assertTrue(finalLocation!=null);

        finalLocation = store.storeFile(null,"subdir",true);
        Assert.assertFalse(finalLocation!=null);

        finalLocation = store.storeFile(file,"subdir",false);
        Assert.assertTrue(finalLocation!=null);
        Assert.assertTrue(finalLocation.contains(DiskFileStore.FAILED_FILES_DIRECTORY_NAME));
    }

    @Test
    public void diskFileRetrievingTest() throws IOException
    {
        FileStoreSpecification specification = new FileStoreSpecification();
        specification.setLocation(HealthChecksConfiguration.filestore.getLocation());
        specification.setType("disk");

        FileStore store = FileStoreFactory.createFileStore(specification);

        File file = new File(classLoader.getResource("XSDTestFiles/RecordBatch.xml").getFile());

        String finalLocation = store.storeFile(file,null,true);
        File touchedFile = new File(HealthChecksConfiguration.filestore.getLocation()+File.separator+file.getName());
        Assert.assertTrue(touchedFile.exists());
        Assert.assertTrue(finalLocation!=null);

        Assert.assertTrue(store.retrieveFile(touchedFile.getAbsolutePath()) != null );

        touchedFile = new File(HealthChecksConfiguration.filestore.getLocation()+File.separator+"DOESN'T_EXIST"+file.getName());
        Assert.assertTrue(store.retrieveFile(touchedFile.getAbsolutePath()) == null );
    }

}
