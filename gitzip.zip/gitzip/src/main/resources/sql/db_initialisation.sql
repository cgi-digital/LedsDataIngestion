CREATE ROLE dataingestion WITH PASSWORD 'dataingestion' CREATEDB CREATEROLE;
CREATE DATABASE dataingestion;
\connect dataingestion;
CREATE SCHEMA ho_preprocessor;
