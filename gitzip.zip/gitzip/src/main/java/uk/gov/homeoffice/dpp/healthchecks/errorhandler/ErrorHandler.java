package uk.gov.homeoffice.dpp.healthchecks.errorhandler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.FileError;
import uk.gov.homeoffice.dpp.healthchecks.persistence.services.*;

import java.util.List;

/**
 * Created by C.Barnes on 27/05/2017.
 */
public class ErrorHandler {

    private static final Logger logger = LoggerFactory.getLogger(ErrorHandler.class);

    @Autowired
    FileErrorService fileErrorService;

    public List<FileError> createFileErrorsAndClearList(List<FileError> listOfErrors)
    {
        for(FileError error : listOfErrors)
        {
            try {
                fileErrorService.createFileError(error);
            }
            catch (Exception e)
            {
                logger.error("Was unable to load a file error from the list, moving onto the next (if any)",e);
            }
        }

        listOfErrors.clear();

        return listOfErrors;
    }


}
