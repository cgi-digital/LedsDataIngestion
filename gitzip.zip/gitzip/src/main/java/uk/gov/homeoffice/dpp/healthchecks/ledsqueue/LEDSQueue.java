package uk.gov.homeoffice.dpp.healthchecks.ledsqueue;


import com.rabbitmq.client.AlreadyClosedException;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPFile;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

/**
 * Created by C.Barnes on 17/05/2017.
 */
public class LEDSQueue {

    private static final Logger logger = LoggerFactory.getLogger(LEDSQueue.class);

    private final static String QUEUE_NAME = "LEDS";

    private Connection connection = null;
    private String queueName;

    public LEDSQueue(String host, int port, String user, String password, String queueName) {
        logger.info("Connecting to LEDS queue server {}...", host);
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost(host);
        factory.setPort(port);
        factory.setUsername(user);
        factory.setPassword(password);
        this.queueName = queueName;
        try {
            connection = factory.newConnection();
        } catch (IOException e) {
            logger.error("There was a problem when trying to open a connection to {}", host, e);
        } catch (TimeoutException e) {
            logger.error("There was a timeout issue when trying to open a connection to {}", host, e);
        }
    }

    public void send(DPPFile file, UpdategramStats stats)
    {
        logger.info("Sending message to the LEDS Queue");
        Channel channel = null;
        LEDSMessage message = new LEDSMessage(file, stats);
        String formattedMsg = message.extractInfoIntoJSON();

        try {
            channel = connection.createChannel();
            channel.basicPublish("", queueName, null, formattedMsg.getBytes());
            System.out.println(" [x] Message Sent '" + formattedMsg + "'");
        } catch (IOException e) {
            logger.error("Error when trying to send a message to the LEDS queue {}", queueName, e);
        }

        if(channel != null) {
            try {
                channel.close();
            } catch (IOException e) {
                logger.error("Error when trying to close the channel to LEDS queue {}", queueName, e);
            } catch (TimeoutException e) {
                logger.error("Timeout error when trying to close the channel to LEDS queue {}", queueName, e);
            }catch (AlreadyClosedException e)
            {
                logger.error("Trying to close the channel to LEDS queue {} when it is already closed", queueName, e);
            }
        }
        logger.info("Message successfully sent to the LEDS Queue");
    }

    public void send(DPPFile file)
    {
        Channel channel = null;
        LEDSMessage message = new LEDSMessage(file);
        String formattedMsg = message.extractInfoIntoJSON();

        try {
            channel = connection.createChannel();
            channel.basicPublish("", queueName, null, formattedMsg.getBytes());
            System.out.println(" [x] Sent '" + formattedMsg + "'");
        } catch (IOException e) {
            logger.error("Error when trying to send a message to the LEDS queue {}", queueName, e);
        }

        if(channel != null) {
            try {
                channel.close();
            } catch (IOException e) {
                logger.error("Error when trying to close the channel to LEDS queue {}", queueName, e);
            } catch (TimeoutException e) {
                logger.error("Timeout error when trying to close the channel to LEDS queue {}", queueName, e);
            }catch (AlreadyClosedException e)
            {
                logger.error("Trying to close the channel to LEDS queue {} when it is already closed", queueName, e);
            }
        }
    }

    public void close()
    {
        if(!connection.isOpen())
            return;

        try {
            connection.close();
        } catch (IOException e) {
            logger.error("Error when trying to close the connection to message queue server on {}", connection.getAddress(), e);
        } catch (AlreadyClosedException e)
        {
            logger.error("Error when connection to LEDS queue on {} was already closed", connection.getAddress(), e);
        }
    }

    public Connection getConnection() {
        return connection;
    }
}
