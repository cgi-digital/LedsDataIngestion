package uk.gov.homeoffice.dpp.healthchecks.steps;

import java.util.Map;

/**
 * Created by koskinasm on 27/02/2017.
 */
public final class StepResult {

    private boolean success;
    private String errorCode;
    private Map<String,String> errors;

    public StepResult(boolean success, String errorCode, Map<String,String> errors)
    {
        this.success = success;
        this.errorCode = errorCode;
        this.errors = errors;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public Map<String,String> getErrors()
    {
        return this.errors;
    }
}
