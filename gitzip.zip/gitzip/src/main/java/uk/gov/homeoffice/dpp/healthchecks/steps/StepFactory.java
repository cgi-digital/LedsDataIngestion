package uk.gov.homeoffice.dpp.healthchecks.steps;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static uk.gov.homeoffice.dpp.healthchecks.error.ErrorMsg.ERR0006;

/**
 * Created by koskinasm on 27/02/2017.
 */
public class StepFactory {

    private static final Logger logger = LoggerFactory.getLogger(StepFactory.class);

    /**
     * Creates an appropriate Step based on the provided name and instantiated according to the provided StepSpecification
     *
     * @param name the name of the Step type
     * @param stepSpecification the details based on which the Step will be instantiated
     *
     * @return <code>Step</code> the generated Step object
     *
     * @see Step
     * @see StepSpecification
     * */
    public static Step createCheck(String name, StepSpecification stepSpecification)
    {
        Step step = null;

        if("schema_validation".equals(name))
        {
            step = new SchemaValidationStep(stepSpecification);
        }
        else if("category_one_checks".equals(name))
        {
            step = new CategoryOneChecksStep(stepSpecification);
        }
        else if("rename_to_finished".equals(name))
        {
            step = new RenameToFinishedStep(stepSpecification);
        }
        else
        {
            logger.error(ERR0006.getValue(), name);
        }

        return step;
    }
}
