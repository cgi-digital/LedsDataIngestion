package uk.gov.homeoffice.dpp.healthchecks.steps;

import java.util.Map;

/**
 * Specification object for the various Checks. This class holds the information needed to instantiate a Step object
 */
public class StepSpecification
{
    private boolean status;

    private Map<String,String> properties;

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Map<String, String> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, String> properties) {
        this.properties = properties;
    }

}
