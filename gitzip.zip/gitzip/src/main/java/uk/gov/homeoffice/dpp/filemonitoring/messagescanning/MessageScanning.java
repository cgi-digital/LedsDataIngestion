package uk.gov.homeoffice.dpp.filemonitoring.messagescanning;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * This class scans a folder for messages indefinitely
 * until it is sent a message to exit, which will be picked up
 * and relayed to this class by {@link MessageProcessing}
 * Created by C.Barnes on 20/04/2017.
 */
@Component
public class MessageScanning {

    private static final Logger logger = LoggerFactory.getLogger(MessageScanning.class);

    private static final String IDLE_FILE_LABEL = ".IDLE";
    protected static final String ALL_EXIT_MESSAGE = "ALL.EXIT";
    private static final String TRIGGER_LABEL = ".GO";

    @Autowired
    ApplicationContext context;

    @Value("${ftpManager.configuration.scan_sleep_secs}")
    long SLEEP_TIME;

    public MessageScanning()
    {

    }

    /**
     * Kicks off the scanning of a directory. This
     * class will continue to scan until one of the messages
     * that is sent to the {@link MessageProcessing} class contains
     * an exit message. The messages it looks at are those beginning with
     * <processID>.*
     * @param dirToScan Directory that will contain the messages
     * @param processID Given ID to the program. Used to pick up messages.
     */
    public void startScanning(File dirToScan, String processID) {

        FilenameFilter triggerFilter = (dir, name) -> (name.toUpperCase().contains(processID + TRIGGER_LABEL)) || (ALL_EXIT_MESSAGE.equalsIgnoreCase(name)) || (name.toUpperCase().contains(processID + ".EXIT")) ;

        FilenameFilter fileFilter = (dir, name) -> nameFilter(processID, name);

        boolean continueScanning = true;

        logger.info("Process {} has started scanning for messages in {} and is awaiting a trigger message", processID, dirToScan);

        while (continueScanning) {

            File[] triggerFile = dirToScan.listFiles(triggerFilter);


            if(triggerFile != null && triggerFile.length > 0)
            {
                logger.info("Trigger found, gathering messages for process {}", processID);
                continueScanning = triggerFound(dirToScan, processID, fileFilter);
            }
            else{
                createIdleFile(dirToScan, processID);
                try {
                    logger.info("Sleeping for {} seconds", SLEEP_TIME);
                    Thread.sleep(SLEEP_TIME * 1000);
                } catch (InterruptedException e) {
                    logger.error("Error while sleeping", e);
                    deleteIdleFile(dirToScan, processID);
                    Thread.currentThread().interrupt();
                }
            }

        }

        logger.info("Process {} is exiting", processID, dirToScan);
    }

    private boolean triggerFound(File dirToScan, String processID, FilenameFilter fileFilter)
    {
        boolean continueScanning = true;
        File[] files = dirToScan.listFiles(fileFilter);

        if(files == null ||files.length == 0)
        {
            logger.error("No messages found for process {}, removing trigger and returning to idle.", processID);
        }
        else{
            deleteIdleFile(dirToScan, processID);
            MessageProcessing processMsgs = (MessageProcessing) context.getBean("MessageProcessing");
            continueScanning = processMsgs.processMessageList(files);
        }

        deleteTriggerFile(dirToScan, processID);

        return continueScanning;
    }

    private void deleteTriggerFile(File dirToDeleteTriggerFile, String processID) {

        Path triggerFile = getTriggerFile(dirToDeleteTriggerFile, processID);

        if(!triggerFile.toFile().exists())
            return;

        if(triggerFile.toFile().getName().equals(ALL_EXIT_MESSAGE))
            return;

        try {
            Files.delete(triggerFile);
        } catch (IOException e) {
            logger.error("Could not delete the trigger file for process ({}) in location ({})", processID, dirToDeleteTriggerFile.getPath(), e);
        }

    }

    private Path getTriggerFile(File dirOfTriggerFile, String processID) {
        return Paths.get(dirOfTriggerFile.getPath() + "/" + processID + TRIGGER_LABEL);
    }

    private boolean nameFilter(String processID, String name)
    {
        return (name.startsWith(processID + ".") || name.toUpperCase().startsWith(ALL_EXIT_MESSAGE)) && !name.toUpperCase().contains(IDLE_FILE_LABEL) && !name.toUpperCase().contains(TRIGGER_LABEL);
    }

    private void deleteIdleFile(File dirToDeleteIdleFile, String processID) {

        Path idleFile = getIdleFile(dirToDeleteIdleFile, processID);

        if(!idleFile.toFile().exists())
            return;

        try {
            Files.delete(idleFile);
        } catch (IOException e) {
            logger.error("Could not delete the idle file for process ({}) in location ({})", processID, dirToDeleteIdleFile.getPath(), e);
        }
    }

    private void createIdleFile(File dirToPlaceIdleFile, String processID) {

        Path idleFile = getIdleFile(dirToPlaceIdleFile, processID);

        if(idleFile.toFile().exists())
            return;

        try {
            Files.createFile(idleFile);
        } catch (IOException e) {
            logger.error("Could not create the idle file for process ({}) in location ({})", processID, dirToPlaceIdleFile.getPath(), e);
        }

    }

    private Path getIdleFile(File dirOfIdleFile, String processID)
    {
        return Paths.get(dirOfIdleFile.getPath() + "/" + processID + IDLE_FILE_LABEL);
    }

}
