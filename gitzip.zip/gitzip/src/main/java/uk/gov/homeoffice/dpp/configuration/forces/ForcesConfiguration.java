package uk.gov.homeoffice.dpp.configuration.forces;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * Created by C.Barnes on 12/07/2017.
 */
@Configuration
@ConfigurationProperties(prefix = "force")
public class ForcesConfiguration {

    public static Map<String, ForceProperties> forceList;

    public Map<String, ForceProperties> getForceList() {
        return forceList;
    }

    public void setForceList(Map<String, ForceProperties> forceList) {
        ForcesConfiguration.forceList = forceList;
    }

}
