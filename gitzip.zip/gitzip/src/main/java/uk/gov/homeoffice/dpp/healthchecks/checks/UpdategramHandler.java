package uk.gov.homeoffice.dpp.healthchecks.checks;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;
import uk.gov.homeoffice.dpp.healthchecks.xmlparser.XMLParser;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by M.Koskinas on 04/05/2017.
 */
public final class UpdategramHandler
{
    private static Map<String,Map<String,String>> fileValues = new HashMap<>();

    /***
     * Executes all Cat 1 checks against the provided file
     * Gathers useful statistics while parsing the provided file
     *
     * @param file
     * @return <code>List<CategoryOneCheckResult></code> the results of all individual tests execution
     */
    public static List<CategoryOneCheckResult> executeChecks(File file)
    {
        return executeChecks(file,FileMetadata.createEmptyMetadata(),new UpdategramStats());
    }

    public static List<CategoryOneCheckResult> executeChecks(File file, FileMetadata fileMetadata, UpdategramStats stats)
    {
        List<CategoryOneCheckResult> results = new ArrayList<>();
        //this check is not related to any file
        results.add(ElementChecks.validateFTPSServerChannelsDistinctions());
        results.add(ElementChecks.checkFileEncoding(file));

        String filetype = XMLParser.getFileType(file);

        if(filetype.equals(XMLParser.ATTATCHMENTBATCH_TAG) || filetype.equals(XMLParser.RECORDBATCH_TAG) || filetype.equals(XMLParser.EVENTBATCH_TAG))
        {
            Document document = XMLParser.getDocForFile(file);
            Element documentElement = document.getDocumentElement();

            for(int n = 0 ; n < documentElement.getChildNodes().getLength() ; n++)
            {
                results.addAll(checkNode(documentElement.getChildNodes().item(n), file.getName(), stats, fileMetadata));
            }
        }
        fileValues.remove(file.getName());
        return results;
    }

    /**
     * Identifies the category of the provided node and executes the respective checks
     *
     * @param node the node to be checked
     * @param filename
     *
     * @return <code>List<CategoryOneCheckResult></code> the results of all individual tests execution
     * */
    private static List<CategoryOneCheckResult> checkNode(Node node, String filename, UpdategramStats stats, FileMetadata fileMetadata)
    {
        List<CategoryOneCheckResult> results = new ArrayList<>();

        if(!"#text".equals(node.getNodeName()) && !"#comment".equals(node.getNodeName()))
        {
            String nodeName = node.getNodeName();
            String nodeValue = null;
            if(node.getChildNodes().getLength() == 1)
            {
                nodeValue = node.getTextContent();
            }

            switch (nodeName)
            {
                case UpdategramElementNames.EVENT_MESSAGE:
                {
                    stats.setMessages(stats.getMessages()+1);
                    for(int n = 0 ; n < node.getChildNodes().getLength() ; n++)
                    {
                        if(!"#text".equals(node.getChildNodes().item(n).getNodeName()) && !"#comment".equals(node.getChildNodes().item(n).getNodeName()))
                        {
                            results.addAll(checkNode(node.getChildNodes().item(n),filename,stats,fileMetadata));
                        }
                    }
                    break;
                }
                case UpdategramElementNames.EVENT_RECORD:
                {
                    stats.setRecords(stats.getRecords()+1);
                    for(int n = 0 ; n < node.getChildNodes().getLength() ; n++)
                    {
                        if(!"#text".equals(node.getChildNodes().item(n).getNodeName()) && !"#comment".equals(node.getChildNodes().item(n).getNodeName()))
                        {
                            results.addAll(checkNode(node.getChildNodes().item(n),filename,stats,fileMetadata));
                        }
                    }
                    break;
                }
                case UpdategramElementNames.RECORD_MESSAGE:
                case UpdategramElementNames.ATTATCHMENT_MESSAGE:
                {
                    stats.setMessages(stats.getMessages()+1);
                    stats.setRecords(stats.getRecords()+1);
                    for(int n = 0 ; n < node.getChildNodes().getLength() ; n++)
                    {
                        if(!"#text".equals(node.getChildNodes().item(n).getNodeName()) && !"#comment".equals(node.getChildNodes().item(n).getNodeName()))
                        {
                            results.addAll(checkNode(node.getChildNodes().item(n),filename,stats,fileMetadata));
                        }
                    }
                    break;
                }
                case UpdategramElementNames.BATCH_HEADER:
                {
                    //In case we detect a BatchHeader we immediately process all of its children nodes in order to populate the BatchHeaderValues table
                    //as the table may be required by other checks in the future
                    Map<String,String> batchHeaderContents = new HashMap<>();
                    for(int n = 0 ; n < node.getChildNodes().getLength() ; n++)
                    {
                        if(!"#text".equals(node.getChildNodes().item(n).getNodeName()) && !"#comment".equals(node.getChildNodes().item(n).getNodeName()))
                        {
                            //Validate the values of the BatchHeader before adding them to the static table
                            results.addAll(checkNode(node.getChildNodes().item(n),filename,stats,fileMetadata));
                            batchHeaderContents.put(UpdategramElementNames.BATCH_HEADER+"."+node.getChildNodes().item(n).getNodeName(), node.getChildNodes().item(n).getTextContent());
                        }
                    }
                    //map the filename to the contents of the BatchHeader
                    fileValues.put(filename,batchHeaderContents);
                    break;
                }
                case UpdategramElementNames.ATTACHMENT_RECORD_HEADER:
                case UpdategramElementNames.ENTITY_RECORD_HEADER:
                case UpdategramElementNames.RECORD_HEADER:
                case UpdategramElementNames.EVENT_RECORD_HEADER:
                {
                    boolean GPMLListExists = false;
                    boolean HandlingListExists = false;

                    for(int n = 0 ; n < node.getChildNodes().getLength() ; n++)
                    {
                        if(!"#text".equals(node.getChildNodes().item(n).getNodeName()) && !"#comment".equals(node.getChildNodes().item(n).getNodeName()))
                        {
                            results.addAll(checkNode(node.getChildNodes().item(n),filename,stats,fileMetadata));

                            if(node.getChildNodes().item(n).getNodeName().equals(UpdategramElementNames.RECORD_TYPE_LIST))
                            {
                                String siblingName = node.getNextSibling().getNextSibling() != null ? node.getNextSibling().getNextSibling().getNodeName() : null;
                                results.add(ElementChecks.validateRecordTypeListToChildEntityAssociation(node.getChildNodes().item(n).getTextContent(), siblingName));
                            }
                            else if(node.getChildNodes().item(n).getNodeName().equals(UpdategramElementNames.GPMS_LIST))
                            {
                                GPMLListExists = true;
                            }
                            else if(node.getChildNodes().item(n).getNodeName().equals(UpdategramElementNames.HANDLING_LIST))
                            {
                                HandlingListExists = true;
                            }
                        }
                    }
                    //Covering for the cases when no GPMSList and HandlingList nodes exist
                    if(!GPMLListExists)
                    {
                        results.add(new CategoryOneCheckResult("C_ALL_1000_020_1",false, "GPMSList must be populated"));
                    }
                    if(!HandlingListExists)
                    {
                        results.add(new CategoryOneCheckResult("C_ALL_1000_010_1",false, "HandlingList must be populated"));
                    }
                    break;
                }
                case UpdategramElementNames.PUBLISHER:
                {
                    CategoryOneCheckResult result = ElementChecks.validatePublisherValue(nodeValue);
                    results.add(result);
                    if(result.isSuccess())
                    {
                        stats.setPublisher(nodeValue);
                    }
                    break;
                }
                case UpdategramElementNames.RECIPIENT:
                {
                    CategoryOneCheckResult result = ElementChecks.validateRecipientValue(nodeValue);
                    results.add(result);
                    if(result.isSuccess())
                    {
                        stats.setRecipient(nodeValue);
                    }
                    break;
                }
                case UpdategramElementNames.FORCE_AGENCY_LIST:
                {
                    results.add(ElementChecks.validateForceAgencyListValue(nodeValue, fileValues.get(filename)));
                    break;
                }
                case UpdategramElementNames.FORCE_AGENCY_SYSTEM_NAME_TEXT:
                {
                    String forceAgencyListValue = null;
                    for(int s = 0 ; s < node.getParentNode().getChildNodes().getLength() ; s++)
                    {
                        Node sibling = node.getParentNode().getChildNodes().item(s);
                        if(sibling.getNodeName().equals(UpdategramElementNames.FORCE_AGENCY_LIST))
                        {
                            if(sibling.getChildNodes().getLength() == 1)
                            {
                                forceAgencyListValue = sibling.getTextContent();
                                break;
                            }
                        }
                    }
                    if(forceAgencyListValue != null)
                    {
                        results.addAll(ElementChecks.validateForceAgencySystems(forceAgencyListValue,nodeValue));
                    }
                    //TODO confirm behaviour when no ForceAgencyList field is available
                    break;
                }
                case UpdategramElementNames.TRANSACTION_LIST:
                {
                    CategoryOneCheckResult result = ElementChecks.validateTransactionListValue(nodeValue);
                    results.add(result);
                    if(result.isSuccess())
                    {
                        stats.setTransactionList(nodeValue);
                    }
                    break;
                }
                case UpdategramElementNames.MESSAGE_TRANSACTION_LIST:
                {
                    results.add(ElementChecks.validateMessageTransactionListValue(nodeValue));
                    break;
                }
                case UpdategramElementNames.MESSAGE_DATE_TIME:
                {
                    results.add(ElementChecks.validateMessageDateTime(nodeValue));
                    break;
                }
                case UpdategramElementNames.RECORD_TYPE_LIST:
                {
                    CategoryOneCheckResult validValueResult = ElementChecks.validateRecordTypeListValue(nodeValue);
                    results.add(validValueResult);

                    if(validValueResult.isSuccess())
                    {
                        results.add(ElementChecks.validateRecordTypeListValueAgainstInvalidValues(nodeValue));
                        results.add(ElementChecks.validateRecordTypeListOCG(nodeValue,node.getParentNode().getNodeName()));
                        results.add(ElementChecks.validateRecordTypeListFlag(nodeValue,node.getParentNode().getNodeName()));
                    }

                    break;
                }
                case UpdategramElementNames.GPMS_LIST:
                {
                    CategoryOneCheckResult populatedResult = ElementChecks.validateGPMSListValuePopulated(node.getParentNode());
                    results.add(populatedResult);
                    if(populatedResult.isSuccess())
                    {
                        results.add(ElementChecks.validateGPMSListValueConstrained(nodeValue));
                        results.add(ElementChecks.validateGPMSListValueLEDSInvalidClassification(nodeValue));
                        results.add(ElementChecks.validateGPMSListValueAgainstFTPSServerChannel(nodeValue,fileMetadata));
                    }
                    break;
                }
                case UpdategramElementNames.HANDLING_LIST:
                {
                    CategoryOneCheckResult populatedResult = ElementChecks.validateHandlingListValuePopulated(node.getParentNode());
                    results.add(populatedResult);
                    if(populatedResult.isSuccess())
                    {
                        results.add(ElementChecks.validateHandlingListValueConstrained(nodeValue));
                        if("4".equals(nodeValue) || "5".equals(nodeValue))
                        {
                            results.add(ElementChecks.validateHandlingListRelatedValue(node, nodeValue));
                        }
                    }
                    break;
                }
                case UpdategramElementNames.IMAGE_DATA:
                {
                    results.add(ElementChecks.validateImageData(nodeValue));
                    break;
                }
                case UpdategramElementNames.ROLE:
                {
                    String from = null;
                    String to = null;
                    for(int s = 0 ; s < node.getParentNode().getChildNodes().getLength() ; s++)
                    {
                        Node sibling = node.getParentNode().getChildNodes().item(s);
                        if(sibling.getNodeName().equals(UpdategramElementNames.SOURCE_ASSOCIATION_IDENTIFIERS))
                        {
                            for(int n = 0 ; n < sibling.getChildNodes().getLength() ; n++)
                            {
                                if(sibling.getChildNodes().item(n).getNodeName().equals(UpdategramElementNames.RECORD_TYPE_LIST))
                                {
                                    if(sibling.getChildNodes().item(n).getChildNodes().getLength() == 1)
                                    {
                                        from = sibling.getChildNodes().item(n).getTextContent();
                                        break;
                                    }
                                }
                            }
                        }
                        else if(sibling.getNodeName().equals(UpdategramElementNames.TARGET_ASSOCIATION_IDENTIFIERS))
                        {
                            for(int n = 0 ; n < sibling.getChildNodes().getLength() ; n++)
                            {
                                if(sibling.getChildNodes().item(n).getNodeName().equals(UpdategramElementNames.RECORD_TYPE_LIST))
                                {
                                    if(sibling.getChildNodes().item(n).getChildNodes().getLength() == 1)
                                    {
                                        to = sibling.getChildNodes().item(n).getTextContent();
                                        break;
                                    }
                                }
                            }
                        }
                    }

                    results.add(ElementChecks.validateAssociationRoleValue(nodeValue));
                    results.add(ElementChecks.validateAssociationRoleCombinations(nodeValue,from,to));
                    break;
                }
                default:
                {
                    //non-leaf node. Proceed to check its children nodes
                    for(int n = 0 ; n < node.getChildNodes().getLength() ; n++)
                    {
                        if(!"#text".equals(node.getChildNodes().item(n).getNodeName()) && !"#comment".equals(node.getChildNodes().item(n).getNodeName()))
                        {
                            results.addAll(checkNode(node.getChildNodes().item(n),filename,stats,fileMetadata));
                        }
                    }
                }
            }
        }
        return results;
    }

}
