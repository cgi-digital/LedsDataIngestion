package uk.gov.homeoffice.dpp.healthchecks.filestore;

import java.io.IOException;

/**
 * Created by M.Koskinas on 30/05/2017.
 */
public class FileStoreFactory
{
    /**
     * Creates and returns a FileStore instance based on the provided FileStoreSpecification object.
     * Defaults to DiskFileStore
     *
     * @param specification the FileStoreSpecification object describing the FileStore instance to be created
     *
     * @return <code>FileStore</code>
     *
     * @see FileStore
     * @see DiskFileStore
     * */
    public static FileStore createFileStore(FileStoreSpecification specification) throws IOException
    {
        if(specification != null)
        {
            switch (specification.getType())
            {
                case "disk":
                {
                    return new DiskFileStore(specification.getLocation());
                }
                default:
                {
                    return new DiskFileStore("./FILESTORE");
                }
            }
        }
        else
        {
            return new DiskFileStore("./FILESTORE");
        }
    }
}
