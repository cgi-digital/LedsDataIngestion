package uk.gov.homeoffice.dpp.healthchecks.persistence.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPCheck;
import uk.gov.homeoffice.dpp.healthchecks.persistence.repositories.CheckRepository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by C.Barnes on 01/03/2017.
 */
@Service("CheckService")
public class CheckServiceImpl implements CheckService {

    @PersistenceContext
    private EntityManager em;

    @Autowired
    private CheckRepository checkRepository;

    private static Map<Long,DPPCheck> checksMap = new HashMap<>();

    @Override
    public List<DPPCheck> getAll()
    {
        cacheChecks();
        List<DPPCheck> checks = checksMap.values().stream().collect(Collectors.toList());
        return checks;
    }

    @Override
    @Transactional
    public DPPCheck getCheckByID(Long id)
    {
        cacheChecks();
        return checksMap.get(id);
    }

    @Override
    @Transactional
    public List<DPPCheck> getChecksByActiveType(boolean isActive)
    {
        cacheChecks();
        List<DPPCheck> checks = checksMap.values().stream().filter(c -> c.isActive() == isActive).collect(Collectors.toList());
        return checks;
    }

    @Override
    @Transactional
    public List<DPPCheck> getChecksByName(String name)
    {
        cacheChecks();
        List<DPPCheck> checks = checksMap.values().stream().filter(c -> c.getName().equals(name)).collect(Collectors.toList());
        return checks;
    }

    @Override
    @Modifying
    @Transactional
    public DPPCheck createCheck(Long id, boolean isActive, String checkName, String checkDesc)
    {
        DPPCheck dppCheck = new DPPCheck(id, isActive, checkName, checkDesc);

        return checkRepository.save(dppCheck);
    }

    private void cacheChecks()
    {
        if(checksMap.isEmpty())
        {
            for(DPPCheck check : checkRepository.findAll())
            {
                checksMap.put(check.getId(),check);
            }
        }
    }

}
