package uk.gov.homeoffice.dpp.healthchecks.persistence.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;
import uk.gov.homeoffice.dpp.healthchecks.persistence.repositories.UpdategramStatsRepository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

/**
 * Created by M.Koskinas on 12/06/2017.
 */
@Service("UpdategramStatsService")
public class UpdategramStatsServiceImpl implements UpdategramStatsService
{
    private static final Logger logger = LoggerFactory.getLogger(UpdategramStatsServiceImpl.class);

    @PersistenceContext
    public EntityManager em;

    @Autowired
    private UpdategramStatsRepository updategramStatsRepository;

    @Override
    public List<UpdategramStats> findAll() {
        return updategramStatsRepository.findAll();
    }

    @Override
    public UpdategramStats findById(Long id) {
        return updategramStatsRepository.findById(id);
    }

    @Override
    public UpdategramStats findByFileid(Long fileid) {
        return updategramStatsRepository.findByFileid(fileid);
    }

    @Override
    @Modifying
    @Transactional
    public UpdategramStats createStats(UpdategramStats stats, Long fileID) {
        stats.setFileid(fileID);
        em.persist(stats);
        return stats;

    }
}
