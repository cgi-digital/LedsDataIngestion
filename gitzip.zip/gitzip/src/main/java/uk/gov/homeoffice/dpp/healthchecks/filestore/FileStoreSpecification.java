package uk.gov.homeoffice.dpp.healthchecks.filestore;

/**
 * Created by M.Koskinas on 30/05/2017.
 */
public class FileStoreSpecification
{
    private String type;
    private String location;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
