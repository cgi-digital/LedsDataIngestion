package uk.gov.homeoffice.dpp.fileingest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import uk.gov.homeoffice.dpp.configuration.FileIngestConfiguration;
import uk.gov.homeoffice.dpp.configuration.priorities.PriorityConfiguration;
import uk.gov.homeoffice.dpp.configuration.forces.ForceLandingLocation;
import uk.gov.homeoffice.dpp.configuration.forces.ForceProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import uk.gov.homeoffice.dpp.configuration.priorities.PriorityProperties;

import java.util.*;

/**
 * This class is used to start polling a list of directories in priority order
 * Created by C.Barnes on 06/07/2017.
 */
@Component
public class DirPoller {

    private static final Logger logger = LoggerFactory.getLogger(DirPoller.class);

    @Autowired
    ApplicationContext appContext;

    List<ForceDirectory> dirsToPoll = new ArrayList<>();
    int minFileAge;

    public DirPoller()
    {
        minFileAge = 10;
    }

    public DirPoller(Map<String, ForceProperties> forceProperties, int minFileAge)
    {
        for(Map.Entry<String, ForceProperties> force: forceProperties.entrySet())
        {
            for(Map.Entry<String, ForceLandingLocation> forceLandingLoc: force.getValue().getIngest().entrySet())
            {
                dirsToPoll.add(new ForceDirectory(forceLandingLoc.getValue(), force.getValue().getForceID()));
            }
        }

        this.minFileAge = minFileAge;


    }

    /**
     * Starts a loop to poll the directories indefinitely
     * @throws InterruptedException
     */
    public void startPolling() throws InterruptedException {
        while(FileIngestConfiguration.isKeepPolling())
        {
            boolean filesFound = poll();

            if (!filesFound)
            {
                logger.info("No files found in any of the directories, so sleeping for {} minutes", FileIngestConfiguration.getSleepTime());
                Thread.sleep(60000 * (long)FileIngestConfiguration.getSleepTime());
            }
        }
    }

    /**
     * This method polls each of the directories in the given list once.
     * It iterates through the list of directories starting with the most important priority (1).
     * If no files are found to be processed in any of the directories it sleeps for a defined amount of time.
     * @return returns true if a file was processed, false otherwise
     */
    public boolean poll() {
        boolean filesFound = false;

        dirsToPoll.sort(Comparator.comparingInt(o -> o.dirPath.getPriority()));

        for(ForceDirectory forceDir : dirsToPoll)
        {
            PriorityProperties priorityProperties = PriorityConfiguration.priorityLevels.get(Integer.toString(forceDir.dirPath.getPriority()));

            if(priorityProperties == null)
            {
                logger.error("{} is not a recognised priority in the 'priority' properties", forceDir.dirPath.getPriority());
            }
            else if(priorityProperties.isAutoCollect())
            {
                //DirProcessor dirProcessor = new DirProcessor(forceDir, priorityProperties);
                DirProcessor dirProcessor = (DirProcessor) appContext.getBean("DirProcessor", forceDir.getDirPath(), priorityProperties, forceDir.getForceID());
                if(!filesFound) {
                    filesFound = dirProcessor.processDirectory();
                }
                else
                {
                    dirProcessor.processDirectory();
                }
            }
        }

        logger.info("----------------------------------------------------");

        return filesFound;

    }

    public List<ForceDirectory> getDirsToPoll() {
        return dirsToPoll;
    }

    public class ForceDirectory {
        private ForceLandingLocation dirPath;
        private String forceID;

        public ForceDirectory(ForceLandingLocation dirPath, String forceID)
        {
            this.dirPath = dirPath;
            this.forceID = forceID;
        }

        public ForceLandingLocation getDirPath() {
            return dirPath;
        }

        public void setDirPath(ForceLandingLocation dirPath) {
            this.dirPath = dirPath;
        }

        public String getForceID() {
            return forceID;
        }

        public void setForceID(String forceID) {
            this.forceID = forceID;
        }
    }
}