package uk.gov.homeoffice.dpp.filemonitoring.utilities;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.DotFinishedHandler;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.UUID;

/**
 * The FileIngestor class prepares a file for ingestion into the pipeline. Such as
 * copying it into a temporary location
 * @author C.Barnes
 */
public final class FileIngestor {

    private static final Logger logger = LoggerFactory.getLogger(FileIngestor.class);

    /**
     * Moves the {@link FileMetadata#currentPath} file into a temporary
     * location and then renames it into a generated guid in preparation
     * for going through the pipeline
     * @param fileToBeIngested Metadata object for the file about to enter the pipeline
     * @return returns true if the file is correctly prepared for loading, false otherwise
     */
    public static boolean prepareFileForLoading(FileMetadata fileToBeIngested)
    {
        Path pathToOrigFile = fileToBeIngested.getCurrentPath();
        Path pathToTempFile = Paths.get(FTPManagerConfiguration.getTempStoragePath() + "/" + pathToOrigFile.getFileName());

        try
        {
            Files.copy(pathToOrigFile, pathToTempFile);
            fileToBeIngested.setCurrentPath(pathToTempFile);
        }
        catch (IOException e)
        {
            logger.error("Failed to copy file {} to temporary location {} for virus scanning", pathToOrigFile.toString(), pathToTempFile.toString(), e);
            return false;
        }

        //if(pathToOrigFile.getFileName().toString().contains(".tar")) {
            if (!generateAndRenameToGUID(fileToBeIngested))
                return false;
        //}

        return true;
    }

    /**
     * Renames the file in {@link FileMetadata#currentPath} to a
     * randomly generated GUID
     * @param fileToBeIngested the metadata object referring to the file to be renamed
     * @return true if the file is successfully renamed to a GUID, false otherwise
     */
    private static boolean generateAndRenameToGUID(FileMetadata fileToBeIngested) {

        UUID guid = GUIDHandler.guidGenerator();

        try {
            Path newPath = GUIDHandler.renameFileToGuid(fileToBeIngested.getCurrentPath(), guid);
            fileToBeIngested.setGuid(guid);
            fileToBeIngested.setCurrentPath(newPath);
        } catch (IOException e) {
            logger.error("Failed to rename file {} to guid {}", fileToBeIngested.getCurrentPath().toString(), guid.toString(), e);
            return false;
        }

        return true;

    }

    /**
     * Logs some of the metadata into the {@link FileMetadata} object
     * that can only be gathered at the beginning stages. Such as {@link FileMetadata#originalFilePath},
     * {@link FileMetadata#landingDate}
     * @param fileToLog metadata object to populate with initial data
     */
    public static void populateInitialMetadata(FileMetadata fileToLog)
    {
        logger.info("Populating initial metadata values for file {}", fileToLog.getCurrentPath());

        populateInitialFilepath(fileToLog);
        populateInitialFileNameAndSize(fileToLog);
        populateIPAddress(fileToLog);
        populateReceivedTime(fileToLog);
    }

    /**
     * Logs the ip address of the machine the original file was delivered
     * to. (Provided that {@link FileMetadata#ipAddress} isn't already populated)
     * @param fileToLog The metadata object for the delivered file that will store the ip address
     */
    private static void populateIPAddress(FileMetadata fileToLog) {

        if(fileToLog.getIpAddress() != null)
            return;

        try {
            fileToLog.setIpAddress(InetAddress.getLocalHost());
        } catch (UnknownHostException e) {
            logger.error("Could not get localhost address for file {}", fileToLog.getOriginalFilePath(), e);
        }

    }

    /**
     * Logs the original file path (provided the {@link FileMetadata#currentPath} is
     * currently the original file path and the {@link FileMetadata#originalFilePath}
     * isn't populated)
     * @param fileToLog file metadata object to store the original filepath in
     */
    private static void populateInitialFilepath(FileMetadata fileToLog) {

        if(fileToLog.getOriginalFilePath() != null)
            return;

        fileToLog.setOriginalFilePath(fileToLog.getCurrentPath().toString());
    }

    /**
     * Logs the original file path (provided the {@link FileMetadata#currentPath} is
     * currently the original file path and the {@link FileMetadata#originalFilePath}
     * isn't populated)
     * @param fileToLog file metadata object to store the original filepath in
     */
    private static void logFileSize(FileMetadata fileToLog) {

        if(fileToLog.getOriginalFileSize() != 0)
            return;

        fileToLog.setOriginalFilePath(fileToLog.getCurrentPath().toString());
    }

    /**
     * Logs the original file name and file size(provided the {@link FileMetadata#originalFilePath} is
     * currently the original file name and the {@link FileMetadata#originalFileName}
     * isn't populated)
     * @param fileToLog file metadata object to store the original file name in
     */
    private static void populateInitialFileNameAndSize(FileMetadata fileToLog) {

        if(fileToLog.getOriginalFileName() != null)
            return;

        File file = fileToLog.getCurrentPath().toFile();
        String originalFilename = Paths.get(fileToLog.getOriginalFilePath()).getFileName().toString();

        if(originalFilename.contains(".tar"))
        {
            fileToLog.setGuid(GUIDHandler.guidGenerator());

            fileToLog.setOriginalFileName(DotFinishedHandler.removeDotFinished(file.getName()));
        }
        else{

            fileToLog.setOriginalFileName(DotFinishedHandler.removeDotFinished(originalFilename));
        }

        fileToLog.setOriginalFileSize(file.length());
    }

    /**
     * Logs the time that the file landed in the directory in the {@link FileMetadata#landingDate}
     * @param fileToLog file metadata object to store the received time in
     */
    private static void populateReceivedTime(FileMetadata fileToLog)
    {

        if(fileToLog.getLandingDate() != null)
            return;

        Path filePath = fileToLog.getCurrentPath();

        File file = new File(filePath.toString());
        Date timeArrived = new Date(file.lastModified());

        fileToLog.setLandingDate(timeArrived);

    }

}
