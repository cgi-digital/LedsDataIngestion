package uk.gov.homeoffice.dpp.healthchecks.persistence.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.Audit;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPCheck;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPFile;
import uk.gov.homeoffice.dpp.healthchecks.persistence.repositories.AuditRepository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Date;
import java.util.List;

/**
 * Created by C.Barnes on 01/03/2017.
 */
@Service("AuditService")
public class AuditServiceImpl implements AuditService {


    @PersistenceContext
    private EntityManager em;

    @Autowired
    private AuditRepository auditRepository;

    @Override
    @Transactional
    public Audit getAuditByID(Integer id)
    {
        return auditRepository.findById(id);
    }

    @Override
    @Transactional
    public List<Audit> getAuditsByFileGUID(Long guid)
    {
        return auditRepository.findByFileId(guid);
    }

    @Override
    @Transactional
    public List<Audit> getAllAuditsFinishBetween(Date from, Date to)
    {
        return auditRepository.findByFinishBetween(from, to);
    }

    @Override
    @Transactional
    public List<Audit> getAllAuditsStartBetween(Date from, Date to)
    {
        return auditRepository.findByStartBetween(from, to);
    }

    @Override
    @Transactional
    public Audit getAuditByFileGUIDAndCheckID(Long guid, Long id)
    {
        return auditRepository.findByFileIdAndCheckId(guid, id);
    }

    @Override
    @Transactional
    public List<Audit> getAuditsByFileGUIDAndStatus(Long guid, String status)
    {
        return auditRepository.findByFileIdAndStatus(guid, status);
    }

    @Override
    @Modifying
    @Transactional
    public Audit createAudit(Date startTime, String auditStatus, DPPFile fileToCheck, DPPCheck dppCheckExecuted)
    {
        Audit newAudit = new Audit(startTime, auditStatus, fileToCheck, dppCheckExecuted);

        return auditRepository.save(newAudit);
    }

    @Override
    @Modifying
    @Transactional
    public Audit createAudit(Date startTime, String auditStatus, Long fileid, Long checkID)
    {

        DPPFile dppFile = new DPPFile(fileid);
        DPPCheck dppCheck = new DPPCheck(checkID);

        Audit newAudit = new Audit(startTime, auditStatus, dppFile, dppCheck);

        em.persist(newAudit);
        return newAudit;
    }

    @Override
    @Modifying
    @Transactional
    public Audit updateAudit(Audit audit)
    {
        return em.merge(audit);
    }


}
