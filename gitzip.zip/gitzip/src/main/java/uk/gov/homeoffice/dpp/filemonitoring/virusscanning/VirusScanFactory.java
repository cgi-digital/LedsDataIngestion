package uk.gov.homeoffice.dpp.filemonitoring.virusscanning;

import uk.gov.homeoffice.dpp.filemonitoring.steps.StepSpecification;

/**
 * Creates an instance of a VirusScan object specific
 * to an Operating System
 * @author C.Barnes
 */
public final class VirusScanFactory {

    /**
     * Currently accepted Operating Systems
     */
    public enum OS {
        WINDOWS, UNIX, NONE
    }

    private OS opSys;

    /**
     * Identifies the type of OS to create
     * a Virus Scanning object for
     * @param OperatingSystem The specified Operating System. Either 'Windows' or 'Unix'
     */
    public VirusScanFactory(String OperatingSystem)
    {
        if(OperatingSystem == null)
        {
            opSys = OS.NONE;
            return;
        }

        switch (OperatingSystem)
        {
            case "Windows":
                opSys = OS.WINDOWS;
                break;
            case "Unix":
                opSys = OS.UNIX;
                break;
            default:
                opSys = OS.NONE;
                break;

        }
    }

    /**
     * Creates and returns a new instance
     * of a VirusScanner object specific to the
     * Operating System outlined in the constructor
     * @param stepSpec Step specification details for the Virus Scanning Step
     * @return The OS-Specific VirusScan object that was created
     */
    public VirusScan getVirusScanner(StepSpecification stepSpec)
    {
        switch (opSys)
        {
            case WINDOWS:
                return new WindowsVirusScan(stepSpec);
            case UNIX:
                return new UnixVirusScan(stepSpec);
            case NONE:
            default:
                return null;

        }
    }

}
