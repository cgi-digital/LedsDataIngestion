package uk.gov.homeoffice.dpp.healthchecks.persistence.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPFile;

import java.util.Date;
import java.util.List;

/**
 * Created by C.Barnes on 01/03/2017.
 */
@Repository
@Transactional
public interface DPPFileRepository extends JpaRepository<DPPFile, Long> {

    DPPFile findById(Long id);

    List<DPPFile> findByFilepath(String filepath);

    List<DPPFile> findByReceivedBetween(Date from, Date until);

    DPPFile findByGuid(String guid);

    List<DPPFile> findByStatus(String status);

    List<DPPFile> findByFilename(String filename);

    List<DPPFile> findByForceID(String forceid);

    DPPFile findByChecksum(String checksum);

    List<DPPFile> findByPriorityLevel(String priorityLevel);

    List<DPPFile> findByChecksumAndFilenameAndForceID(String checksum, String filename, String forceID);

}
