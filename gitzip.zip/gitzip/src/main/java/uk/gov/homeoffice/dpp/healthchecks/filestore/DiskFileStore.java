package uk.gov.homeoffice.dpp.healthchecks.filestore;

import org.slf4j.Logger;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Implementation of the FileStore interface, storing files on the disk
 * @see FileStore
 *
 * Created by M.Koskinas on 30/05/2017.
 */
public class DiskFileStore implements FileStore
{
    public static final String FAILED_FILES_DIRECTORY_NAME = "FAILED";

    private static final Logger logger = org.slf4j.LoggerFactory.getLogger(DiskFileStore.class);
    private String location;

    public DiskFileStore(String location) throws IOException
    {
        this.location = location;
        try
        {
            if(!Paths.get(this.location).toFile().exists())
            {
                Files.createDirectories(Paths.get(this.location));
            }
        }
        catch (IOException e)
        {
            logger.error("Could not build file store on disk location '"+location+"'",e);
            throw(e);
        }
    }

    @Override
    public String storeFile(File sourceFile, String subdirectory, boolean success)
    {
        String finalLocation = null;
        String target;

        if(sourceFile != null)
        {
            if(subdirectory == null || subdirectory.isEmpty())
            {
                target = location;
            }
            else
            {
                target = location + "/" + subdirectory;
            }

            target = success ? target : target + File.separator + FAILED_FILES_DIRECTORY_NAME;

            logger.info("Storing file {} in file store location {}", sourceFile.getName(), target);

            File targetFile = new File(target+File.separator+sourceFile.getName());
            Path targetPath = targetFile.toPath();

            if(!Paths.get(target).toFile().exists())
            {
                try
                {
                    Files.createDirectories(Paths.get(target));
                }
                catch (IOException e)
                {
                    logger.error("Could not create directory for disk location '"+location+"'",e);
                }
            }

            try
            {
                Files.copy(sourceFile.toPath(), targetPath);
                finalLocation = targetFile.getAbsolutePath();
            }
            catch (IOException e)
            {
                logger.error("Error while storing file in the file store",e);
            }

            logger.info("File {} successfully stored in {}", sourceFile.getName(), finalLocation);
        }



        return finalLocation;
    }

    @Override
    public File retrieveFile(String filepath)
    {
        File file = new File(filepath);
        if(file.exists() && !file.isDirectory())
        {
            return file;
        }
        return null;
    }
}
