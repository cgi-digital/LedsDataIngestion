package uk.gov.homeoffice.dpp.healthchecks.persistence.services;

import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPFile;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.FileError;

import java.util.List;

/**
 * Created by M.Koskinas on 08/05/2017.
 */
public interface FileErrorService {

    List<FileError> findAll();

    FileError findById(Long id);

    List<FileError> findByGuid(String guid);

    List<FileError> findByErrorid(String errorid);

    FileError createFileError(DPPFile file, String guid, String errorid);

    List<FileError> createFileErrorsAndClearList(List<FileError> listOfErrors);

    FileError createFileError(FileError error);
}
