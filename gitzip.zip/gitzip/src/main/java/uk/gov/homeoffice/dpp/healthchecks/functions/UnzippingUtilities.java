package uk.gov.homeoffice.dpp.healthchecks.functions;

import org.apache.commons.compress.compressors.z.ZCompressorInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.healthchecks.xmlparser.XMLParser;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipInputStream;

/**
 * Created by M.Koskinas on 22/03/2017.
 */
public final class UnzippingUtilities {

    private static final Logger logger = LoggerFactory.getLogger(UnzippingUtilities.class);

    private static final int BUFFER_SIZE = 4096;

    public static final String UNZIPPED_EXTENSION = ".unzipped";

    /**
     * Detects if the file specified by the provided file path is a zip file
     *
     * @param filepath
     *
     * @return <code>boolean</code>
     * */
    public static boolean isZipped(String filepath) throws IOException
    {
        boolean zip = false;
        FileInputStream fis = new FileInputStream(filepath);

        if(filepath.endsWith(".gz") || filepath.endsWith(".z"))
        {
            GZIPInputStream gzipInputStream = null;
            try {
                gzipInputStream = new GZIPInputStream(fis);
                zip = true;
                logger.info("file {} compressed in {} format",filepath, filepath.substring(filepath.lastIndexOf('.',filepath.length()-1)));
            }
            catch (ZipException ze)
            {
                zip = false;
                logger.error("File {} not properly compressed",filepath, ze);
            }
            if(gzipInputStream != null)
            {
                gzipInputStream.close();
            }
        }
        else if(filepath.endsWith(".Z"))
        {
            BufferedInputStream in = new BufferedInputStream(fis);
            ZCompressorInputStream zIn = new ZCompressorInputStream(in);

            BufferedReader br = new BufferedReader(new InputStreamReader(zIn));

            br.close();
            zip = true;
        }
        else if(filepath.endsWith(".zip"))
        {
            ZipInputStream zipInputStream = new ZipInputStream(fis);
            zip = (zipInputStream.getNextEntry() != null) ;
            zipInputStream.close();

            logger.info("file {} compressed in .zip format",filepath);
        }

        fis.close();

        return zip;
}

    /**
     * Unzips the provide zip file, and returns it's contents
     *
     * @param zipFile
     * @return <code>List<String></code> the contents of the zip file
     * */
    public static List<String> unzip(File zipFile, FileMetadata zipFileProp) throws IOException {

        String zipFileFullName = zipFileProp.getOriginalFileName();//zipFile.getName();
        String zipFileName = zipFileFullName.substring(0,zipFileFullName.lastIndexOf('.'));

        logger.info("Unzipping file: {}", zipFileName);

        List<String> filepaths = new ArrayList<>();

        String destination = zipFile.getParent() + File.separator + zipFile.getName()+UNZIPPED_EXTENSION;

        File destinationDirectory = new File(destination);
        if (!destinationDirectory.exists())
        {
            destinationDirectory.mkdir();
        }

        FileInputStream fis = new FileInputStream(zipFile.getPath());

        if(zipFile.getName().endsWith(".zip"))
        {
            ZipInputStream zipInput = new ZipInputStream(fis);

            ZipEntry entry = zipInput.getNextEntry();

            boolean error = false;

            // iterates over entries in the zip file
            while (entry != null && !error)
            {
                String filePath = destination + File.separator + entry.getName();
                if (!entry.isDirectory())
                {
                    //TODO get file name from the properties file
                    if(!entry.getName().substring(0,entry.getName().lastIndexOf('.')).equals(zipFileName))
                    {
                        error = true;
                        logger.error("Invalid zip entry name: {} . Name doesn't match the name of the zip file",entry.getName());
                    }
                    else if(!".xml".equals(entry.getName().substring(entry.getName().lastIndexOf('.'))))
                    {
                        error = true;
                        logger.error("Invalid zip entry type: {} . Type must be '.xml'", entry.getName().substring(entry.getName().lastIndexOf('.')));
                    }
                    else if(!filepaths.isEmpty())
                    {
                        error = true;
                        logger.error("Zip files should only contain one entry.");
                    }

                    if(!error)
                    {
                        logger.info("Extracting zip entry: {}", filePath);
                        // if the entry is a file, extracts it
                        extractFile(zipInput, filePath);
                        filepaths.add(filePath);
                        logger.info("Zip entry {} extracted", filePath);
                    }
                }
                else
                {
                    error = true;
                }
                zipInput.closeEntry();
                entry = zipInput.getNextEntry();
            }

            zipInput.close();
        }
        else if(zipFile.getName().endsWith(".gz") || zipFile.getName().endsWith(".z"))
        {
            //create extracted file with the name of the .gz/.z file and the xml extension
            //these compression formats only compress single files
            String filePath = destination + File.separator + zipFile.getName().substring(0,zipFile.getName().lastIndexOf('.'));

            GZIPInputStream gzipInputStream = new GZIPInputStream(fis);
            extractFile(gzipInputStream, filePath);

            if(XMLParser.isXMLFile(new File(filePath)))
            {
                filepaths.add(filePath);
            }
            else
            {
                logger.error("Invalid compressed file type. Type must be '.xml'");
            }

            gzipInputStream.close();
        }
        else if(zipFile.getName().endsWith(".Z"))
        {
            String filePath = destination + File.separator + zipFile.getName().substring(0,zipFile.getName().lastIndexOf('.'));

            BufferedInputStream in = new BufferedInputStream(fis);
            ZCompressorInputStream zIn = new ZCompressorInputStream(in);

            extractFile(zIn,filePath);

            filepaths.add(filePath);

            zIn.close();
        }

        fis.close();

        return filepaths;
    }

    private static void extractFile(InputStream zipInpout, String filePath) throws IOException
    {
        BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(filePath));
        byte[] bytesIn = new byte[BUFFER_SIZE];
        int read = 0;

        while ((read = zipInpout.read(bytesIn)) != -1)
        {
            outputStream.write(bytesIn, 0, read);
        }
        outputStream.close();
    }

}
