package uk.gov.homeoffice.dpp.configuration.priorities;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * Created by C.Barnes on 12/07/2017.
 */
@Configuration
@ConfigurationProperties(prefix = "priorities")
public class PriorityConfiguration {

    public static Map<String, PriorityProperties> priorityLevels;

    public Map<String, PriorityProperties> getPriorityLevels() {
        return priorityLevels;
    }

    public void setPriorityLevels(Map<String, PriorityProperties> priorityLevels) {
        PriorityConfiguration.priorityLevels = priorityLevels;
    }
}
