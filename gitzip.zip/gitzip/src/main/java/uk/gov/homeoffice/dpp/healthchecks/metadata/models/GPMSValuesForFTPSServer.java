package uk.gov.homeoffice.dpp.healthchecks.metadata.models;

import java.util.List;

/**
 * Created by M.Koskinas on 27/04/2017.
 */
public final class GPMSValuesForFTPSServer
{
    private final String servername;
    private final List<String> gpmslist_values;

    public GPMSValuesForFTPSServer(String servername, List<String> gpmslist_values)
    {
        this.servername = servername;
        this.gpmslist_values = gpmslist_values;
    }

    public String getServername() {
        return servername;
    }

    public List<String> getGpmslist_values() {
        return gpmslist_values;
    }
}
