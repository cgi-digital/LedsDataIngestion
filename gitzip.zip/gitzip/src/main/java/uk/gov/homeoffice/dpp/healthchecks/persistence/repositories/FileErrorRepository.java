package uk.gov.homeoffice.dpp.healthchecks.persistence.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.FileError;

import java.util.List;

/**
 * Created by M.Koskinas on 08/05/2017.
 */

@Repository
@Transactional
public interface FileErrorRepository extends JpaRepository<FileError, Long> {

    List<FileError> findAll();

    FileError findById(Long id);

    List<FileError> findByGuid(String guid);

    List<FileError> findByErrorid(String errorid);

}
