package uk.gov.homeoffice.dpp.filemonitoring;

import java.net.InetAddress;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Object to store all the metadata of a single file
 * @author C.Barnes, M.Koskinas
 */
public class FileMetadata {

    public static final String STATE_SUCCESFUL = "SUCCESSFUL";
    public static final String STATE_VIRUS = "VIRUS";
    public static final String VIRUS_MESSAGE = "File failed virus scanning";
    public static final String SUCCESFUL_MESSAGE = "NONE";

    private UUID guid;
    private String originalFilePath;
    private String originalFileName;
    private String forceID;
    private String priorityLevel;
    private String finalLocation;

    private InetAddress ipAddress;//split

    private String receivedMachineName;
    private String receivedMachineIP;

    private long originalFileSize;
    private Date landingDate;
    private Date VSstart;
    private Date VSfinish;
    private String state;
    private String errorMessage;

    private Path currentPath;

    public static FileMetadata createEmptyMetadata()
    {
        return new FileMetadata(null,null,null);
    }

    public FileMetadata(Path curPath, String frcID, String priorityLvl)
    {
        this.currentPath = curPath;
        this.forceID = frcID;
        this.priorityLevel = priorityLvl;
    }

    public FileMetadata(Path curPath, FileMetadata metaToDup)
    {
        this.currentPath = curPath;

        this.guid = metaToDup.getGuid();
        this.originalFilePath = metaToDup.getOriginalFilePath();
        this.originalFileName = metaToDup.getOriginalFileName();
        this.forceID = metaToDup.getForceID();
        this.priorityLevel = metaToDup.getPriorityLevel();
        this.finalLocation = metaToDup.getFinalLocation();
        setIpAddress(metaToDup.getIpAddress());
        this.landingDate = metaToDup.getLandingDate();
        this.VSstart = metaToDup.getVSstart();
        this.VSfinish = metaToDup.getVSfinish();
        this.originalFileSize = metaToDup.getOriginalFileSize();
        this.state = metaToDup.getState();
        this.errorMessage = metaToDup.getErrorMessage();
    }


    public UUID getGuid() {
        return guid;
    }

    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    public String getOriginalFilePath() {
        return originalFilePath;
    }

    public void setOriginalFilePath(String originalFilePath) {
        this.originalFilePath = originalFilePath;
    }

    public String getOriginalFileName() {
        return originalFileName;
    }

    public void setOriginalFileName(String originalFileName) {
        this.originalFileName = originalFileName;
    }

    public InetAddress getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(InetAddress ipAddress) {
        this.ipAddress = ipAddress;

        if(ipAddress != null && ipAddress.toString() != null && !ipAddress.toString().isEmpty())
        {
            String[] nameIP = ipAddress.toString().split("/");
            this.receivedMachineName = nameIP[0];
            this.receivedMachineIP = nameIP[1];
        }
        else
        {
            this.receivedMachineName = null;
            this.receivedMachineIP = null;
        }
    }

    public Date getLandingDate() {
        return landingDate;
    }

    public void setLandingDate(Date landingDate) {
        this.landingDate = landingDate;
    }

    public Date getVSstart() {
        return VSstart;
    }

    public void setVSstart(Date VSstart) {
        this.VSstart = VSstart;
    }

    public Date getVSfinish() {
        return VSfinish;
    }

    public void setVSfinish(Date VSfinish) {
        this.VSfinish = VSfinish;
    }

    public Path getCurrentPath() {
        return currentPath;
    }

    public void setCurrentPath(Path currentPath) {
        this.currentPath = currentPath;
    }

    public long getOriginalFileSize() {
        return originalFileSize;
    }

    public void setOriginalFileSize(long originalFileSize) {
        this.originalFileSize = originalFileSize;
    }

    public String getForceID() {
        return forceID;
    }

    public void setForceID(String forceID)
    {
        if(forceID != null && !forceID.isEmpty() && forceID.toCharArray()[0] == 'F' )
        {
            this.forceID = forceID.replace("F", "");
        }
        else {
            this.forceID = forceID;
        }
    }

    public String getPriorityLevel() {
        return priorityLevel;
    }

    public void setPriorityLevel(String priorityLevel)
    {
        if(priorityLevel != null && !priorityLevel.isEmpty())
        {
            this.priorityLevel = priorityLevel;
        }
        else
        {
            this.priorityLevel = "3";
        }
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }


    public String getReceivedMachineName() {
        return receivedMachineName;
    }

    public void setReceivedMachineName(String receivedMachineName) {
        this.receivedMachineName = receivedMachineName;
    }

    public String getReceivedMachineIP() {
        return receivedMachineIP;
    }

    public void setReceivedMachineIP(String receivedMachineIP) {
        this.receivedMachineIP = receivedMachineIP;
    }

    public String getFinalLocation() {
        return finalLocation;
    }

    public void setFinalLocation(String finalLocation) {
        this.finalLocation = finalLocation;
    }

    /**
     * Validates that all of the values of the provided FileMetadata object are populated
     *
     * @param fileMetadata the FileMetadata object to be examined
     * @return boolean
     * */
    public static boolean areMetadataPopulated(FileMetadata fileMetadata)
    {

        //not checking for finalLocation because in case of a virus, the file is removed from the file system
        //resulting in an empty final location

        return  fileMetadata != null
                && fileMetadata.getGuid() != null
                && fileMetadata.getOriginalFilePath() != null
                && fileMetadata.getOriginalFileName() != null
                && String.valueOf(fileMetadata.getOriginalFileSize()) != null
                && fileMetadata.getForceID() != null
                && fileMetadata.getPriorityLevel() != null
                && fileMetadata.getLandingDate() != null
                && fileMetadata.getVSstart() != null
                && fileMetadata.getVSfinish() != null
                && fileMetadata.getReceivedMachineName() != null
                && fileMetadata.getReceivedMachineIP() != null
                && fileMetadata.getState() != null
                && fileMetadata.getErrorMessage() != null
                && fileMetadata.getFinalLocation() != null;
    }

    /**
     * returns all the data for a file's properties file
     * in the correct format
     * @return array of strings ready to be written to a properties file
     */
    public List<String> generatePropertyFileContent()
    {

        return Arrays.asList("originalFileLocation: " + this.originalFilePath,"filename: " + this.originalFileName, "fileguid: " + this.guid,
                "forceID: " + this.forceID, "priorityLevel: " + this.priorityLevel, "ReceivedMachineName/IP: " + this.ipAddress, "filesize: " + this.originalFileSize,
                "landedTime: " + this.landingDate, "VSStart: " + this.VSstart, "VSFinish: " + this.VSfinish, "State: " + this.state, "ErrorMessage: " + this.errorMessage);
    }

}
