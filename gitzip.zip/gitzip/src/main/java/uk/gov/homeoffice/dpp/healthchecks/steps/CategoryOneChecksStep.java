package uk.gov.homeoffice.dpp.healthchecks.steps;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.healthchecks.checks.UpdategramHandler;
import uk.gov.homeoffice.dpp.healthchecks.checks.CategoryOneCheckResult;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by M.Koskinas on 05/05/2017.
 */
public class CategoryOneChecksStep implements Step
{
    private static final Logger logger = LoggerFactory.getLogger(CategoryOneChecksStep.class);

    private Map<String,String> properties;
    private boolean enabled;

    public CategoryOneChecksStep(StepSpecification specification)
    {
        this.properties = specification.getProperties();
        this.enabled = specification.getStatus();
    }

    @Override
    public StepResult runCheck(File file, Long fileID, FileMetadata fileMetadata, UpdategramStats stats) {

        Map<String,String> errors = new HashMap<>();
        boolean success = true;

        List<CategoryOneCheckResult> results = UpdategramHandler.executeChecks(file, fileMetadata, stats);

        for(int r = 0 ; r < results.size() ; r++)
        {
            if(!results.get(r).isSuccess())
            {
                success = false;
                errors.put(results.get(r).getCheckName(),results.get(r).getMessage());
            }
        }

        return new StepResult(success,null, errors);
    }

    @Override
    public String getName() {
        return "category_one_checks";
    }

    @Override
    public Long getID() {
        return Long.valueOf(2);
    }

    @Override
    public Map<String, String> getProperties() {
        return this.properties;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }
}
