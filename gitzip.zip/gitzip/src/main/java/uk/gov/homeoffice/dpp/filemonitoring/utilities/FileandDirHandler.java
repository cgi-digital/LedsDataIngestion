package uk.gov.homeoffice.dpp.filemonitoring.utilities;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.steps.UnTarStep;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * This class is used to handle the creation/deletion of files and directories
 * @author C.Barnes
 */
public final class FileandDirHandler {

    private static final Logger logger = LoggerFactory.getLogger(FileandDirHandler.class);

    /**
     * Creates the temporary folder(s) needed for the pipeline in the location
     * specified in the properties file
     * @return true if the folder(s) are created successfully, false if not
     */
    public static boolean createTemporaryFolderStructure()
    {
        Path tempFolder = FTPManagerConfiguration.getTempStoragePath();
        boolean success = true;

        logger.info("Creating temporary folder {}", tempFolder.toString());


        if(tempFolder.toFile().exists())
        {
            if(!tempFolder.toFile().isDirectory()) {
                logger.error("Tried to create {} temp folder but it is not a directory", tempFolder.toString());
                return false;
            }
        }
        else{
            success = tempFolder.toFile().mkdir();
        }

        return success;
    }

    /**
     * Creates temporary folder to be used to untar files into. Created
     * in the applications temporary storage.
     * @return true if temp folder is created successfully, false if not
     */
    public static boolean createTarTempFolder()
    {
        Path tempFolder = FTPManagerConfiguration.getTempStoragePath();

        Path tarTempFolder = Paths.get(tempFolder.toString() + "/" + UnTarStep.TEMP_UNTAR_NAME); //+ FTPManagerConfiguration.getTemp_tar_storage_name());

        boolean success = true;

        if(!tarTempFolder.toFile().exists())
        {

            logger.info("Creating temporary UNTAR folder {}", tarTempFolder.toString());
            success = tarTempFolder.toFile().mkdir();
        }

        return success;
    }

    /**
     * Recursively deletes a Directory and all the directories inside it.
     * Does not delete files as in most cases this means there has been an
     * error and the file has not been moved out
     * @param dirToDelete path to the directory that is to be deleted
     * @return true if the directory is successfully deleted, false otherwise
     */
    public static boolean deleteDirectoryAndAllContentsExceptFiles(Path dirToDelete)
    {
        File originalDir = new File(dirToDelete.toString());
        File[] dirContents = originalDir.listFiles();

        if(dirContents != null)
        {
            for(File file : dirContents)
            {
                deleteDirectoryAndAllContentsExceptFiles(file.toPath());
            }
        }

        if(originalDir.isFile())
        {
            logger.error("File {} was found in temp folder, should have been moved to output dir", dirToDelete.toString());
            return false;
        }

        return originalDir.delete();

    }

    /**
     * Deletes a file
     * @param pathToFile path to the file to be deleted
     * @return true if the file is deleted successfully, false otherwise
     */
    public static boolean deleteFile(Path pathToFile)
    {
        File file = new File(pathToFile.toString());

        if(!file.isFile())
            return false;

        return file.delete();
    }

}
