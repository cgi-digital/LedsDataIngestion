package uk.gov.homeoffice.dpp.healthchecks.xsd;

import java.util.Map;

/**
 * Created by M.Koskinas on 05/04/2017.
 */
public class XsdConfiguration {

    private String xsdSchemasLocation;
    private Map<String,String> typeMappings;

    public String getXsdSchemasLocation() {
        return xsdSchemasLocation;
    }

    public void setXsdSchemasLocation(String xsdSchemasLocation) {
        this.xsdSchemasLocation = xsdSchemasLocation;
    }

    public Map<String, String> getTypeMappings() {
        return typeMappings;
    }

    public void setTypeMappings(Map<String, String> typeMappings) {
        this.typeMappings = typeMappings;
    }

}
