package uk.gov.homeoffice.dpp.healthchecks.persistence.entities;

import javax.persistence.*;

/**
 * Created by M.Koskinas on 08/05/2017.
 */
@Entity
@Table(name = "ho_file_errors")
public class FileError
{
    public FileError()
    {

    }

    public FileError(String guid, String errorid, DPPFile file)
    {
        this.guid = guid;
        this.errorid = errorid;
        this.fileID = file;
    }

    @Id
    @Column(name = "hofer_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="hofd_guid")
    private String guid;

    @ManyToOne
    @JoinColumn(name = "hofd_id")
    private DPPFile fileID;

    @Column(name="hofer_errorid")
    private String errorid;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getErrorid() {
        return errorid;
    }

    public void setErrorid(String errorid) {
        this.errorid = errorid;
    }

    public DPPFile getFileID() {
        return fileID;
    }

    public void setFileID(DPPFile fileID) {
        this.fileID = fileID;
    }
}
