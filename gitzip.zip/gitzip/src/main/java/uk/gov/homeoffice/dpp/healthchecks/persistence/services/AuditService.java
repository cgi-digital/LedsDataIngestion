package uk.gov.homeoffice.dpp.healthchecks.persistence.services;

import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.Audit;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPCheck;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPFile;

import java.util.Date;
import java.util.List;

/**
 * Created by C.Barnes on 01/03/2017.
 */
public interface AuditService {

    Audit getAuditByID(Integer id);

    List<Audit> getAuditsByFileGUID(Long guid);

    List<Audit> getAllAuditsFinishBetween(Date from, Date to);

    List<Audit> getAllAuditsStartBetween(Date from, Date to);

    Audit getAuditByFileGUIDAndCheckID(Long guid, Long id);

    List<Audit> getAuditsByFileGUIDAndStatus(Long guid, String status);

    Audit createAudit(Date startTime, String auditStatus, DPPFile fileToCheck, DPPCheck dppCheckExecuted);

    Audit createAudit(Date startTime, String auditStatus, Long fileId, Long checkID);

    Audit updateAudit(Audit audit);

}
