package uk.gov.homeoffice.dpp.healthchecks.checks;

/**
 * Created by M.Koskinas on 04/05/2017.
 */
public final class CategoryOneCheckResult {

    private final String checkName;
    private final boolean success;
    private final String message;

    public CategoryOneCheckResult(String checkName, boolean success, String message)
    {
        this.checkName = checkName;
        this.success = success;
        this.message = message;
    }

    public String getCheckName() {
        return checkName;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }
}
