package uk.gov.homeoffice.dpp.configuration;

import liquibase.integration.spring.SpringLiquibase;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.*;
import uk.gov.homeoffice.dpp.healthchecks.HealthChecksPipeline;
import uk.gov.homeoffice.dpp.healthchecks.errorhandler.ErrorHandler;
import uk.gov.homeoffice.dpp.healthchecks.filestore.FileStore;
import uk.gov.homeoffice.dpp.healthchecks.filestore.FileStoreFactory;
import uk.gov.homeoffice.dpp.healthchecks.filestore.FileStoreSpecification;
import uk.gov.homeoffice.dpp.healthchecks.ledsqueue.LEDSQueue;
import uk.gov.homeoffice.dpp.healthchecks.ledsqueue.LEDSQueueSpecification;
import uk.gov.homeoffice.dpp.healthchecks.steps.StepSpecification;
import uk.gov.homeoffice.dpp.healthchecks.xsd.XsdConfiguration;

import javax.sql.DataSource;
import java.io.IOException;
import java.util.Map;

/**
 * Created by koskinasm on 09/02/2017.
 */

@Configuration
@ConfigurationProperties(prefix = "healthChecks.configuration")
public class HealthChecksConfiguration {

    /*---PROCESS ID--------------------------------------------------------------------------------------------------*/

    public static String processID = null;

    public static void setProcessID(String processID)
    {
        HealthChecksConfiguration.processID = processID;
    }

    /*---XSD CONFIGURATION-------------------------------------------------------------------------------------------*/

    public static XsdConfiguration xsdConfiguration;

    public XsdConfiguration getXsdConfiguration() {
        return xsdConfiguration;
    }

    public void setXsdConfiguration(XsdConfiguration xsdConfiguration)
    {
        HealthChecksConfiguration.xsdConfiguration = xsdConfiguration;
    }

    /*---CHECKS AND PIPELINE-----------------------------------------------------------------------------------------*/

    public static Map<String,StepSpecification> checks;

    public Map<String,StepSpecification> getChecks() {
        return checks;
    }

    public void setChecks(Map<String,StepSpecification> checks) {
        this.checks = checks;
    }

    @Bean("HealthChecksPipeline")
    @Scope("prototype")
    public HealthChecksPipeline createPipeline()
    {
        return new HealthChecksPipeline(checks);
    }

    /*---LEDS QUEUE--------------------------------------------------------------------------------------------------*/

    private static LEDSQueueSpecification ledsQueue;

    public LEDSQueueSpecification getLedsQueue() {
        return ledsQueue;
    }

    public void setLedsQueue(LEDSQueueSpecification ledsQueue) {
        HealthChecksConfiguration.ledsQueue = ledsQueue;
    }

    @Bean("LEDSQueue")
    public LEDSQueue createLEDSQueue() {
        return new LEDSQueue(ledsQueue.getHost(),ledsQueue.getPort(),ledsQueue.getUsername(),ledsQueue.getPassword(),ledsQueue.getQueueName());
    }

    /*---FILE STORE--------------------------------------------------------------------------------------------------*/

    public static FileStoreSpecification filestore;

    public FileStoreSpecification getFilestore() {
        return filestore;
    }

    public void setFilestore(FileStoreSpecification filestore) {
        HealthChecksConfiguration.filestore = filestore;
    }

    @Bean("FileStore")
    public FileStore createFileStore() throws IOException
    {
        return FileStoreFactory.createFileStore(filestore);
    }

    /*---METADATA UPDATE FREQUENCY-----------------------------------------------------------------------------------*/

    public static int metadataUpdateFrequency;

    public int getMetadataUpdateFrequency() {
        return metadataUpdateFrequency;
    }

    public void setMetadataUpdateFrequency(int metadataUpdateFrequency)
    {
        HealthChecksConfiguration.metadataUpdateFrequency = metadataUpdateFrequency;
    }

    /*---ERROR HANDLER----------------------------------------------------------------------------------------------*/

    @Bean("ErrorHandler")
    public ErrorHandler createDBHandler() {return new ErrorHandler();}

    /*---DATASOURCES AND LIQUIBASE----------------------------------------------------------------------------------*/
    /*
    * Primary datasource and liquibase configuration
    * This datasource will be used for storing our model (files, audits, check details etc)
    * */
    @Bean
    @Primary
    @ConfigurationProperties("spring.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "primaryLiquibaseProperties")
    @ConfigurationProperties("liquibase-changelogs.primary.liquibase")
    public LiquibaseProperties primaryLiquibaseProperties() {
        return new LiquibaseProperties();
    }

    @Bean(name = "liquibase")
    public SpringLiquibase primaryLiquibase(@Qualifier("primaryLiquibaseProperties") LiquibaseProperties liquibaseProperties) {
        SpringLiquibase primary = new SpringLiquibase();
        primary.setDataSource(dataSource());
        primary.setChangeLog(primaryLiquibaseProperties().getChangeLog());

        return primary;
    }

    /*
    * Secondary datasource and liquibase configuration
    * This datasource will be used for reference metadata
    * */
    @Bean(name = "metadata_datasource")
    @ConfigurationProperties("spring.metadata_datascource")
    public DataSource metadataDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "metadataLiquibaseProperties")
    @ConfigurationProperties("liquibase-changelogs.metadata.liquibase")
    public LiquibaseProperties metadataLiquibaseProperties() {
        return new LiquibaseProperties();
    }

    @Bean(name = "metadata-liquibase")
    public SpringLiquibase metadataLiquibase(@Qualifier("metadataLiquibaseProperties") LiquibaseProperties liquibaseProperties) {
        SpringLiquibase metadata = new SpringLiquibase();
        metadata.setDataSource(metadataDataSource());
        metadata.setChangeLog(metadataLiquibaseProperties().getChangeLog());

        return metadata;
    }
}
