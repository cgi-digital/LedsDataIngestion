package uk.gov.homeoffice.dpp.healthchecks.steps;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.DotFinishedHandler;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by M.Koskinas on 10/07/2017.
 */
public class RenameToFinishedStep implements Step {

    private static final Logger logger = LoggerFactory.getLogger(RenameToFinishedStep.class);

    private Map<String,String> properties;
    private boolean enabled;
    private String errorCode = "HC-0010";
    private FileMetadata currentFile;

    private static final String FILE_APPENDER = ".finished";

    public RenameToFinishedStep(StepSpecification specification)
    {
        this.properties = specification.getProperties();
        this.enabled = specification.getStatus();
    }

    @Override
    public StepResult runCheck(File file, Long fileID, FileMetadata fileMetadata, UpdategramStats stats)
    {
        Map<String,String> errors = new HashMap<>();

        boolean success = DotFinishedHandler.rename(fileMetadata);

        if(success)
        {
            return new StepResult(true,null,null);
        }
        else
        {
            errors.put(errorCode,"File doesn't exist");
            return new StepResult(false,null,errors);
        }
    }


    @Override
    public String getName() {
        return "rename_to_finished";
    }

    @Override
    public Long getID() {
        return Long.valueOf(3);
    }

    @Override
    public Map<String, String> getProperties() {
        return this.properties;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }
}