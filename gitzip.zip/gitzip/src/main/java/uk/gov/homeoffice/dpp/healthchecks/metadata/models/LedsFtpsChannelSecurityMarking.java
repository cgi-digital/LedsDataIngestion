package uk.gov.homeoffice.dpp.healthchecks.metadata.models;

/**
 * Created by M.Koskinas on 27/04/2017.
 */
public class LedsFtpsChannelSecurityMarking {

    private final String channelname;
    private final String gpmslist_value;
    private final String allowedinchannel_yn;

    public LedsFtpsChannelSecurityMarking(String channelname, String gpmslist_value, String allowedinchannel_yn)
    {
        this.channelname = channelname;
        this.gpmslist_value = gpmslist_value;
        this.allowedinchannel_yn = allowedinchannel_yn;
    }

    public String getChannelname() {
        return channelname;
    }

    public String getGpmslist_value() {
        return gpmslist_value;
    }

    public String getAllowedinchannel_yn() {
        return allowedinchannel_yn;
    }
}
