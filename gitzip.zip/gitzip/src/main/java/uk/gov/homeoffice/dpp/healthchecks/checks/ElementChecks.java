package uk.gov.homeoffice.dpp.healthchecks.checks;

import org.w3c.dom.Node;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.healthchecks.metadata.ValidationMetadata;
import uk.gov.homeoffice.dpp.healthchecks.metadata.models.AssociationRoleCombination;
import uk.gov.homeoffice.dpp.healthchecks.metadata.models.ForceAgencySystem;
import uk.gov.homeoffice.dpp.healthchecks.metadata.models.GPMSValuesForFTPSServer;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Utility class including functions that validate the values of various fields in the incoming updategrams.
 *
 * Created by M.Koskinas on 20/04/2017.
 */
public class ElementChecks {

    private static String RECORDTYPELIST_NOT_POPULATED = "RecordTypeList value must be populated";

    /**
     * Rule ID: C_ALL_0010_020_1
     * Validates that the value of the BatchHeader.Recipient field is populated
     * @param value the BatchHeader.Recipient value
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateRecipientValue(String value)
    {
        String message = null;
        boolean success = true;

        if(value == null || value.trim().isEmpty())
        {
            message = "Empty value for 'BatchHeader.Recipient'";
            success = false;
        }
        return new CategoryOneCheckResult("C_ALL_0010_020_1",success, message);
    }



    /**
     * Rule ID: C_ALL_1000_010_1
     * Record Header.Handling List.Must be populated.
     *
     * @param node the parent node of the HandlingList node
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateHandlingListValuePopulated(Node node)
    {
        String message = "HandlingList value must be populated";
        boolean success = false;

        Node nextNode = node.getFirstChild();

        String nodeName;
        String nodeValue;

        while (nextNode != null && !success)
        {
            if (!"#text".equals(nextNode.getNodeName()) && !"#comment".equals(nextNode.getNodeName()))
            {
                nodeName = nextNode.getNodeName();
                nodeValue = null;
                if (nextNode.getChildNodes().getLength() == 1)
                {
                    nodeValue = nextNode.getTextContent();
                }
                if("HandlingList".equals(nodeName) && nodeValue!=null && !nodeValue.trim().isEmpty())
                {
                    success = true;
                    message = null;
                }
            }
            nextNode = nextNode.getNextSibling();
        }

        return new CategoryOneCheckResult("C_ALL_1000_010_1",success, message);
    }



    /**
     * Rule ID: C_ALL_1000_010_2
     * Any Handling List, if populated, must be a value in the constrained value list <<Record Version Class Handling List>>
     *
     * @param value the value of the HandlingList node
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateHandlingListValueConstrained(String value)
    {
        String message = null;
        boolean success = true;

        String handlinglist = value;

        //TODO revisit the validity of this mapping
        if("P".equals(value))
        {
            handlinglist = "3";
        }
        else if("C".equals(value))
        {
            handlinglist = "5";
        }

        if(handlinglist == null || handlinglist.trim().isEmpty())
        {
            success = false;
            message = "HandlingList value must be populated";
        }
        else
        {
            if( !ValidationMetadata.getValidHandlingListValues().keySet().contains(handlinglist))
            {
                success = false;
                message = "HandlingList value invalid";
            }
        }

        return new CategoryOneCheckResult("C_ALL_1000_010_2",success, message);
    }



    /**
     * Rule ID: C_ALL_1000_M010_1
     * HandlingUserGroupText must be populated if Handling List is 4
     *
     * Rule ID: C_ALL_1000_M020_1
     * HandlingInstructionsText must be populated if Handling List is 5
     *
     * @param value the HandlingList value
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateHandlingListRelatedValue(Node node, String value)
    {
        String message = null;
        String checkName = null;
        boolean success = false;

            Node nextNode = node.getNextSibling();

            String nodeName;
            String nodeValue;

            while (nextNode != null && !success)
            {
                if (!"#text".equals(node.getNodeName()) && !"#comment".equals(node.getNodeName()))
                {
                    nodeName = nextNode.getNodeName();
                    nodeValue = null;
                    if (nextNode.getChildNodes().getLength() == 1) {
                        nodeValue = nextNode.getTextContent();
                    }
                    if ("4".equals(value) && "HandlingUserGroupText".equals(nodeName) && nodeValue != null && !nodeValue.trim().isEmpty())
                    {
                        success = true;
                    }
                    else if ("5".equals(value) && "HandlingInstructionsText".equals(nodeName) && nodeValue != null && !nodeValue.trim().isEmpty())
                    {
                        success = true;
                    }
                }
                nextNode = nextNode.getNextSibling();
            }

        if("4".equals(value))
        {
            checkName = "C_ALL_1000_M010_1";
            message = success ? null : "HandlingUserGroupText field not populated";
        }
        else if("5".equals(value))
        {
            checkName = "C_ALL_1000_M020_1";
            message = success ? null : "HandlingInstructionsText field not populated";
        }

        return new CategoryOneCheckResult(checkName,success, message);
    }



    /**
     * Rule ID: C_ALL_0020_040_1
     * The Message Header Message TransactionList must be a value in the constrained value list <<MessageHeaderMessageTransactionList>>
     * (Delete or Restate)
     *
     * @param value the value of the TransactionList field
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateMessageTransactionListValue(String value)
    {
        String message = null;
        boolean success = true;

        if(!"Delete".equalsIgnoreCase(value) && !"Restate".equalsIgnoreCase(value))
        {
            message = "MessageHeader.MessageTransactionList field doesn't have a valid value'";
            success = false;
        }
        return new CategoryOneCheckResult("C_ALL_0020_040_1",success, message);
    }


    //TODO clarify disabled status
    /**
     * Rule ID: C_ALL_0020_030_1
     * The Message Header Message DateTime must be a valid Datetime value
     * (Delete or Restate)
     *
     * @param value the value of the MessageDateTime field
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateMessageDateTime(String value)
    {
        String message = null;
        boolean success = true;

        try
        {
            LocalDateTime.parse(value, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        }
        catch (DateTimeParseException e)
        {
            success = false;
            message = "Invalid DateTime format: " + value;
        }

        return new CategoryOneCheckResult("C_ALL_0020_030_1",success, message);
    }



    /**
     * Rule ID: C_ALL_1000_020_1
     * RecordHeader.GPMSList.Must be populated
     *
     * @param node the parent node of the HandlingList node
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateGPMSListValuePopulated(Node node)
    {
        String message = "GPMSList value must be populated";
        boolean success = false;

        Node nextNode = node.getFirstChild();

        String nodeName;
        String nodeValue;

        while (nextNode != null && !success)
        {
            if (!"#text".equals(nextNode.getNodeName()) && !"#comment".equals(nextNode.getNodeName()))
            {
                nodeName = nextNode.getNodeName();
                nodeValue = null;
                if (nextNode.getChildNodes().getLength() == 1)
                {
                    nodeValue = nextNode.getTextContent();
                }
                if("GPMSList".equals(nodeName) &&  nodeValue!=null && !nodeValue.trim().isEmpty())
                {
                    success = true;
                    message = null;
                }
            }
            nextNode = nextNode.getNextSibling();
        }

        return new CategoryOneCheckResult("C_ALL_1000_020_1",success, message);
    }


    //TODO clarify disabled status
    /**
     * Rule ID: C_ALL_1000_020_2
     * Any GPMS List, if populated, must be a value in the constrained value list <<Record Version GPMS List>>
     *
     * @param value the value of the GPMSList field
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateGPMSListValueConstrained(String value)
    {
        String message = null;
        boolean success = true;

        if(value == null || value.trim().isEmpty())
        {
            success = false;
            message = "GPMSList value must be populated";
        }
        else
        {
            if(!ValidationMetadata.getGPMSList().keySet().contains(value))
            {
                success = false;
                message = "GPMSList value invalid";
            }
        }

        return new CategoryOneCheckResult("C_ALL_1000_020_2",success, message);
    }


    /*
    * GPMSList mappings
    * "1" - "GPMS Not Protectively Marked"
    * "2" - "GPMS Restricted"
    * "3" - "GPMS Confidential"
    * "4" - "GPMS SECRET"
    * "5" - "GPMS TOP SECRET"
    * "6" - "GPMS UNKNOWN"
    * "7" - "GPMS PROTECT"
    * "A" - "GSC Official"
    * "B" - "GSC Offcial Sensitive"
    * "C" - "GSC SECRET"
    * "D" - "GSC TOP SECRET"
    */

    /**
     * Rule ID: C_ALL_1000_020_3
     * Any GPMS List, if populated, must not indicate a classification of 'UNKNOWN' or above 'CONFIDENTIAL'
     * "If the GPMS List is populated, at least one of the following must be true:
     * - The GPMS List is RESTRICTED
     * - The GPMS List is CONFIDENTIAL
     * - The GPMS List is PROTECT
     * - The GPMS List is NOT PROTECTIVELY MARKED"
     *
     * @param value the value of the GPMSList field
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateGPMSListValueLEDSInvalidClassification(String value)
    {
        String message = null;
        boolean success = true;

        if(value != null && !value.trim().isEmpty())
        {
            if(!"UNKNOWN".equals(value) && ValidationMetadata.getGPMSList().keySet().contains(value))
            {
                if(!("2".equals(value) || "3".equals(value) || "7".equals(value) || "1".equals(value)
                        || "A".equals(value) || "B".equals(value)))
                {
                    success = false;
                    message = "GPMSList value: "+value+" invalid for LEDS";
                }
            }
            else
            {
                success = false;
                message = "GPMSList value: "+value+" invalid";
            }
        }
        else
        {
            success = false;
            message = "GPMSList value must be populated";
        }

        return new CategoryOneCheckResult("C_ALL_1000_020_3",success, message);
    }



    /**
     * Rule ID: C_ALL_1000_020_4
     * If the GPMS Marking of the channel that the Updategram was received over is RESTRICTED the GPMS List must not be CONFIDENTIAL.
     *
     * @param value the value of the GPMSList field
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateGPMSListValueAgainstFTPSServerChannel(String value, FileMetadata fileMetadata)
    {
        String message = null;
        boolean success = true;

        if(value != null && !value.trim().isEmpty())
        {
            if(ValidationMetadata.getGPMSList().keySet().contains(value))
            {
                for(GPMSValuesForFTPSServer mapping : ValidationMetadata.getValidGPMSValuesForFTPSServers())
                {
                    if(fileMetadata.getReceivedMachineName() != null && mapping.getServername().equals(fileMetadata.getReceivedMachineName()))
                    {
                        if(mapping.getGpmslist_values().contains("2") && "3".equals(value))
                        {
                            message = "Invalid GPMSList value "+ value+" for FTPS Server's ("+fileMetadata.getReceivedMachineName()+") channels";
                            success = false;
                        }
                        break;
                    }
                }
            }
            else
            {
                success = false;
                message = "GPMSList value invalid";
            }
        }
        else
        {
            success = false;
            message = "GPMSList value must be populated";
        }

        return new CategoryOneCheckResult("C_ALL_1000_020_4",success, message);
    }

    /**
     * Validates the provided String representation of an image in order to detect if it's properly encoded
     * in Base64
     *
     * @param value the encoded image String
     *
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateImageData(String value)
    {
        String message = null;
        boolean success = true;

        String regex = "^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{4}|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)$";

        if(value == null || value.isEmpty() || !value.matches(regex))
        {
            message = "Image data invalid or not properly encoded";
            success = false;
        }

        return new CategoryOneCheckResult("HC-0009",success, message);
    }


    /**
     * Rule ID: C_ALL_1000_020_5
     * "One of the following must be true:
     * - The Channel that the updategram was received over must be 'RESTRICTED'
     * - The Channel that the updategram was received over must be 'CONFIDENTIAL'"
     * Not related to the input files, only related to the system's configuration
     *
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateFTPSServerChannelsDistinctions()
    {
        String message = null;
        boolean success = true;

        for(GPMSValuesForFTPSServer mapping : ValidationMetadata.getValidGPMSValuesForFTPSServers())
        {
            if ( (mapping.getGpmslist_values().contains("2") && mapping.getGpmslist_values().contains("3")) || (!mapping.getGpmslist_values().contains("2") && !mapping.getGpmslist_values().contains("3")) )
            {
                message = "Invalid configuration for the security channels of FTPS server: "+mapping.getServername();
                success = false;
            }
            break;
        }

        return new CategoryOneCheckResult("C_ALL_1000_020_5",success, message);
    }



    /**
     * Rule ID: C_ALL_0030_020_1
     * Any RecordTypeList must be a value in the constrained value list <<RecordVersionRecordTypeList>>
     *
     * @param value the value of the RecordTypeList field
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateRecordTypeListValue(String value)
    {
        String message = null;
        boolean success = true;

        if(value != null && !value.trim().isEmpty())
        {
            if(!ValidationMetadata.getValidRecordTypeListValues().keySet().contains(value))
            {
                success = false;
                message = "Invalid value " + value + " for the RecordTypeList value";
            }
        }
        else
        {
            message = RECORDTYPELIST_NOT_POPULATED;
            success = false;
        }

        return new CategoryOneCheckResult("C_ALL_0030_020_1",success, message);
    }



    /**
     * Rule ID: C_ALL_0030_020_2
     * Due to RFC 20 De-scope of Firearm Licencing data from PND, the RecordTypeList must not be
     * FirearmsCertificate or FirearmsCertificateApplication
     *
     * @param value the value of the RecordTypeList field
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateRecordTypeListValueAgainstInvalidValues(String value)
    {
        String message = null;
        boolean success = true;

        if(value != null && !value.trim().isEmpty())
        {
            if("FirearmsCertificate".equals(value) || "FirearmsCertificateApplication".equals(value))
            {
                success = false;
                message = "Value " + value + " is not allowed for the RecordTypeList";
            }
        }
        else
        {
            message = RECORDTYPELIST_NOT_POPULATED;
            success = false;
        }

        return new CategoryOneCheckResult("C_ALL_0030_020_2",success, message);
    }



    /**
     * Rule ID: C_ALL_0010_030_1
     * The Batch Header Transaction List must be a value in the constrained value list <<BatchHeaderTransactionList>>
     * (Transaction or Independent)
     *
     * @param value the value of the TransactionList field
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateTransactionListValue(String value)
    {
        String message = null;
        boolean success = true;

        if(value != null && !value.trim().isEmpty())
        {
            if(!"Transaction".equalsIgnoreCase(value) && !"Independent".equalsIgnoreCase(value))
            {
                message = "BatchHeader.TransactionList field doesn't have a valid value'";
                success = false;
            }
        }
        else
        {
            message = RECORDTYPELIST_NOT_POPULATED;
            success = false;
        }

        return new CategoryOneCheckResult("C_ALL_0010_030_1",success, message);
    }



    /**
     * Rule ID: C_ALL_0010_010_2
     * Validates the provided value for the BatchHeader.Publisher field against the list of Valid Force Agencies in the metadata database
     *
     * Rule ID: C_ALL_0010_010_1
     * Validates that the value of the BatchHeader.Publisher field is populated
     *
     * @param value the BatchHeader.Publisher value
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validatePublisherValue(String value)
    {
        String message = null;
        boolean success = true;

        if(value != null && !value.trim().isEmpty())
        {
            if (!ValidationMetadata.getValidForceAgencies().isEmpty())
            {
                if (!ValidationMetadata.getValidForceAgencies().keySet().contains(value))
                {
                    message = "Invalid value "+value+" for 'Publisher'";
                    success = false;
                }
            }
            else
            {
                message = "Error getting valid values for 'Publisher'";
                success = false;
            }
        }
        else
        {
            message = "Empty value for 'BatchHeader.Publisher'";
            success = false;
            return new CategoryOneCheckResult("C_ALL_0010_010_1",success, message);
        }

        return new CategoryOneCheckResult("C_ALL_0010_010_2",success, message);
    }



    /**
     * Rule ID : C_ALL_0030_030_1
     * Validates the provided value for the ForceAgencyList field against the list of Valid Force Agencies in the metadata database.
     *
     * Rule ID: C_ALL_1000_M030_1
     * Validates the provided value for the ForceAgencyList field against the BatchHeader.
     * Publisher field whose value can be obtained from the provided batchHeaderValues map
     *
     * @param value the ForceAgencyList value
     * @param batchHeaderValues a map containing the values of the file's BatchHeader
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateForceAgencyListValue(String value, Map<String,String> batchHeaderValues)
    {
        String message = null;

        boolean success = true;
        boolean publisherValid = false;

        String publisher = batchHeaderValues.get(UpdategramElementNames.BATCH_HEADER+".Publisher");
        if(publisher != null && !publisher.isEmpty() && ValidationMetadata.getValidForceAgencies().keySet().contains(publisher))
        {
            //identifying if the value of the Publisher is valid
            publisherValid = true;
        }

        if(value != null && !value.trim().isEmpty())
        {
            if (!ValidationMetadata.getValidForceAgencies().isEmpty())
            {
                if (!ValidationMetadata.getValidForceAgencies().keySet().contains(value))
                {
                    //value not in the constrained list -> error
                    message = "Invalid value "+value+" for 'ForceAgencyList'";
                    success = false;
                }
                else if(publisherValid && !publisher.equals(value))
                {
                    //value in the constrained list and publisher value is valid but the two values don't match
                    message = "Invalid value "+value+" for 'ForceAgencyList'. This value is different from the value of the 'Publisher' field in the BatchHeader";
                    success = false;
                    return new CategoryOneCheckResult("C_ALL_1000_M030_1",success, message);
                }
            }
            else
            {
                message = "Error getting valid values for 'ForceAgencyList'";
                success = false;
            }
        }
        else
        {
            //value is empty -> error
            message = "Empty value for 'ForceAgencyList'";
            success = false;
        }

        return new CategoryOneCheckResult("C_ALL_0030_030_1",success, message);
    }



    /**
     * Rule ID: C_ALL_1000_110_1
     * The Record Version element name must be the same as the Record Type List of the Record Header.
     *
     * @param headerValue the value of the RecordTypeList field in the Header
     * @param siblingName the name of the Entity inside the message
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateRecordTypeListToChildEntityAssociation(String headerValue, String siblingName)
    {
        String message = "Record Entity name must match the value of the 'RecordTypeList' field in the Record Header";
        boolean success = false;

        if(siblingName != null)
        {
            if(headerValue.equals(siblingName) || ( "Attachment".equals(headerValue) && "AttachmentFile".equals(siblingName) ))
            {
                success = true;
                message = null;
            }
        }

        return new CategoryOneCheckResult("C_ALL_1000_110_1", success, message);
    }



    /**
     * Rule ID: C_ALL_1000_100_1
     * Must be a value in the constrained value list <<Association Role List>>
     *
     * @param value the value of the 'Role' field
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateAssociationRoleValue(String value)
    {
        String message = null;
        boolean success = true;

        if(value != null && !value.trim().isEmpty())
        {
            if(!ValidationMetadata.getValidAssocationRoleListValues().keySet().contains(value))
            {
                success = false;
                message = "Invalid value " + value + " for the 'Association.Role' value";
            }
        }
        else
        {
            message = "'Association.Role' value must be populated";
            success = false;
        }

        return new CategoryOneCheckResult("C_ALL_1000_100_1",success, message);
    }



    /**
     * Rule ID: C_ALL_1000_100_2
     * The combination of
     * - Role
     * - The RecordTypeList of the Source Association Identifiers
     * - The RecordTypeList of the Target Association Identifiers
     *
     * must be in the list of <<PND Association Roles>>
     *
     * @param role the value of the 'Role' field
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateAssociationRoleCombinations(String role, String from, String to)
    {
        String message = null;
        boolean success = true;

        if(role != null && !role.trim().isEmpty()
                && from != null && !from.trim().isEmpty()
                && to != null && !to.trim().isEmpty())
        {
            if(ValidationMetadata.getValidAssociationRoleCombinations().get(role) != null &&
                    !ValidationMetadata.getValidAssociationRoleCombinations().get(role).contains(new AssociationRoleCombination(from,to)))
            {
                success = false;
                message = "Invalid combination of Role with the RecordTypeList values for SourceAssociationIdentifiers and TargetAssociationIdentifiers";
            }
        }
        else
        {
            success = false;
            message = "Invalid or missing values for 'Role' or for the RecordTypeList values for SourceAssociationIdentifiers and TargetAssociationIdentifiers";
        }

        return new CategoryOneCheckResult("C_ALL_1000_100_2",success, message);
    }



    /**
     * Rule ID: C_ALL_0030_040_1
     * The Force Agency System Name Text must be a value in the constrained value list  <<Force Agency System Name List>>
     *
     * Rule ID: C_ALL_0030_040_2
     * Record Header Force Agency System Name Text.Must have CLMS Context
     *
     * Rule ID: C_ALL_0030_040_3
     * Record Header Force Agency System Name Text.Must have CLMS Context Map
     *
     * @param forceAgency the name of the ForceAgency to which the ForceAgencySystem is supposed to be associated
     * @param nodeValue the name of the ForceAgencySystem
     *
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static List<CategoryOneCheckResult> validateForceAgencySystems(String forceAgency, String nodeValue)
    {
        List<CategoryOneCheckResult> results = new ArrayList<>();

        for(String forceAgencyName : ValidationMetadata.getValidForceAgencySystems().keySet())
        {
            if(forceAgency.equals(forceAgencyName))
            {
                List<ForceAgencySystem> associatedSystems = ValidationMetadata.getValidForceAgencySystems().get(forceAgencyName);
                boolean validSystem = false;
                for(ForceAgencySystem  system : associatedSystems)
                {
                    if(system.getForceAgencySystem().equals(nodeValue))
                    {
                        validSystem = true;
                        //TODO ensure we need these Checks
                        if("Y".equals(system.getClms_context_loaded_yn()))
                        {
                            results.add(new CategoryOneCheckResult("C_ALL_0030_040_2", true, null));
                        }
                        else
                        {
                            results.add(new CategoryOneCheckResult("C_ALL_0030_040_1", false, "CLMS Context not loaded for ForceAgencySystem: " + nodeValue));
                        }
                        if("Y".equals(system.getClms_contextmap_loaded_yn()))
                        {
                            results.add(new CategoryOneCheckResult("C_ALL_0030_040_3", true, null));
                        }
                        else
                        {
                            results.add(new CategoryOneCheckResult("C_ALL_0030_040_1", false, "CLMS Context Map not loaded for ForceAgencySystem: " + nodeValue));
                        }
                        break;
                    }
                }
                if(validSystem)
                {
                    results.add(new CategoryOneCheckResult("C_ALL_0030_040_1", true, null));
                }
                else
                {
                    results.add(new CategoryOneCheckResult("C_ALL_0030_040_1", false, "Invalid name: " + nodeValue+ " for ForceAgencySystem"));
                }
                break;
            }
        }
        return results;
    }


    /**
     * Rule ID: C_ALL_OCG_001
     * Due to RFC 68, the record type list must not be OrganisedCrimeGroup
     *
     * Rule ID: C_ALL_OCG_002
     * Due to RFC 68, the AssocationSource.RecordTypeList must not be OrganisedCrimeGroup
     *
     * Rule ID: C_ALL_OCG_003
     * Due to RFC 68, the AssocationTarget.RecordTypeList must not be OrganisedCrimeGroup
     *
     * @param value the value of the 'RecordTypeList' field
     * @param parentNodeName the name of the parent node. This will be used to define the most appropriate error code.
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateRecordTypeListOCG(String value, String parentNodeName)
    {
        String message = null;
        boolean success = true;
        String checkCode = "C_ALL_OCG_001";

        if(value != null && !value.trim().isEmpty())
        {
            //if this is null the error will be detected by a previous rule and this rule won't be executed
            if("OrganisedCrimeGroup".equals(value))
            {
                success = false;
            }
        }

        if(parentNodeName.equals(UpdategramElementNames.RECORD_HEADER))
        {
            checkCode = "C_ALL_OCG_001";
            message = "Due to RFC 68, the record type list must not be OrganisedCrimeGroup";
        }
        else if(parentNodeName.equals(UpdategramElementNames.SOURCE_ASSOCIATION_IDENTIFIERS))
        {
            checkCode = "C_ALL_OCG_002";
            message = "Due to RFC 68, the AssocationSource.RecordTypeList must not be OrganisedCrimeGroup";

        }
        else if(parentNodeName.equals(UpdategramElementNames.TARGET_ASSOCIATION_IDENTIFIERS))
        {
            checkCode = "C_ALL_OCG_003";
            message = "Due to RFC 68, the AssocationTarget.RecordTypeList must not be OrganisedCrimeGroup";
        }

        return new CategoryOneCheckResult(checkCode,success, success ? null : message);
    }


    /**
     * Rule ID: C_ALL_FLAG_001
     * Due to RFC 68, the record type list must not be Flag
     *
     * Rule ID: C_ALL_FLAG_002
     * Due to RFC 68, the AssocationSource.RecordTypeList must not be Flag
     *
     * Rule ID: C_ALL_FLAG_003
     * Due to RFC 68, the AssocationTarget.RecordTypeList must not be Flag
     *
     * @param value the value of the 'RecordTypeList' field
     * @param parentNodeName the name of the parent node. This will be used to define the most appropriate error code.
     * @return <code>CategoryOneCheckResult</code>
     * */
    public static CategoryOneCheckResult validateRecordTypeListFlag(String value, String parentNodeName)
    {
        String message = null;
        boolean success = true;
        String checkCode = "C_ALL_FLAG_001";

        if(value != null && !value.trim().isEmpty())
        {
            //if this is null the error will be detected by a previous rule and this rule won't be executed
            if("Flag".equals(value))
            {
                success = false;
            }
        }

        if(parentNodeName.equals(UpdategramElementNames.RECORD_HEADER))
        {
            checkCode = "C_ALL_FLAG_001";
            message = "Due to RFC 68, the record type list must not be Flag";
        }
        else if(parentNodeName.equals(UpdategramElementNames.SOURCE_ASSOCIATION_IDENTIFIERS))
        {
            checkCode = "C_ALL_FLAG_002";
            message = "Due to RFC 68, the AssocationSource.RecordTypeList must not be Flag";

        }
        else if(parentNodeName.equals(UpdategramElementNames.TARGET_ASSOCIATION_IDENTIFIERS))
        {
            checkCode = "C_ALL_FLAG_003";
            message = "Due to RFC 68, the AssocationTarget.RecordTypeList must not be Flag";
        }

        return new CategoryOneCheckResult(checkCode,success, success ? null : message);
    }

    /**
     * Rule ID: HC-0012
     * Checks if the provided file is encoded in UTF-8 by checking its xml header
     *
     * Rule ID: HC-0011
     * Unable to detect the file's encoding
     *
     * @param file the file to be examined
     * @return <code>CategoryOneCheckResult</code>
     */
    public static CategoryOneCheckResult checkFileEncoding(File file)
    {
        boolean success = true;
        String message = null;
        String errorCode = "HC-0012";

        XMLInputFactory inputFactory = XMLInputFactory.newInstance();

        try {
            XMLStreamReader reader = inputFactory.createXMLStreamReader(new FileInputStream(file));
            if(!"UTF-8".equals(reader.getEncoding()))
            {
                success = false;
                message = "File not encoded in UTF-8";
            }
        } catch (XMLStreamException e) {
            success = false;
            message = "Unable to detect file encoding";
            errorCode = "HC-0011";
        }
        catch (FileNotFoundException e) {
            success = false;
            message = "Unable to detect file encoding";
            errorCode = "HC-0011";
        }
        return new CategoryOneCheckResult(errorCode,success,message);
    }
}
