package uk.gov.homeoffice.dpp.healthchecks.persistence.services;

import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;

import java.util.List;

/**
 * Created by M.Koskinas on 12/06/2017.
 */
public interface UpdategramStatsService
{
    List<UpdategramStats> findAll();

    UpdategramStats findById(Long id);

    UpdategramStats findByFileid(Long fileid);

    UpdategramStats createStats(UpdategramStats stats,Long fileID);
}
