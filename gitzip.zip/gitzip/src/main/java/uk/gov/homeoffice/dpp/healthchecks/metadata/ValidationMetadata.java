package uk.gov.homeoffice.dpp.healthchecks.metadata;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import uk.gov.homeoffice.dpp.configuration.HealthChecksConfiguration;
import uk.gov.homeoffice.dpp.healthchecks.metadata.models.*;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Utility class responsible for all interactions with the metadata database
 * The provided functions provide a caching mechanism for metadata available in the metadata database.
 * The functions will automatically updated the caches if a request occurs after an interval defined
 * by the 'metadataUpdateFrequency' property of the HealthChecksConfiguration
 *
 * @see HealthChecksConfiguration
 */
@Component
public class ValidationMetadata
{
    private static final Logger logger = LoggerFactory.getLogger(ValidationMetadata.class);

    /*STANDARD METADATA TABLES*/
    private static final Map<String,String> VALID_FORCE_AGENCIES = new HashMap<>();//Arrays.asList("999", "Test LEA 999","52","014","10");
    private static LocalDateTime VALID_FORCE_AGENCIES_UPDATED;

    private static final Map<String,List<ForceAgencySystem>> VALID_FORCE_AGENCY_SYSTEMS = new HashMap<>();
    private static LocalDateTime VALID_FORCE_AGENCY_SYSTEMS_UPDATED;

    private static final Map<String,String> VALID_LEDS_FTPS_CHANNELS = new HashMap<>();
    private static LocalDateTime VALID_LEDS_FTPS_CHANNELS_UPDATED;

    private static final List<LedsFtpsServer> VALID_LEDS_FTPS_SERVERS = new LinkedList<>();
    private static LocalDateTime VALID_LEDS_FTPS_SERVERS_UPDATED;

    private static final List<LedsFtpsChannelSecurityMarking> LEDS_FTPS_CHANNEL_SECURITY_MARKINGS = new LinkedList<>();
    private static LocalDateTime LEDS_FTPS_CHANNEL_SECURITY_MARKINGS_UPDATED;

    private static final Map<String,String> GPMS_LIST = new HashMap<>();
    private static LocalDateTime GPMS_LIST_UPDATED;

    private static final Map<String,String> VALID_RECORD_TYPE_LIST_VALUES = new HashMap<>();
    private static LocalDateTime VALID_RECORD_TYPE_LIST_VALUES_UPDATED;

    private static final Map<String,String> VALID_HANDLING_LIST_VALUES = new HashMap<>();
    private static LocalDateTime VALID_HANDLING_LIST_VALUES_UPDATED;

    private static final Map<String,String> VALID_ASSOCIATION_ROLE_LIST_VALUES = new HashMap<>();
    private static LocalDateTime VALID_ASSOCIATION_ROLE_LIST_VALUES_UPDATED;


    /*CUSTOM QUERIES AND OBJECTS*/
    private static List<GPMSValuesForFTPSServer> VALID_GPMS_VALUES_FOR_FTPS_SERVERS = new LinkedList<>();
    private static LocalDateTime VALID_GPMS_VALUES_FOR_FTPS_SERVERS_UPDATED;

    private static Map<String,List<AssociationRoleCombination>> VALID_ASSOCIATION_ROLE_COMBINATIONS = new HashMap<>();
    private static LocalDateTime VALID_ASSOCIATION_ROLE_COMBINATIONS_UPDATED;

    @Autowired
    @Qualifier("metadata_datasource")
    private DataSource metadata_datasource;

    private static DataSource datasource;

    /**
     * Initialises the static instance of the datasource
     * */
    @PostConstruct
    public void initDatasource ()
    {
        datasource = this.metadata_datasource;
    }


    private static Connection openConnection() throws SQLException
    {
        return datasource.getConnection();
    }

    private static void closeConnection(Connection connection) throws SQLException
    {
        connection.close();
    }



    public static Map<String,List<AssociationRoleCombination>> getValidAssociationRoleCombinations()
    {
        if (shouldUpdate(VALID_ASSOCIATION_ROLE_COMBINATIONS_UPDATED) || VALID_ASSOCIATION_ROLE_COMBINATIONS.isEmpty())
        {
            VALID_ASSOCIATION_ROLE_COMBINATIONS.clear();

            Connection connection = null;
            PreparedStatement statement = null;

            try {
                connection = openConnection();
                statement = connection.prepareStatement("SELECT * FROM AssociationRolesCombinations");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next())
                {
                    String role = resultSet.getString("Role");
                    String from = resultSet.getString("FromAssociation");
                    String to = resultSet.getString("toAssociation");

                    if(!VALID_ASSOCIATION_ROLE_COMBINATIONS.containsKey(role))
                    {
                        VALID_ASSOCIATION_ROLE_COMBINATIONS.put(role,new ArrayList<AssociationRoleCombination>());
                    }
                    VALID_ASSOCIATION_ROLE_COMBINATIONS.get(role).add(new AssociationRoleCombination(from,to));
                }
                statement.close();
                closeConnection(connection);
                VALID_ASSOCIATION_ROLE_COMBINATIONS_UPDATED = LocalDateTime.now();
            } catch (SQLException e) {
                logger.error("Error while querying the metadata database", e);
            } finally {
                try {
                    if (statement != null) {
                        statement.close();
                    }
                    if (connection != null) {
                        closeConnection(connection);
                    }
                } catch (SQLException e) {
                    logger.error("Error while interacting with the metadata database", e);
                }
            }
        }
        return VALID_ASSOCIATION_ROLE_COMBINATIONS;

    }

    /**
     * Checks if the cached data should be updated by querying the database for new data
     * For the given timestap, the function checks if the last update is older than the time specified
     * by the metadataUpdateFrequency defined in the application properties
     *
     * @param updatedDateTime the latest update of the dataset to be queried
     *
     * @return <code>boolean</code>
     * @see HealthChecksConfiguration
     * */
    private static boolean shouldUpdate(LocalDateTime updatedDateTime)
    {
        if(updatedDateTime == null)
        {
            return true;
        }
        else
        {
            Duration interval = Duration.between(updatedDateTime,LocalDateTime.now());
            if((interval.getSeconds()*60) > HealthChecksConfiguration.metadataUpdateFrequency)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    /**
     * Return a map of all valid Force Agencies against their description
     *
     * @return <code>Map<String,String></code>
     * */
    public static Map<String,String> getValidForceAgencies()
    {
        if(shouldUpdate(VALID_FORCE_AGENCIES_UPDATED) || VALID_FORCE_AGENCIES.isEmpty())
        {
            VALID_FORCE_AGENCIES.clear();

            Connection connection = null;
            PreparedStatement statement = null;

            try
            {
                connection = openConnection();
                statement = connection.prepareStatement("SELECT * FROM forceagency");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next())
                {
                    VALID_FORCE_AGENCIES.put(resultSet.getString("forceagency"),resultSet.getString("description"));
                }
                statement.close();
                closeConnection(connection);
                VALID_FORCE_AGENCIES_UPDATED = LocalDateTime.now();

                //TODO remove when tests have been updated
                VALID_FORCE_AGENCIES.put("52","");
                VALID_FORCE_AGENCIES.put("014","");
                VALID_FORCE_AGENCIES.put("10","");
            }
            catch (SQLException e) {
                logger.error("Error while querying the metadata database",e);
            }
            finally
            {
                try {
                    if(statement != null)
                    {
                        statement.close();
                    }
                    if(connection != null)
                    {
                        closeConnection(connection);
                    }
                }
                catch (SQLException e)
                {
                    logger.error("Error while interacting with the metadata database",e);
                }
            }
        }
        return VALID_FORCE_AGENCIES;
    }

    /**
     * Returns a list of ForceAgencySystem objects mapping Force Agencies against Force Agency Systems, their description
     * and information on whether or not CLMS Context and CLMS Context Maps should be loaded
     *
     * @return <code>List<ForceAgencySystem></code>
     * @see ForceAgencySystem
     * */
    public static Map<String,List<ForceAgencySystem>> getValidForceAgencySystems()
    {
        if(shouldUpdate(VALID_FORCE_AGENCY_SYSTEMS_UPDATED) || VALID_FORCE_AGENCY_SYSTEMS.isEmpty())
        {
            VALID_FORCE_AGENCY_SYSTEMS.clear();

            Connection connection = null;
            PreparedStatement statement = null;

            try
            {
                connection = openConnection();
                statement = connection.prepareStatement("SELECT * FROM forceagencysystem");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next())
                {
                    String forceAgency =  resultSet.getString("forceagency");
                    if(VALID_FORCE_AGENCY_SYSTEMS.get(forceAgency) == null)
                    {
                        List<ForceAgencySystem> systemsList = new ArrayList<>();
                        systemsList.add(new ForceAgencySystem(
                                resultSet.getString("forceagency"),
                                resultSet.getString("forceagencysystem"),
                                resultSet.getString("description"),
                                resultSet.getString("clms_context_loaded_yn"),
                                resultSet.getString("clms_contextmap_loaded_yn")));
                        VALID_FORCE_AGENCY_SYSTEMS.put(forceAgency, systemsList);
                    }
                    else
                    {
                        VALID_FORCE_AGENCY_SYSTEMS.get(forceAgency).add(new ForceAgencySystem(
                                forceAgency,
                                resultSet.getString("forceagencysystem"),
                                resultSet.getString("description"),
                                resultSet.getString("clms_context_loaded_yn"),
                                resultSet.getString("clms_contextmap_loaded_yn")));
                    }
                }
                statement.close();
                closeConnection(connection);
                VALID_FORCE_AGENCY_SYSTEMS_UPDATED = LocalDateTime.now();
            }
            catch (SQLException e) {
                logger.error("Error while querying the metadata database",e);
            }
            finally
            {
                try {
                    if(statement != null)
                    {
                        statement.close();
                    }
                    if(connection != null)
                    {
                        closeConnection(connection);
                    }
                }
                catch (SQLException e)
                {
                    logger.error("Error while interacting with the metadata database",e);
                }
            }
        }
        return VALID_FORCE_AGENCY_SYSTEMS;
    }

    /**
     * Return a map of all valid LEDS FTPS Channels against their description
     *
     * @return <code>Map<String,String></code>
     * */
    public static Map<String,String> getValidLedsFtpsChannels()
    {
        if(shouldUpdate(VALID_LEDS_FTPS_CHANNELS_UPDATED) || VALID_LEDS_FTPS_CHANNELS.isEmpty())
        {
            VALID_LEDS_FTPS_CHANNELS.clear();

            Connection connection = null;
            PreparedStatement statement = null;

            try
            {
                connection = openConnection();
                statement = connection.prepareStatement("SELECT * FROM leds_ftps_channels");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next())
                {
                    VALID_LEDS_FTPS_CHANNELS.put(resultSet.getString("channelname"),resultSet.getString("description"));
                }
                statement.close();
                closeConnection(connection);
                VALID_LEDS_FTPS_CHANNELS_UPDATED = LocalDateTime.now();
            }
            catch (SQLException e) {
                logger.error("Error while querying the metadata database",e);
            }
            finally
            {
                try {
                    if(statement != null)
                    {
                        statement.close();
                    }
                    if(connection != null)
                    {
                        closeConnection(connection);
                    }
                }
                catch (SQLException e)
                {
                    logger.error("Error while interacting with the metadata database",e);
                }
            }
        }
        return VALID_LEDS_FTPS_CHANNELS;
    }

    /**
     * Returns list of LedsFtpsServer objects mapping Server names to their description and the FTPS channel that they server
     *
     * @return <code>List<LedsFtpsServer></code>
     * @see LedsFtpsServer
     * */
    public static List<LedsFtpsServer> getValidLedsFtpsServers()
    {
        if(shouldUpdate(VALID_LEDS_FTPS_SERVERS_UPDATED) || VALID_LEDS_FTPS_SERVERS.isEmpty())
        {
            VALID_LEDS_FTPS_SERVERS.clear();

            Connection connection = null;
            PreparedStatement statement = null;

            try
            {
                connection = openConnection();
                statement = connection.prepareStatement("SELECT * FROM leds_ftps_servers");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next())
                {
                    VALID_LEDS_FTPS_SERVERS.add(new LedsFtpsServer(
                            resultSet.getString("servername"),
                            resultSet.getString("description"),
                            resultSet.getString("channelname")));
                }
                statement.close();
                closeConnection(connection);
                VALID_LEDS_FTPS_SERVERS_UPDATED = LocalDateTime.now();
            }
            catch (SQLException e) {
                logger.error("Error while querying the metadata database",e);
            }
            finally
            {
                try {
                    if(statement != null)
                    {
                        statement.close();
                    }
                    if(connection != null)
                    {
                        closeConnection(connection);
                    }
                }
                catch (SQLException e)
                {
                    logger.error("Error while interacting with the metadata database",e);
                }
            }
        }
        return VALID_LEDS_FTPS_SERVERS;
    }

    /**
     * Return a list of LedsFtpsChannelSecurityMarking containing information regarding
     * the availability (if they are allowed) of GPMS List values in various FTPS Channels
     *
     * @return <code>List<LedsFtpsChannelSecurityMarking></code>
     * @see LedsFtpsChannelSecurityMarking
     * */
    public static List<LedsFtpsChannelSecurityMarking> getLedsFtpsChannelSecurityMarkings()
    {
        if(shouldUpdate(LEDS_FTPS_CHANNEL_SECURITY_MARKINGS_UPDATED) || LEDS_FTPS_CHANNEL_SECURITY_MARKINGS.isEmpty())
        {
            LEDS_FTPS_CHANNEL_SECURITY_MARKINGS.clear();

            Connection connection = null;
            PreparedStatement statement = null;

            try
            {
                connection = openConnection();
                statement = connection.prepareStatement("SELECT * FROM leds_ftps_channel_security_markings");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next())
                {
                    LEDS_FTPS_CHANNEL_SECURITY_MARKINGS.add(new LedsFtpsChannelSecurityMarking(
                            resultSet.getString("channelname"),
                            resultSet.getString("gpmslist_value"),
                            resultSet.getString("allowedinchannel_yn")));
                }
                statement.close();
                closeConnection(connection);
                LEDS_FTPS_CHANNEL_SECURITY_MARKINGS_UPDATED = LocalDateTime.now();
            }
            catch (SQLException e) {
                logger.error("Error while querying the metadata database",e);
            }
            finally
            {
                try {
                    if(statement != null)
                    {
                        statement.close();
                    }
                    if(connection != null)
                    {
                        closeConnection(connection);
                    }
                }
                catch (SQLException e)
                {
                    logger.error("Error while interacting with the metadata database",e);
                }
            }
        }
        return LEDS_FTPS_CHANNEL_SECURITY_MARKINGS;
    }


    /**
     * Return a map of all valid GPMS List values against their description
     *
     * @return <code>Map<String,String></code>
     * */
    public static Map<String,String> getGPMSList()
    {
        if(shouldUpdate(GPMS_LIST_UPDATED) || GPMS_LIST.isEmpty())
        {
            GPMS_LIST.clear();

            Connection connection = null;
            PreparedStatement statement = null;

            try
            {
                connection = openConnection();
                statement = connection.prepareStatement("SELECT * FROM gpmslist");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next())
                {
                    GPMS_LIST.put(resultSet.getString("gpmslist_value"),resultSet.getString("description"));
                }
                statement.close();
                closeConnection(connection);
                GPMS_LIST_UPDATED = LocalDateTime.now();
            }
            catch (SQLException e) {
                logger.error("Error while querying the metadata database",e);
            }
            finally
            {
                try {
                    if(statement != null)
                    {
                        statement.close();
                    }
                    if(connection != null)
                    {
                        closeConnection(connection);
                    }
                }
                catch (SQLException e)
                {
                    logger.error("Error while interacting with the metadata database",e);
                }
            }
        }
        return GPMS_LIST;
    }

    /**
     * Returns a map of all FTPS server hostnames to a list of the valid GPMSList values
     *
     * @return <code>List<GPMSValuesForFTPSServer></code>
     * @see GPMSValuesForFTPSServer
     * */
    public static List<GPMSValuesForFTPSServer> getValidGPMSValuesForFTPSServers()
    {
        if(shouldUpdate(VALID_GPMS_VALUES_FOR_FTPS_SERVERS_UPDATED) || VALID_GPMS_VALUES_FOR_FTPS_SERVERS.isEmpty())
        {
            VALID_GPMS_VALUES_FOR_FTPS_SERVERS.clear();

            Connection connection = null;
            PreparedStatement statement = null;

            try
            {
                connection = openConnection();
                statement = connection.prepareStatement(
                        "select svr.servername, mkg.gpmslist_value\n" +
                                "  from "+connection.getSchema()+".leds_ftps_servers svr\n" +
                                "  inner join "+connection.getSchema()+".leds_ftps_channel_security_markings mkg\n" +
                                "        on ( mkg.channelname = svr.channelname )\n" +
                                "  where mkg.allowedinchannel_yn = 'Y'\n" +
                                "  order by servername");
                ResultSet resultSet = statement.executeQuery();

                Map<String,List<String>> mappings = new HashMap<>();

                while (resultSet.next())
                {
                    //A server name may have multiple mappings
                    if(mappings.keySet().contains(resultSet.getString("servername")))
                    {
                        mappings.get(resultSet.getString("servername")).add(resultSet.getString("gpmslist_value"));
                    }
                    else
                    {
                        mappings.put(resultSet.getString("servername"),new LinkedList<String>( Collections.singletonList(resultSet.getString("gpmslist_value")) ));
                    }
                }

                for(String servername : mappings.keySet())
                {
                    VALID_GPMS_VALUES_FOR_FTPS_SERVERS.add(new GPMSValuesForFTPSServer(servername, mappings.get(servername)));
                }

                VALID_GPMS_VALUES_FOR_FTPS_SERVERS_UPDATED = LocalDateTime.now();
            }
            catch (SQLException e) {
                logger.error("Error while querying the metadata database",e);
            }
            finally
            {
                try {
                    if(statement != null)
                    {
                        statement.close();
                    }
                    if(connection != null)
                    {
                        closeConnection(connection);
                    }
                }
                catch (SQLException e)
                {
                    logger.error("Error while interacting with the metadata database",e);
                }
            }
        }
        return VALID_GPMS_VALUES_FOR_FTPS_SERVERS;
    }


    public static Map<String,String> getValidRecordTypeListValues()
    {

        if(shouldUpdate(VALID_RECORD_TYPE_LIST_VALUES_UPDATED) || VALID_RECORD_TYPE_LIST_VALUES.isEmpty())
        {
            VALID_RECORD_TYPE_LIST_VALUES.clear();

            Connection connection = null;
            PreparedStatement statement = null;

            try
            {
                connection = openConnection();
                statement = connection.prepareStatement("SELECT CodeListValue, CodeListValueDescription FROM StandardCodes WHERE TableName = ? AND FieldName = ? AND CodeListName = ?");

                statement.setString(1,"RecordHeader");
                statement.setString(2,"RecordTypeList");
                statement.setString(3,"RecordVersionRecordTypeList");

                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next())
                {
                    VALID_RECORD_TYPE_LIST_VALUES.put(resultSet.getString("CodeListValue"),resultSet.getString("CodeListValueDescription"));
                }
                statement.close();
                closeConnection(connection);
                VALID_RECORD_TYPE_LIST_VALUES_UPDATED = LocalDateTime.now();
            }
            catch (SQLException e) {
                logger.error("Error while querying the metadata database",e);
            }
            finally
            {
                try {
                    if(statement != null)
                    {
                        statement.close();
                    }
                    if(connection != null)
                    {
                        closeConnection(connection);
                    }
                }
                catch (SQLException e)
                {
                    logger.error("Error while interacting with the metadata database",e);
                }
            }
        }
        return VALID_RECORD_TYPE_LIST_VALUES;
    }


    public static Map<String,String> getValidHandlingListValues()
    {

        if(shouldUpdate(VALID_HANDLING_LIST_VALUES_UPDATED) || VALID_HANDLING_LIST_VALUES.isEmpty())
        {
            VALID_HANDLING_LIST_VALUES.clear();

            Connection connection = null;
            PreparedStatement statement = null;

            try
            {
                connection = openConnection();
                statement = connection.prepareStatement("SELECT CodeListValue, CodeListValueDescription FROM StandardCodes WHERE FieldName = ? AND CodeListName = ?");

                statement.setString(1,"HandlingList");
                statement.setString(2,"RecordHandlingList");

                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next())
                {
                    VALID_HANDLING_LIST_VALUES.put(resultSet.getString("CodeListValue"),resultSet.getString("CodeListValueDescription"));
                }
                statement.close();
                closeConnection(connection);
                VALID_HANDLING_LIST_VALUES_UPDATED = LocalDateTime.now();
            }
            catch (SQLException e) {
                logger.error("Error while querying the metadata database",e);
            }
            finally
            {
                try {
                    if(statement != null)
                    {
                        statement.close();
                    }
                    if(connection != null)
                    {
                        closeConnection(connection);
                    }
                }
                catch (SQLException e)
                {
                    logger.error("Error while interacting with the metadata database",e);
                }
            }
        }
        return VALID_HANDLING_LIST_VALUES;
    }



    public static Map<String,String> getValidAssocationRoleListValues()
    {

        if(shouldUpdate(VALID_ASSOCIATION_ROLE_LIST_VALUES_UPDATED) || VALID_ASSOCIATION_ROLE_LIST_VALUES.isEmpty())
        {
            VALID_ASSOCIATION_ROLE_LIST_VALUES.clear();

            Connection connection = null;
            PreparedStatement statement = null;

            try
            {
                connection = openConnection();
                statement = connection.prepareStatement("SELECT CodeListValue, CodeListValueDescription FROM StandardCodes WHERE TableName = ? AND FieldName = ? AND CodeListName = ?");

                statement.setString(1,"Association");
                statement.setString(2,"Role");
                statement.setString(3,"AssociationRoleList");

                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next())
                {
                    VALID_ASSOCIATION_ROLE_LIST_VALUES.put(resultSet.getString("CodeListValue"),resultSet.getString("CodeListValueDescription"));
                }
                statement.close();
                closeConnection(connection);
                VALID_ASSOCIATION_ROLE_LIST_VALUES_UPDATED = LocalDateTime.now();
            }
            catch (SQLException e) {
                logger.error("Error while querying the metadata database",e);
            }
            finally
            {
                try {
                    if(statement != null)
                    {
                        statement.close();
                    }
                    if(connection != null)
                    {
                        closeConnection(connection);
                    }
                }
                catch (SQLException e)
                {
                    logger.error("Error while interacting with the metadata database",e);
                }
            }
        }
        return VALID_ASSOCIATION_ROLE_LIST_VALUES;
    }
}
