package uk.gov.homeoffice.dpp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Handles the .finished extensions as this can be appear throughout multiple steps
 * @author M.Koskinas
 */
public final class DotFinishedHandler {

    private static final Logger logger = LoggerFactory.getLogger(DotFinishedHandler.class);

    public static String errorCode = "HC-0010";


    private static final String FILE_APPENDER = ".finished";

    public static boolean rename(FileMetadata fileMetadata)
    {
        Map<String,String> errors = new HashMap<>();

        Path path = Paths.get(fileMetadata.getOriginalFilePath());
        Path finishedPath = Paths.get(appendDotFinished(path.toString()));

        logger.info("Appending {} extension to file {}", FILE_APPENDER, path.getFileName().toString());

        if(validateFile(finishedPath))
        {
            return true;
        }
        if (!validateFile(path))
        {
            logger.error("File {} did not exist", path.toString());

            errors.put(errorCode,"File doesn't exist");
            return false;
        }

        if(!renameFile(path, fileMetadata))
        {
            errors.put(errorCode,"File doesn't exist");
            return false;
        }

        return true;
    }

    /**
     * Renames the file passed to it to have .finished appended to it
     * @param pathToFile path to file that is to be renamed to .finished
     * @return true if successful in renaming, false otherwise
     */
    private static boolean renameFile(Path pathToFile, FileMetadata fileMetadata)
    {
        Path newFileName = Paths.get(DotFinishedHandler.appendDotFinished(pathToFile.toString()));
        try
        {
            Files.move(pathToFile, newFileName);
            fileMetadata.setCurrentPath(newFileName);
            FileTime curTime = FileTime.fromMillis(System.currentTimeMillis());
            Files.setLastModifiedTime(newFileName, curTime);
        }
        catch(IOException ioe)
        {
            logger.error("Error when renaming file from {} to {}", pathToFile.toString(), newFileName.toString(), ioe);
            return false;
        }

        return true;
    }

    /**
     * Checks whether the path exists
     * @param pathToFile the path to be checked
     * @return true if the path exists, false if it doesn't
     */
    private static boolean validateFile(Path pathToFile)
    {
        return pathToFile.toFile().exists();
    }

    /**
     * Adds a .finished onto the end of a file
     * @param filepath path to the file which is to have it's name modified
     * @return the path with .finished on the end of it
     */
    public static final String appendDotFinished(String filepath)
    {
        String fileTAppend = filepath;

        if(!fileTAppend.contains(".finished"))
            fileTAppend = fileTAppend.concat(".finished");

        return fileTAppend;
    }

    /**
     * Removes .finished from a filepath
     * @param filepath The filepath to remove .finished from
     * @return filepath without the .finished
     */
    public static final String removeDotFinished(String filepath)
    {
        String fileTRemove = filepath;

        if(fileTRemove.contains(".finished"))
        {
            fileTRemove = fileTRemove.replace(".finished","");
        }
        return fileTRemove;
    }
}
