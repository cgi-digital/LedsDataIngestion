package uk.gov.homeoffice.dpp.healthchecks.persistence.entities;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by C.Barnes on 01/03/2017.
 */
@Entity
@NamedEntityGraph(name = "graph.DPPFile.audits",
        attributeNodes = @NamedAttributeNode("audits"))
@Table(name = "ho_file_details")
public class DPPFile {

    @Id
    @Column(name = "hofd_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "hofd_received")
    private Date received;

    @Column(name = "hofd_vsstart")
    private Date vsstart;

    @Column(name = "hofd_vsfinish")
    private Date vsfinish;

    @Column(name = "hofd_originalfilepath")
    private String originalFilePath;

    @Column(name = "hofd_filepath")
    private String filepath;

    @Column(name = "hofd_status")
    private String status;

    @Column(name = "hofd_guid")
    private String guid;

    @Column(name = "hofd_filename")
    private String filename;

    @Column(name = "hofd_filesize")
    private long filesize;

    @Column(name = "hofd_checksum")
    private String checksum;

    @Column(name = "hofd_forceid")
    private String forceID;

    @Column(name = "hofd_laststatusupdate")
    private Date lastStatusUpdate;

    @Column(name = "hofd_lsr")
    private String lsr;

    @Column(name = "hofd_respfile")
    private String respFile;

    @Column(name = "hofd_prioritylevel")
    private String priorityLevel;

    @OneToMany(mappedBy = "file", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Audit> audits;

    @OneToMany(mappedBy = "fileID", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<FileError> fileErrors;

    public DPPFile()
    {
        fileErrors = new ArrayList<>();
        audits = new ArrayList<>();
        //Left empty for use by Spring

        this.lsr = "NONE";
        this.respFile = "NONE";
     }

    public DPPFile(Long id)
    {
        this.id = id;
        fileErrors = new ArrayList<>();
        audits = new ArrayList<>();

        this.lsr = "NONE";
        this.respFile = "NONE";
    }

    public DPPFile(String pathToFile, String filename, String forceID, String checksum, Date fileReceived, String status)
    {
        this.filepath = pathToFile;
        this.filename = filename;
        this.forceID = forceID;
        this.checksum = checksum;
        this.received = fileReceived;
        this.status = status;
        this.lsr = "NONE";
        this.respFile = "NONE";
        fileErrors = new ArrayList<>();
    }

    public DPPFile(Date fileReceived, Date vsstart, Date vsfinish, String originalFilePath, String pathToFile, String status, String filename, String guid, long filesize, String checksum, String forceID, String priorityLevel){
        this.received = fileReceived;
        this.vsstart = vsstart;
        this.vsfinish = vsfinish;
        this.originalFilePath = originalFilePath;
        this.filepath = pathToFile;
        this.filename = filename;
        this.guid = guid;
        this.status = status;
        this.filesize = filesize;
        this.checksum = checksum;
        this.forceID = forceID;
        this.lsr = "NONE";
        this.respFile = "NONE";
        this.priorityLevel = priorityLevel;
        fileErrors = new ArrayList<>();
    }


    public List<Audit> getAudits() {
        return audits;
    }

    public void setAudits(List<Audit> audits) {
        this.audits = audits;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getReceived() {
        return received;
    }

    public void setReceived(Date received) {
        this.received = received;
    }

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    public String output() {

        String sp = ", ";
        return this.id + sp + this.received + sp + this.filepath;
    }

    @Override
    public String toString() {
        String result = String.format(
                "DPPFile[id=%s, received='%s', filepath='%s']%n",
                id, received.toString(), filepath);

        return result;
    }

    public String toCompleteString() {
        StringBuilder res = new StringBuilder();

        String result = String.format(
                "DPPFile[id=%s, received='%s', filepath='%s']%n",
                id, received.toString(), filepath);

        res.append(result);

        for (Audit audit: audits)
        {
            res.append(String.format(audit.toString()));
        }

        return res.toString();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public long getFilesize() {
        return filesize;
    }

    public void setFilesize(long filesize) {
        this.filesize = filesize;
    }

    public String getChecksum() {
        return checksum;
    }

    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }

    public String getForceID() {
        return forceID;
    }

    public void setForceID(String forceID) {
        this.forceID = forceID;
    }

    public Date getLastStatusUpdate() {
        return lastStatusUpdate;
    }

    public void setLastStatusUpdate(Date lastStatusUpdate) {
        this.lastStatusUpdate = lastStatusUpdate;
    }

    public String getLsr() {
        return lsr;
    }

    public void setLsr(String lsr) {
        this.lsr = lsr;
    }

    public String getRespFile() {
        return respFile;
    }

    public void setRespFile(String respFile) {
        this.respFile = respFile;
    }

    public Date getVsstart() {
        return vsstart;
    }

    public void setVsstart(Date vsstart) {
        this.vsstart = vsstart;
    }

    public Date getVsfinish() {
        return vsfinish;
    }

    public void setVsfinish(Date vsfinish) {
        this.vsfinish = vsfinish;
    }

    public String getOriginalFilePath() {
        return originalFilePath;
    }

    public void setOriginalFilePath(String originalFilePath) {
        this.originalFilePath = originalFilePath;
    }

    public String getPriorityLevel() {
        return priorityLevel;
    }

    public void setPriorityLevel(String priorityLevel) {
        this.priorityLevel = priorityLevel;
    }

    public List<FileError> getFileErrors() {
        return fileErrors;
    }

    public void setFileErrors(List<FileError> fileErrors) {
        this.fileErrors = fileErrors;
    }

    public void addFileError(FileError fileError)
    {
        this.fileErrors.add(fileError);
    }

    public void addAudit(Audit audit) {
        this.audits.add(audit);
    }
}
