package uk.gov.homeoffice.dpp.healthchecks.ledsqueue;

import net.minidev.json.JSONObject;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPFile;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;

import java.util.Date;

/**
 * Created by M.Koskinas on 25/07/2017.
 */
public class FileStatusUpdateRequest
{
    private DPPFile file;
    private UpdategramStats stats;
    private String status;
    private String state;
    private Date statusDateTime;
    private String errorCode;
    private String errorDescription;

    public FileStatusUpdateRequest(DPPFile file, UpdategramStats stats, String status, Date statusDateTime, String state, String errorCode, String errorDescription)
    {
        this.file = file;
        this.stats = stats;
        this.status = status;
        this.state = state;
        this.statusDateTime = statusDateTime;
        this.errorCode = errorCode;
        this.errorDescription = errorDescription;
    }

    public String extractInfoIntoJSON()
    {
        JSONObject jsonMessage = new JSONObject();

        jsonMessage.put("GUID", file.getGuid());
        jsonMessage.put("OrigFileName", file.getFilename());
        jsonMessage.put("ForceAgency", file.getForceID());
        jsonMessage.put("State", this.state);
        jsonMessage.put("OverallStatus", this.status);
        jsonMessage.put("StatusDateTime", this.statusDateTime);
        jsonMessage.put("ErrorCode",this.errorCode);
        jsonMessage.put("ErrorDescription",this.errorDescription);

        if(stats == null)
        {
            jsonMessage.put("FileType", "");
            jsonMessage.put("ForceSystem", "");
            jsonMessage.put("MessageCount", "");
        }
        else
        {
            jsonMessage.put("FileType", stats.getBatchType());
            jsonMessage.put("ForceSystem", ""); //TODO Need to gather the forceSystem at some point
            jsonMessage.put("MessageCount", stats.getMessages());
        }

        return jsonMessage.toString();
    }
}
