package uk.gov.homeoffice.dpp.healthchecks.persistence.services;

import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPFile;

import java.util.Date;
import java.util.List;

/**
 * Created by C.Barnes on 01/03/2017.
 */
public interface DPPFileService {

    List<DPPFile> getAllFiles();

    List<DPPFile> getAllFilesByFilepath(String filePath);

    List<DPPFile> getAllFilesReceivedBetween(Date from, Date to);

    List<DPPFile> getAllFilesWithAudits();

    DPPFile createFile(Date fileReceived, Date vsstart, Date vsfinish, String originalFilePath, String pathToFile, String status, String filename, String guid, long filesize, String checksum, String forceId, String priorityLevel);

    DPPFile createFile(DPPFile fileToCreate, Date fileReceived, Date vsstart, Date vsfinish, String originalFilePath, String pathToFile,String status, String filename, String guid, long filesize, String checksum, String forceID, String priorityLevel);

    DPPFile updateFile(DPPFile dppFile);

    DPPFile getFileById(Long guid);

    public DPPFile getFileByGuid(String guid);

    public List<DPPFile> getFileByStatus(String status);

    public List<DPPFile> getFileByFilename(String filename);

    public List<DPPFile> getFilesByForceId(String forceId);

    public DPPFile getFileByChecksum(String checksum);

    public List<DPPFile>  getFileByChecksumAndFilenameAndForceID(String checksum, String filename, String forceID);

    public List<DPPFile> getFilesByPriorityLevel(String priorityLevel);
}
