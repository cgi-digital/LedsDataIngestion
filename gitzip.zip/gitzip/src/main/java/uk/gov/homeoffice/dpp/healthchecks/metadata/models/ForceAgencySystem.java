package uk.gov.homeoffice.dpp.healthchecks.metadata.models;

/**
 * Created by M.Koskinas on 27/04/2017.
 */
public final class ForceAgencySystem
{
    private final String forceAgency;
    private final String forceAgencySystem;
    private final String description;
    private final String clms_context_loaded_yn;
    private final String clms_contextmap_loaded_yn;

    public ForceAgencySystem(String forceAgency, String forceAgencySystem, String description, String clms_context_loaded_yn, String clms_contextmap_loaded_yn)
    {
        this.forceAgency = forceAgency;
        this.forceAgencySystem = forceAgencySystem;
        this.description = description;
        this.clms_context_loaded_yn = clms_context_loaded_yn;
        this.clms_contextmap_loaded_yn = clms_contextmap_loaded_yn;
    }

    public String getForceAgency() {
        return forceAgency;
    }

    public String getForceAgencySystem() {
        return forceAgencySystem;
    }

    public String getDescription() {
        return description;
    }

    public String getClms_context_loaded_yn() {
        return clms_context_loaded_yn;
    }

    public String getClms_contextmap_loaded_yn() {
        return clms_contextmap_loaded_yn;
    }
}
