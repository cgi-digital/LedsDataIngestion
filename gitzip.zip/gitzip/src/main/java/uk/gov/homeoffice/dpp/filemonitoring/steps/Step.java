package uk.gov.homeoffice.dpp.filemonitoring.steps;


import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;

import java.util.Map;

/**
 * Created by koskinasm on 09/02/2017.
 */
public interface Step {

    public StepResult runStep(FileMetadata fileMetadata);

    public String getName();

    public Map<String,String> properties();

    public boolean isEnabled();
}
