package uk.gov.homeoffice.dpp.filemonitoring.virusscanning;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.filemonitoring.steps.StepSpecification;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/**
 * Parent class for the Operating System variants of
 * the Virus Scanning classes as almost all methods are the same
 * barring the ones that involve executing commands on the command line
 * @author C.Barnes
 */
public abstract class VirusScan {

    /**
     * The values that need to be returned
     * from the results
     */
    public enum VirusScanResultType {
        POSSIBLY_INFECTED, CLEAN, NOT_SCANNED
    }

    private static final Logger logger = LoggerFactory.getLogger(VirusScan.class);
    private List<String> vsOutput = new ArrayList<>();
    protected Path quarantineLocation;
    protected Path reportsLocation;
    protected boolean generateXMLReport;
    protected boolean generateTextReport;
    protected Path virusScanPath;

    /**
     * Constructor that assigns all the properties for
     * the Virus Scanning step from the configuration file and stores them
     * in the class
     * @param stepSpec object that holds all the step specifications
     */
    public VirusScan(StepSpecification stepSpec){
        this.quarantineLocation = Paths.get(stepSpec.getProperties().get("quarantine_location"));
        this.reportsLocation = Paths.get(stepSpec.getProperties().get("report_location"));
        this.virusScanPath = Paths.get(stepSpec.getProperties().get("virusscan_path"));
        this.generateXMLReport = Boolean.parseBoolean(stepSpec.getProperties().get("generate_xmlreport"));
        this.generateTextReport = Boolean.parseBoolean(stepSpec.getProperties().get("generate_textreport"));

    }

    /**
     * This method is used to execute the virus scan of
     * a specified file on the command line
     * @param fileTBScanned Path to the file to be scanned
     * @return A list of strings that the virus scan returned as a result
     */
    public List<String> runVirusScan(Path fileTBScanned)
    {
        List<String> output = new ArrayList<>();

        Process vscan;

        try{
            vscan = createVirusScanCommand(fileTBScanned).start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(vscan.getInputStream()));
            BufferedReader readerError = new BufferedReader(new InputStreamReader(vscan.getErrorStream()));

            String line;
            while((line = reader.readLine()) != null)
            {
                output.add(line);
            }


            while((line = readerError.readLine()) != null)
            {

                output.add(line);
            }

            vscan.waitFor();
        }
        catch (Exception e)
        {
            logger.error("Error while trying to virus scan {}", fileTBScanned, e);
        }

        vsOutput = output;
        return output;
    }

    /**
     * Creates the commands to run the Virus Scanner
     * with certain parameters on a particular system
     * @param fileTBScanned Path of the file to be virus scanned
     * @return returns a ProcessBuilder containing commands to run the Virus Scanner
     */
    protected abstract ProcessBuilder createVirusScanCommand(Path fileTBScanned);

    /**
     * Adds in commands to make sure all
     * detail is contained in the reports
     * @return List of commands to ensure full reporting
     */
    protected abstract List<String> addGeneralReportCommands();

    /**
     * Adds in commands to ensure an
     * xml report is to be created at the
     * {@link VirusScan#reportsLocation} location
     * @param fileTBScanned path to the file to be scanned
     * @return List of commands to ensure xml report created
     */
    protected abstract List<String> addXMLReportCommands(Path fileTBScanned);

    /**
     * Adds in commands to ensure a text
     * report is to be created at the
     * {@link VirusScan#reportsLocation} location
     * @param fileTBScanned path to the file to be scanned
     * @return List of commands to ensure text report created
     */
    protected abstract List<String> addTextReportCommands(Path fileTBScanned);

    /**
     * Iterates through the result text and pulls out
     * the necessary information, storing it in a enum map.
     * (e.g <INFECTED, <no. of infected files>>)
     * @return A hashmap storing info on how many files were {@link VirusScanResultType#POSSIBLY_INFECTED},
     * {@link VirusScanResultType#NOT_SCANNED} and {@link VirusScanResultType#CLEAN}
     */
    public Map<VirusScanResultType, Integer> returnResultSummary(){
        if(vsOutput.isEmpty()) {
            logger.error("There is no virus result stored in this class, are you sure you are calling runVirusScan beforehand?");
            return null;
        }

        int resultSize = vsOutput.size();
        int startPoint = 0;
        if(resultSize > 30)
            startPoint = resultSize - 30;

        //List<String> statList = new ArrayList<>();
        EnumMap<VirusScanResultType, Integer> statList = new EnumMap<>(VirusScanResultType.class);

        for(int i = startPoint; i < resultSize && statList.size() < 3; i++)
        {
            String resultLine = vsOutput.get(i);
            if(resultLine.contains("Possibly Infected:..."))
            {
                String[] splitResult = resultLine.split("\\.+");

                statList.put(VirusScanResultType.POSSIBLY_INFECTED, Integer.parseInt(splitResult[1].trim()));

            }
            else if (resultLine.contains("Not Scanned:..."))
            {
                String[] splitResult = resultLine.split("\\.+");
                statList.put(VirusScanResultType.NOT_SCANNED, Integer.parseInt(splitResult[1].trim()));
            }
            else if (resultLine.contains("Clean:..."))
            {
                String[] splitResult = resultLine.split("\\.+");
                statList.put(VirusScanResultType.CLEAN, Integer.parseInt(splitResult[1].trim()));
            }
        }

        return statList;
    }

    public List<String> getVsOutput() {
        return vsOutput;
    }

    public void setVsOutput(List<String> vsOutput) {
        this.vsOutput = vsOutput;
    }
}
