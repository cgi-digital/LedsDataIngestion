package uk.gov.homeoffice.dpp.filemonitoring.steps;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.DotFinishedHandler;
import uk.gov.homeoffice.dpp.filemonitoring.utilities.FileandDirHandler;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Map;

/**
 * This step untars a .tar file into a list of {@link FileMetadata} objects
 * each relating to a file within the tar
 * @author C.Barnes
 */
public class UnTarStep implements Step{

    private static final Logger logger = LoggerFactory.getLogger(UnTarStep.class);
    public static final String TEMP_UNTAR_NAME = "TempTar";

    private boolean enabled;
    private Path tempStorage;
    private String errorCode = null;

    private FileMetadata currentMetadataFile;

    /**
     * Constructor for UnTarStep assigns the properties
     * attributed to this step in the yml properties file
     * @param stepSpecification information about the step from the properties file
     */
    public UnTarStep(StepSpecification stepSpecification)
    {
        this.enabled = stepSpecification.getStatus();
        this.tempStorage = Paths.get(FTPManagerConfiguration.getTempStoragePath().toString() + "/" + TEMP_UNTAR_NAME);
    }

    /**
     * Executes the Untarring Step on the {@link FileMetadata#currentPath}
     * and creates multiple metadata objects for each of the output files
     * @param fileMetadata The FileMetadata object referring to the .tar file
     * @return A {@link StepResult} object detailing whether it was successful, if there is an error code
     * and a list of the new metadata objects that came from the .tar
     */
    @Override
    public StepResult runStep(FileMetadata fileMetadata) {

        if(!FileandDirHandler.createTarTempFolder())
        {
            logger.error("Error creating temporary untarring folder for {}", fileMetadata.getOriginalFilePath());
            errorCode = "10";
            return new StepResult(false, errorCode, fileMetadata);
        }

        currentMetadataFile = fileMetadata;
        Path path = fileMetadata.getCurrentPath();

        StepResult result = untarFile(path);


        return result;

    }

    /**
     * Untars a .tar file into a temporary directory
     * @param tarPath path to the .tar file
     * @return @return A {@link StepResult} object detailing whether it was successful, if there is an error code
     * and a list of the new metadata objects that came from the .tar
     */
    private StepResult untarFile(Path tarPath)
    {
        boolean success = true;
        File tar = new File(tarPath.toString());
        logger.info("Starting to untar {}", tarPath.toString());

        ArrayList<FileMetadata> untarredFilesMetadata =  new ArrayList<>();
        InputStream input = null;
        TarArchiveInputStream tarInput = null;
        BufferedOutputStream outputStream = null;

        try {
            input = new FileInputStream(tar);
            tarInput = new TarArchiveInputStream(input);

            TarArchiveEntry tarEntry;
            while((tarEntry = tarInput.getNextTarEntry()) != null)
            {
                File newFile = new File(tempStorage.toString(), tarEntry.getName());

                logger.info("Creating {} from tar", newFile.getPath());

                if(tarEntry.isDirectory())
                {
                    if(!newFile.mkdirs())
                    {
                        logger.error("Could not create directory {} from tar {}", newFile.getPath(), tarPath.toString());
                        errorCode = "12";
                        break;
                    }
                }
                else
                {

                    if(!newFile.createNewFile())
                    {
                        logger.error("Could not create the new file {} from tar {}", newFile.getPath(), tarPath.toString());
                        errorCode = "11";
                        break;
                    }

                    byte[] byteToRead = new byte[1024];

                    outputStream = new BufferedOutputStream(new FileOutputStream(newFile));
                    int length;

                    while ((length = tarInput.read(byteToRead)) != -1)
                    {
                        outputStream.write(byteToRead, 0, length);
                    }

                    outputStream.close();
                    untarredFilesMetadata.add(new FileMetadata(newFile.toPath(), currentMetadataFile));
                }


            }



        } catch (FileNotFoundException e) {
            logger.error("File not found", e);
            errorCode = "3";
            success = false;

        } catch (IOException e) {
            logger.error("IO Error when attempting to untar file {}", tarPath.toString(), e);
            errorCode = "4";
            success = false;

        }
        finally {
            try {

                if (outputStream != null)
                    outputStream.close();

                if (tarInput != null)
                    tarInput.close();

                if (input != null)
                    input.close();
            }
            catch (IOException e)
            {
                logger.error("IO Error when attempting to close streams", e);
                errorCode = "5";
                success = false;
            }

        }

        if(!success)
            return new StepResult(false, errorCode, currentMetadataFile);

        return new StepResult(true, errorCode, untarredFilesMetadata);
    }

    /**
     * Used to delete all directories created when untarring. Will not delete
     * files so this should be done once all the files have been moved out
     * @return returns true if the all directories have been removed, false if not
     */
    public boolean unTarCleanup()
    {
        boolean success;
        if(currentMetadataFile == null)
            return true;

        Path dirPath = Paths.get(currentMetadataFile.getOriginalFilePath());
        String dirName = dirPath.getFileName().toString().replace(".tar", "");
        dirName = DotFinishedHandler.removeDotFinished(dirName);

        Path dirToDelete = Paths.get(tempStorage.toString() + "\\" + dirName);

        logger.info("Deleting temp directory and contents of {}", dirToDelete.toString());

        if(!dirToDelete.toFile().exists())
            return true;

        success =  FileandDirHandler.deleteDirectoryAndAllContentsExceptFiles(dirToDelete);

        if(success)
            success = FileandDirHandler.deleteFile(currentMetadataFile.getCurrentPath());

        return success;

    }

    @Override
    public String getName() {
        return "untarring";
    }

    @Override
    public Map<String, String> properties() {
        return null;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }

    public Path getTempStorage() {
        return tempStorage;
    }

    public void setTempStorage(Path tempStorage) {
        this.tempStorage = tempStorage;
    }
}
