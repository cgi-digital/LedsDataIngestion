package uk.gov.homeoffice.dpp.filemonitoring.steps;

import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;

import java.util.ArrayList;
import java.util.List;

/**
 * Outlines the result from a step
 * @author C.Barnes, M.Koskinas
 */
public class StepResult {

    private boolean success;
    private String errorCode;
    private List<FileMetadata> currentFiles = new ArrayList<>();

    /**
     * To be used when the step is only returning one file
     * @param success True if the step passed, false if it failed
     * @param errorCode If it failed the errorcode relating to {@link uk.gov.homeoffice.dpp.filemonitoring.error.ErrorMsg}
     * @param currentFile The Metadata object containing the current working file and it's attributes
     */
    public StepResult(boolean success, String errorCode, FileMetadata currentFile)
    {
        this.success = success;
        this.errorCode = errorCode;

        this.currentFiles = new ArrayList<>();
        this.currentFiles.add(currentFile);
    }

    /**
     * To be used when the step is returning more than one file (such as the Untar step)
     * @param success True if the step passed, false if it failed
     * @param errorCode If it failed the errorcode relating to {@link uk.gov.homeoffice.dpp.filemonitoring.error.ErrorMsg}
     * @param currentFiles A list of Metadata objects, each containing a working file and it's attributes
     */
    public StepResult(boolean success, String errorCode, List<FileMetadata> currentFiles)
    {
        this.success = success;
        this.errorCode = errorCode;

        this.currentFiles = new ArrayList<>();
        this.currentFiles = currentFiles;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public List<FileMetadata> getCurrentFiles() {
        return currentFiles;
    }
}
