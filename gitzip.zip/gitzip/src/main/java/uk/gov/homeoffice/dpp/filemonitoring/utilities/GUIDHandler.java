package uk.gov.homeoffice.dpp.filemonitoring.utilities;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import org.apache.commons.io.FilenameUtils;

/**
 * Handles GUID generating and renaming for files
 * @author C.Barnes
 */
public final class GUIDHandler {

    /**
     * Generates a random GUID
     * @return returns the randomly generated GUID
     */
    public static UUID guidGenerator()
    {
        UUID uuid = UUID.randomUUID();
        return uuid;
    }

    /**
     * Generates a random GUID and converts it into a string
     * @return returns generated GUID as a string
     */
    public static String guidGeneratorAsString()
    {
        UUID uuid = guidGenerator();
        return uuid.toString();
    }

    /**
     * Renames a given file's name to a given GUID
     * @param fileToRename path to the file to be renamed
     * @param guid GUID to be used when renaming
     * @return return new path of the renamed file
     * @throws IOException File has not been found or cannot be rewritten
     */
    public static Path renameFileToGuid(Path fileToRename, UUID guid) throws IOException {

        String extension = FilenameUtils.getExtension(fileToRename.toString());

        String newPath = fileToRename.getParent() + "/" + guid + "." + extension;

        Files.move(fileToRename, Paths.get(newPath));

        return Paths.get(newPath);
    }

}
