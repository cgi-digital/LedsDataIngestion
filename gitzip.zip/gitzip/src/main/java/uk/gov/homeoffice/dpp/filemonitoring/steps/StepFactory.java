package uk.gov.homeoffice.dpp.filemonitoring.steps;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static uk.gov.homeoffice.dpp.filemonitoring.error.ErrorMsg.ERR0006;


/**
 * Used to generate the individual steps
 * with their corresponding properties
 * @author M.Koskinas
 */
public class StepFactory {

    private static final Logger logger = LoggerFactory.getLogger(StepFactory.class);

    /**
     * Used to create a step
     * @param name The name to specify which step to create
     * @param stepSpecification the properties corresponding to the chosen step
     * @return Either the created step or null if incorrectly specified
     */
    public static Step createStep(String name, StepSpecification stepSpecification)
    {
        Step step = null;

        if("metadata_creation".equals(name))
        {
            step = new MetadataCreationStep(stepSpecification);
        }
        else if("rename_to_finished".equals(name))
        {
            step = new RenameToFinishedStep(stepSpecification);
        }
        else if("virus_scanning".equals(name))
        {
            step = new VirusScanningStep(stepSpecification);
        }
        else if("file_forwarding".equals(name))
        {
            step = new FileForwardingStep(stepSpecification);
        }
        else if("untarring".equals(name))
        {
            step = new UnTarStep(stepSpecification);
        }
        else
        {
            logger.error(ERR0006.getValue(), name);
        }


        return step;
    }
}
