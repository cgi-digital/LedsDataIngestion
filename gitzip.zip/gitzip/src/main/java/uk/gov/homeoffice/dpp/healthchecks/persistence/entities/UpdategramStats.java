package uk.gov.homeoffice.dpp.healthchecks.persistence.entities;

/**
 * Created by M.Koskinas on 08/06/2017.
 */

import javax.persistence.*;

@Entity
@Table(name = "ho_updategram_stats")
public class UpdategramStats
{
    public UpdategramStats()
    {

    }

    public UpdategramStats(Long fileid)
    {
        this.fileid = fileid;
    }

    @Id
    @Column(name = "hofs_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "hofd_id")
    private Long fileid;

    @Column(name="hofs_messages")
    private int messages = 0;

    @Column(name="hofs_records")
    private int records = 0;

    @Column(name="hofs_publisher")
    private String publisher = null;

    @Column(name="hofs_recipient")
    private String recipient = null;

    @Column(name="hofs_batchtype")
    private String batchType = null;

    @Column(name="hofs_transactionlist")
    private String transactionList = null;

    @Column(name="hofs_securitychannel")
    private String securityChannel = null;

    @Column(name="hofs_protectivemarking")
    private String protectiveMarking = null;

    @Column(name="hofs_gpmslist")
    private String gpmsList = null;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFileid() {
        return fileid;
    }

    public void setFileid(Long fileid) {
        this.fileid = fileid;
    }

    public int getMessages() {
        return messages;
    }

    public void setMessages(int messages) {
        this.messages = messages;
    }

    public int getRecords() {
        return records;
    }

    public void setRecords(int records) {
        this.records = records;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getBatchType() {
        return batchType;
    }

    public void setBatchType(String batchType) {
        this.batchType = batchType;
    }

    public String getTransactionList() {
        return transactionList;
    }

    public void setTransactionList(String transactionList) {
        this.transactionList = transactionList;
    }

    public String getSecurityChannel() {
        return securityChannel;
    }

    public void setSecurityChannel(String securityChannel) {
        this.securityChannel = securityChannel;
    }

    public String getProtectiveMarking() {
        return protectiveMarking;
    }

    public void setProtectiveMarking(String protectiveMarking) {
        this.protectiveMarking = protectiveMarking;
    }

    public String getGpmsList() {
        return gpmsList;
    }

    public void setGpmsList(String gpmsList) {
        this.gpmsList = gpmsList;
    }
}
