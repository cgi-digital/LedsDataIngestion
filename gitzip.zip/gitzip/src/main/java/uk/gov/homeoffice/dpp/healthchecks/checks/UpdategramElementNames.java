package uk.gov.homeoffice.dpp.healthchecks.checks;

/**
 * Created by M.Koskinas on 05/05/2017.
 */
public final class UpdategramElementNames
{
    public static final String BATCH_HEADER = "BatchHeader";
    public static final String PUBLISHER = "Publisher";
    public static final String RECIPIENT = "Recipient";

    public static final String ENTITY_RECORD_HEADER = "EntityRecordHeader";
    public static final String ATTACHMENT_RECORD_HEADER = "AttachmentRecordHeader";
    public static final String RECORD_HEADER = "RecordHeader";
    public static final String EVENT_RECORD_HEADER = "EventRecordHeader";

    public static final String EVENT_RECORD = "EventRecord";

    public static final String RECORD_MESSAGE = "RecordMessage";
    public static final String ATTATCHMENT_MESSAGE = "AttachmentMessage";
    public static final String EVENT_MESSAGE = "EventMessage";

    public static final String FORCE_AGENCY_LIST = "ForceAgencyList";
    public static final String FORCE_AGENCY_SYSTEM_NAME_TEXT = "ForceAgencySystemNameText";
    public static final String HANDLING_LIST ="HandlingList";
    public static final String TRANSACTION_LIST ="TransactionList";
    public static final String MESSAGE_TRANSACTION_LIST = "MessageTransactionList";
    public static final String MESSAGE_DATE_TIME = "MessageDateTime";
    public static final String RECORD_TYPE_LIST = "RecordTypeList";
    public static final String GPMS_LIST = "GPMSList";

    public static final String ASSOCIATION = "Association";
    public static final String SOURCE_ASSOCIATION_IDENTIFIERS = "SourceAssociationIdentifiers";
    public static final String TARGET_ASSOCIATION_IDENTIFIERS = "TargetAssociationIdentifiers";
    public static final String ROLE = "Role";

    public static final String IMAGE_DATA = "ImageData";

}
