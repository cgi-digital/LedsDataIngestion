package uk.gov.homeoffice.dpp.healthchecks.metadata.models;

/**
 * Created by M.Koskinas on 27/04/2017.
 */
public final class LedsFtpsServer
{
    private final String servername;
    private final String description;
    private final String channelname;

    public LedsFtpsServer(String servername, String description, String channelname)
    {
        this.servername = servername;
        this.description = description;
        this.channelname = channelname;
    }

    public String getServername() {
        return servername;
    }

    public String getDescription() {
        return description;
    }

    public String getChannelname() {
        return channelname;
    }
}
