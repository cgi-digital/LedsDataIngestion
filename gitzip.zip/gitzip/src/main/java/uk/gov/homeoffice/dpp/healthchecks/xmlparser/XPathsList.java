package uk.gov.homeoffice.dpp.healthchecks.xmlparser;

/**
 * Created by M.Koskinas on 20/04/2017.
 */
public final class XPathsList {
    public static final String BATCH_HEADER_PUBLISHER = "*/BatchHeader/Publisher";
    public static final String BATCH_HEADER_RECIPIENT = "*/BatchHeader/Recipient";
    public static final String BATCH_HEADER_TRANSACTIONLIST = "*/BatchHeader/TransactionList";
    public static final String BATCH_HEADER_BATCH_REFERENCE = "*/BatchHeader/BatchReference";

}
