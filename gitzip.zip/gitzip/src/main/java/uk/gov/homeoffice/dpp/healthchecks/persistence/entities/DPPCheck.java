package uk.gov.homeoffice.dpp.healthchecks.persistence.entities;

import javax.persistence.*;
import java.util.List;

/**
 * Created by C.Barnes on 01/03/2017.
 */
@Entity
@Table(name = "ho_check_details")
public class DPPCheck {

    @Id
    @Column(name = "hocd_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="hocd_active")
    private boolean active;

    @Column(name="hocd_name")
    private String name;

    @Column(name="hocd_description")
    private String description;

    @OneToMany(mappedBy = "check", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Audit> auditList;

    DPPCheck()
    {

    }

    public DPPCheck(Long id){
        this.id = id;
    }

    public DPPCheck(Long id, boolean isActive, String checkName, String checkDesc)
    {
        this.id = id;
        this.active = isActive;
        this.name = checkName;
        this.description = checkDesc;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Audit> getAuditList() {
        return auditList;
    }

    public void setAuditList(List<Audit> auditList) {
        this.auditList = auditList;
    }

    public String output() {
        String sp = ", ";

        return this.id + sp + this.name + sp + this.active + sp + this.description;
    }

    @Override
    public String toString() {
        return  String.format(
                "DPPCheck[id=%d, active='%b', name='%s', Desc='%s']%n",
                id, active, name, description);

    }

    public String toCompleteString(){
        StringBuilder res = new StringBuilder();

        String result =  String.format(
                "DPPCheck[id=%d, active='%b', name='%s', Desc='%s']%n",
                id, active, name, description);

        res.append(result);

        for (Audit audit: auditList)
        {
            res.append(String.format(audit.toString()));
        }

        return res.toString();
    }

}
