package uk.gov.homeoffice.dpp.healthchecks.steps;

import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;

import java.io.File;
import java.util.Map;

/**
 * Created by koskinasm on 09/02/2017.
 */
public interface Step {

    /**
     * Perform the check on the provided input file
     *
     * @param file the file on which the check will be performed
     *
     * @param fileMetadata
     * @return Checkresult the result of the check's execution
     * @see StepResult
     * */
    public StepResult runCheck(File file, Long fileID, FileMetadata fileMetadata, UpdategramStats stats);

    public String getName();

    public Long getID();

    public Map<String,String> getProperties();

    public boolean isEnabled();
}
