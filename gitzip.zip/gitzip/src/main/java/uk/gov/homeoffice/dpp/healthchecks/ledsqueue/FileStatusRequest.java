package uk.gov.homeoffice.dpp.healthchecks.ledsqueue;

import net.minidev.json.JSONObject;

/**
 * Created by M.Koskinas on 25/07/2017.
 */
public class FileStatusRequest
{
    private String uniqueFileName;
    private String originalFileName;

    public FileStatusRequest(String uniqueFileName, String originalFileName)
    {
        this.uniqueFileName = uniqueFileName;
        this.originalFileName = originalFileName;
    }

    public String extractInfoIntoJSON()
    {
        JSONObject jsonMessage = new JSONObject();

        jsonMessage.put("UniqueFileName", uniqueFileName);
        jsonMessage.put("OriginalFileName", originalFileName);

        return jsonMessage.toString();
    }
}
