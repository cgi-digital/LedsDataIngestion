package uk.gov.homeoffice.dpp.healthchecks.error;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

/**
 * Created by C.Barnes on 08/03/2017.
 */
public enum ErrorMsg {
    ERR0001, ERR0002, ERR0003, ERR0004, ERR0005, ERR0006;

    private static final Logger logger = LoggerFactory.getLogger(ErrorMsg.class);

    private Properties properties;

    private String value;

    private void init() {
        if(properties == null)
        {
            properties = new Properties();
            try{
                properties.load(ErrorMsg.class.getClassLoader().getResourceAsStream("error.properties"));
            }
            catch (Exception e)
            {
                logger.error("Could not load the error properties file", e);
            }
        }

        value = (String) properties.get(this.toString());
    }

    public String getValue()
    {
        if(value == null)
        {
            init();
        }

        return value;
    }
}
