package uk.gov.homeoffice.dpp.configuration.priorities;

/**
 * Created by C.Barnes on 06/07/2017.
 */
public class PriorityProperties {

    private boolean autoCollect;

    private int filesPerLoop;

    private int maxFileAge;

    public boolean isAutoCollect() {
        return autoCollect;
    }

    public void setAutoCollect(boolean autoCollect) {
        this.autoCollect = autoCollect;
    }

    public int getFilesPerLoop() {
        return filesPerLoop;
    }

    public void setFilesPerLoop(int filesPerLoop) {
        this.filesPerLoop = filesPerLoop;
    }

    public int getMaxFileAge() {
        return maxFileAge;
    }

    public void setMaxFileAge(int maxFileAge) {
        this.maxFileAge = maxFileAge;
    }
}
