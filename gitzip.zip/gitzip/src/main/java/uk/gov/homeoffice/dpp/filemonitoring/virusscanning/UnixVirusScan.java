package uk.gov.homeoffice.dpp.filemonitoring.virusscanning;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.filemonitoring.steps.StepSpecification;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * Class that handles running the Virus Scan
 * on a Unix machine
 * @author C.Barnes
 */
public class UnixVirusScan extends VirusScan {

    private static final Logger logger = LoggerFactory.getLogger(UnixVirusScan.class);

    /**
     * Just uses the same contructor at {@link VirusScan#VirusScan(StepSpecification)}
     * @param stepSpec Lays out the specification for the Virus Scanning Step
     */
    public UnixVirusScan(StepSpecification stepSpec)
    {
        super(stepSpec);
    }

    /**
     * Creates the commands to run the Virus Scanner
     * with certain parameters on a Unix system
     * @param fileTBScanned Path of the file to be virus scanned
     * @return returns a ProcessBuilder containing commands to run the Virus Scanner
     */
    @Override
    public ProcessBuilder createVirusScanCommand(Path fileTBScanned) {

        List<String> commands = new ArrayList<>();

        commands.add(virusScanPath.toString());
        commands.add("--unzip");

        if(generateTextReport || generateXMLReport)
            commands.addAll(addGeneralReportCommands());

        if(generateXMLReport)
            commands.addAll(addXMLReportCommands(fileTBScanned));

        if(generateTextReport)
            commands.addAll(addTextReportCommands(fileTBScanned));

        commands.add("-m");
        commands.add(quarantineLocation.toString());

        commands.add("--summary");

        commands.add(fileTBScanned.toString());

        return new ProcessBuilder(commands);

    }

    /**
     * Adds in commands to make sure all
     * detail is contained in the reports
     * @return List of commands to ensure full reporting
     */
    @Override
    protected List<String> addGeneralReportCommands() {

        List<String> genReportCmds = new ArrayList<>();

        genReportCmds.add("--rptall");
        genReportCmds.add("--rptcor");
        genReportCmds.add("--rpterr");

        return genReportCmds;

    }

    /**
     * Adds in commands to ensure an
     * xml report is to be created at the
     * {@link VirusScan#reportsLocation} location
     * @param fileTBScanned path to the file to be scanned
     * @return List of commands to ensure xml report created
     */
    @Override
    protected List<String> addXMLReportCommands(Path fileTBScanned)
    {
        List<String> xmlCommands = new ArrayList<>();
        Path wholeXMLReportPath = Paths.get(reportsLocation + "/" + fileTBScanned.getFileName().toString() + ".xml");

        xmlCommands.add("--xmlpath");
        xmlCommands.add(wholeXMLReportPath.toString());

        return xmlCommands;
    }

    /**
     * Adds in commands to ensure a text
     * report is to be created at the
     * {@link VirusScan#reportsLocation} location
     * @param fileTBScanned path to the file to be scanned
     * @return List of commands to ensure text report created
     */
    @Override
    protected List<String> addTextReportCommands(Path fileTBScanned)
    {
        List<String> reportCommands = new ArrayList<>();
        Path wholeTextReportPath = Paths.get(reportsLocation + "/" + fileTBScanned.getFileName().toString() + ".report");

        reportCommands.add("--report");
        reportCommands.add(wholeTextReportPath.toString());

        return reportCommands;
    }


}
