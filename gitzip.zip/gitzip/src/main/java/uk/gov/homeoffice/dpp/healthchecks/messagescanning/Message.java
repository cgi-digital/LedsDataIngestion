//package uk.gov.homeoffice.dpp.healthchecks.messagescanning;
//
//import java.nio.file.Path;
//
///**
// * Object representation of a message and it's
// * contents
// * Created by C.Barnes on 20/04/2017.
// */
//public class Message {
//
//    private Path fileToProcess;
//    boolean valid;
//
//    public Message()
//    {
//
//    }
//
//    public Message(boolean isValid)
//    {
//        this.valid = isValid;
//    }
//
//    public Message(Path file)
//    {
//        this.fileToProcess = file;
//    }
//
//
//    public Path getFileToProcess() {
//        return fileToProcess;
//    }
//
//    public void setFileToProcess(Path fileToProcess) {
//        this.fileToProcess = fileToProcess;
//    }
//
//    public boolean isValid() {
//        return valid;
//    }
//
//    public void setValid(boolean valid) {
//        this.valid = valid;
//    }
//}
