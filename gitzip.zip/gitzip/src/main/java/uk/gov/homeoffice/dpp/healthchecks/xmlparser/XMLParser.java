package uk.gov.homeoffice.dpp.healthchecks.xmlparser;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import uk.gov.homeoffice.dpp.configuration.HealthChecksConfiguration;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by M.Koskinas on 06/04/2017.
 */
@Component
public class XMLParser {

    private static final Logger logger = LoggerFactory.getLogger(XMLParser.class);

    public static final String ATTATCHMENTBATCH_TAG = "AttachmentBatch";
    public static final String RECORDBATCH_TAG = "RecordBatch";
    public static final String EVENTBATCH_TAG = "EventBatch";

    public static final String CLMS_CONTEXT_TAG = "Context";
    private static final String CLMS_CONTEXT_SCHEMA = "http://www.JoinedUpSystems.net/schemas/v4/Context-v4-3.xsd";

    public static final String CLMS_CONTEXTMAP_TAG = "ContextMap";
    private static final String CLMS_CONTEXTMAP_SCHEMA = "http://www.JoinedUpSystems.net/schemas/v4/ContextMap-v4-3.xsd";

    public static boolean isXMLFile(File file)
    {
        return getDocForFile(file) != null ? true : false;
    }

    /**
     * Parses the provided file and returns the file type
     *
     * @param file the file to be parsed
     *
     * @return <code>String</code> the type of the file
     * */
    public static String getFileType(File file)
    {
        String fileType = null;
        boolean rootElementDetected = false;

        Document doc = getDocForFile(file);

        if(doc != null)
        {
            for(int node = 0 ; node < doc.getChildNodes().getLength() && !rootElementDetected ; node++)
            {
                if(!"#comment".equals(doc.getChildNodes().item(node).getNodeName()))
                {
                    rootElementDetected = true;
                    if(doc.getChildNodes().item(node).getNodeName().equals(CLMS_CONTEXT_TAG))
                    {
                        if(doc.getChildNodes().item(node).getAttributes().getNamedItem("xsi:schemaLocation").getNodeValue().contains(CLMS_CONTEXT_SCHEMA))
                        {
                            fileType = CLMS_CONTEXT_TAG;
                        }
                    }
                    else if(doc.getChildNodes().item(node).getNodeName().equals(CLMS_CONTEXTMAP_TAG))
                    {
                        if(doc.getChildNodes().item(node).getAttributes().getNamedItem("xsi:schemaLocation").getNodeValue().contains(CLMS_CONTEXTMAP_SCHEMA))
                        {
                            fileType = CLMS_CONTEXTMAP_TAG;
                        }
                    }
                    else if(doc.getChildNodes().item(node).getNodeName().equals(ATTATCHMENTBATCH_TAG) ||
                            doc.getChildNodes().item(node).getNodeName().equals(RECORDBATCH_TAG)||
                            doc.getChildNodes().item(node).getNodeName().equals(EVENTBATCH_TAG))
                    {
                        fileType = doc.getChildNodes().item(node).getNodeName();
                    }
                }
            }
        }

        return fileType;
    }

    public static Document getDocForFile(File file)
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = null;
        Document doc = null;

        try
        {
            builder = factory.newDocumentBuilder();
        }
        catch (ParserConfigurationException e)
        {
            logger.error("Error while parsing file : {}", file.getName(), e);
        }

        if(builder != null)
        {
            try
            {
                doc = builder.parse(file);
                doc.getDocumentElement().normalize();
            }
            catch (SAXException saxe)
            {
                logger.error("Error while parsing file : {}", file.getName() , saxe);
            }
            catch (IOException ioe)
            {
                logger.error("Error while parsing file : {}", file.getName(),ioe );
            }
        }

        return doc;
    }

    private static Map<String,Schema> schemaMap = new HashMap<>();

    /**
     * Validates the provided xml file against the XSD schema defined by the provided fileType
     *
     * @param file
     * @param fileType the file type of the provided file
     *
     * @return <code>boolean</code> value indicating if the file metadata was successful
     * */
    public static boolean validateFile(File file, String fileType) {

        boolean validXML = true;
        String schemaFilename = HealthChecksConfiguration.xsdConfiguration.getTypeMappings().get(fileType);
        Schema schema = null;

        if(schemaMap.get(fileType) != null)
        {
            schema = schemaMap.get(fileType);
            logger.info("Using cached XSD schema for file {}", schemaFilename);
        }
        else
        {
            ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
            URL schemaFile = classLoader.getResource(HealthChecksConfiguration.xsdConfiguration.getXsdSchemasLocation()+schemaFilename);

            final SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

            try
            {
                logger.info("Instantiating XSD schema from file {}", schemaFile);
                schema = schemaFactory.newSchema(schemaFile);
                schemaMap.put(fileType,schema);
            }
            catch (SAXException e)
            {
                logger.error("Could not instantiate XSD schema from file: {}", HealthChecksConfiguration.xsdConfiguration.getXsdSchemasLocation()+schemaFilename, e);
                validXML = false;
            }
        }

        if(schema != null)
        {
            final Validator validator = schema.newValidator();
            try
            {
                validator.validate(new StreamSource(file));
            }
            catch (Exception e)
            {
                validXML = false;
                logger.error("File {} couldn't be validated", file.getName(), e);
            }
        }

        return validXML;
    }

}
