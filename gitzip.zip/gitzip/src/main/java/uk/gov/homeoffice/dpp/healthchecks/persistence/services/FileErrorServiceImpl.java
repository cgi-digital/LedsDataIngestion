package uk.gov.homeoffice.dpp.healthchecks.persistence.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.transaction.annotation.Transactional;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPFile;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.FileError;
import uk.gov.homeoffice.dpp.healthchecks.persistence.repositories.FileErrorRepository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

/**
 * Created by M.Koskinas on 08/05/2017.
 */
@Service("FileErrorService")
public class FileErrorServiceImpl implements FileErrorService {

    private static final Logger logger = LoggerFactory.getLogger(FileErrorServiceImpl.class);

    @PersistenceContext
    public EntityManager em;

    @Autowired
    private FileErrorRepository fileErrorRepository;

    @Override
    public List<FileError> findAll() {
        return fileErrorRepository.findAll();
    }

    @Override
    public FileError findById(Long id) {
        return fileErrorRepository.findById(id);
    }

    @Override
    public List<FileError> findByGuid(String guid) {
        return fileErrorRepository.findByGuid(guid);
    }

    @Override
    public List<FileError> findByErrorid(String errorid) {
        return fileErrorRepository.findByErrorid(errorid);
    }

    @Override
    @Modifying
    @Transactional
    public FileError createFileError(DPPFile file, String guid, String errorid)
    {
        FileError fileError = new FileError(guid, errorid, file);
        em.persist(fileError);
        return fileError;
    }

    @Override
    @Modifying
    @Transactional
    public FileError createFileError(FileError error)
    {
        try {
            em.persist(error);
        }
        catch (TransactionSystemException e)
        {
            logger.error("TransactionSystemException. Could not commit file error to the database for file_id: {}", error.getFileID(), e);
        }
        catch (Exception e)
        {
            logger.error("Could not commit file error to the database for file_id: {}", error.getFileID(), e);
        }

        return error;
    }


    @Override
    @Transactional
    public List<FileError> createFileErrorsAndClearList(List<FileError> listOfErrors)
    {
        for(FileError error : listOfErrors)
        {
            createFileError(error);
        }

        listOfErrors.clear();

        return listOfErrors;
    }
}
