package uk.gov.homeoffice.dpp.filemonitoring.messagescanning;

import java.nio.file.Path;

/**
 * Object representation of a message and it's
 * contents
 * Created by C.Barnes on 20/04/2017.
 */
public class Message {

    private Path fileToScan;
    private String forceID;
    private String priority;
    boolean valid;

    public Message()
    {

    }

    public Message(boolean isValid)
    {
        this.valid = isValid;
    }

    public Message(Path file, String frcID, String priority)
    {
        this.fileToScan = file;
        this.forceID = frcID;
        this.priority = priority;
    }


    public Path getFileToScan() {
        return fileToScan;
    }

    public void setFileToScan(Path fileToScan) {
        this.fileToScan = fileToScan;
    }

    public String getForceID() {
        return forceID;
    }

    public void setForceID(String forceID) {
        this.forceID = forceID;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }
}
