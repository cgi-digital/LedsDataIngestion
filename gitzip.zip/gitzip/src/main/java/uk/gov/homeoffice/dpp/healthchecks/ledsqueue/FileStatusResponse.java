package uk.gov.homeoffice.dpp.healthchecks.ledsqueue;

/**
 * Created by M.Koskinas on 25/07/2017.
 */
public class FileStatusResponse
{

}
