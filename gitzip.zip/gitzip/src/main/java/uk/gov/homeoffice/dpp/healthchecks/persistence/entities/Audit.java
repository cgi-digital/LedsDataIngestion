package uk.gov.homeoffice.dpp.healthchecks.persistence.entities;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by C.Barnes on 01/03/2017.
 */
@Entity
@Table(name = "ho_audit")
public class Audit {

    @Id
    @Column(name = "hoa_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="hoa_start_dt")
    private Date start;

    @Column(name="hoa_finish_dt")
    private Date finish;

    @Column(name="hoa_status")
    private String status;

    @Column(name="hoa_error_message")
    private String error_msg;

    @ManyToOne
    @JoinColumn(name="hofd_id")
    private DPPFile file;

    @ManyToOne
    @JoinColumn(name="hocd_id")
    private DPPCheck check;

    Audit(){

    }

    public Audit(Long id, Date startTime, String auditStatus, DPPFile fileToCheck, DPPCheck dppCheckExecuted)
    {
        this.id = id;
        this.start = startTime;
        this.status = auditStatus;
        this.file = fileToCheck;
        this.check = dppCheckExecuted;
    }

    public Audit(Date startTime, String auditStatus, DPPFile fileToCheck, DPPCheck dppCheckExecuted)
    {
        this.start = startTime;
        this.status = auditStatus;
        this.file = fileToCheck;
        this.check = dppCheckExecuted;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public Date getStart() {
        return start;
    }

    public void setStart(Date start) {
        this.start = start;
    }

    public Date getFinish() {
        return finish;
    }

    public void setFinish(Date finish) {
        this.finish = finish;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getError_msg() {
        return error_msg;
    }

    public void setError_msg(String error_msg) {
        this.error_msg = error_msg;
    }

    public DPPFile getFile() {
        return file;
    }

    public DPPCheck getCheck() {
        return check;
    }

    public void setFile(DPPFile dppFile) {
        this.file = dppFile;
    }

    public void setCheck(DPPCheck check) {
        this.check = check;
    }

    public String output(){
        String sp = ", ";

        return this.id + sp +  this.start + sp + this.finish + sp + this.status + sp + this.error_msg;


    }

    @Override
    public String toString() {
        return String.format(
                "Audit[id=%d, start='%s', finish='%s', status='%s', error_msg='%s']%n",
                id/*, checkid, fileid*/, start.toString(), finish.toString(), status, error_msg);



    }

    public String toCompleteString() {
        String result = String.format(
                "Audit[id=%d, start='%s', finish='%s', status='%s', error_msg='%s']%n",
                id, start.toString(), finish.toString(), status, error_msg);

        result += file.toString();

        result += check.toString();

        return result;
    }

}
