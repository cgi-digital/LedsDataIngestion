package uk.gov.homeoffice.dpp.filemonitoring.steps;

import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Object used to store the properties and status for a step
 * @author M.Koskinas
 */
@Component
public class StepSpecification
{
    private boolean status;

    private Map<String,String> properties;

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Map<String, String> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, String> properties) {
        this.properties = properties;
    }

}
