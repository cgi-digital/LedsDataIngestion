package uk.gov.homeoffice.dpp.healthchecks.steps;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;
import uk.gov.homeoffice.dpp.healthchecks.xmlparser.XMLParser;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by koskinasm on 09/02/2017.
 */


public class SchemaValidationStep implements Step {

    private static final Logger logger = LoggerFactory.getLogger(SchemaValidationStep.class);

    private Map<String,String> properties;
    private boolean enabled;

    public SchemaValidationStep(StepSpecification specification)
    {
        this.properties = specification.getProperties();
        this.enabled = specification.getStatus();
    }

    public StepResult runCheck(File file, Long fileID, FileMetadata fileMetadata, UpdategramStats stats) {

        XMLParser parser = new XMLParser();
        String fileType = parser.getFileType(file);

        Map<String,String> errors = new HashMap<>();
        boolean success = true;

        if(fileType != null)
        {
            stats.setBatchType(fileType);

            boolean validXML = parser.validateFile(file,fileType);
            if(!validXML)
            {
                errors.put("HC-0006","File "+file.getName()+" could not be validated");
                success = false;
            }
        }
        else
        {
            errors.put("HC-0007","Could not detect a valid file type for file:  "+file.getName());
            success = false;
        }

        return new StepResult(success,null, errors);

    }

    @Override
    public String getName() {
        return "schema_validation";
    }

    @Override
    public Long getID() {
        return Long.valueOf(1);
    }

    @Override
    public Map<String, String> getProperties() {
        return this.properties;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }

}
