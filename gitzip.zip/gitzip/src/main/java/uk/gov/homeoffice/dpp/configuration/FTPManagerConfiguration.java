package uk.gov.homeoffice.dpp.configuration;

import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import uk.gov.homeoffice.dpp.filemonitoring.FTPManagerPipeline;
import uk.gov.homeoffice.dpp.filemonitoring.FileDetector;
import uk.gov.homeoffice.dpp.filemonitoring.messagescanning.MessageProcessing;
import uk.gov.homeoffice.dpp.filemonitoring.messagescanning.MessageScanning;
import uk.gov.homeoffice.dpp.filemonitoring.steps.StepSpecification;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

/**
 * Created by koskinasm on 09/02/2017.
 */

@Configuration
@ConfigurationProperties(prefix = "ftpManager.configuration")
public class FTPManagerConfiguration
{
    public static String original_source;
    public static String output;
    private static String temp_storage;
    private static String temp_storage_name;
    private static String output_directory;

    public static Map<String,StepSpecification> steps;

    public String getOriginal_source() {
        return original_source;
    }

    public void setOriginal_source(String original_source) {
        this.original_source = original_source;
    }

    public String getOutput() {
        return output;
    }

    public void setOutput(String output) {
        this.output = output;
    }

    public String getTemp_storage_name() {
        return this.temp_storage_name;
    }

    public static void setTemp_storage_name(String tempStorageName) {
        temp_storage_name = tempStorageName;
    }

    public String getTemp_storage() {
        return temp_storage;
    }

    public static void setTemp_storage(String tempstorage) {
        temp_storage = tempstorage;
    }

    public static Path getTempStoragePath()
    {
        return Paths.get(temp_storage + "/" + temp_storage_name);
    }

    public static void setOutput_directory(String output_directory) {
        FTPManagerConfiguration.output_directory = output_directory;
    }

    public static String getOutput_directory() {
        return output_directory;
    }

    public Map<String,StepSpecification> getSteps() {
        return steps;
    }

    public void setSteps(Map<String,StepSpecification> steps) {
        this.steps = steps;
    }

    public static FileDetector fileDetector;

    public FileDetector getFileDetector() {
        return fileDetector;
    }

    public void setFileDetector(FileDetector fileDetector) {
        this.fileDetector = fileDetector;
    }

    @Bean("FTPManagerPipeline")
    @Scope("prototype")
    public FTPManagerPipeline createPipeline()
    {
        return new FTPManagerPipeline(original_source,output,steps);
    }

    @Bean("MessageProcessing")
    public MessageProcessing createMessageProcessing() {
        return new MessageProcessing();
    }

    @Bean("MessageScanning")
    public MessageScanning createMessageScanning() {
        return new MessageScanning();
    }

}
