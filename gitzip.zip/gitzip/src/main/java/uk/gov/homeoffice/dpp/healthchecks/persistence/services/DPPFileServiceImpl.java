package uk.gov.homeoffice.dpp.healthchecks.persistence.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPFile;
import uk.gov.homeoffice.dpp.healthchecks.persistence.repositories.DPPFileRepository;

import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;
import java.util.Date;
import java.util.List;

/**
 * Created by C.Barnes on 01/03/2017.
 */
@Service("DPPFileService")
public class DPPFileServiceImpl implements DPPFileService {

    @PersistenceContext
    public EntityManager em;

    @Autowired
    private DPPFileRepository dppFileRepository;

    @Override
    @Transactional
    public DPPFile getFileById(Long id)
    {
        return dppFileRepository.findById(id);
    }

    @Override
    @Transactional
    public DPPFile getFileByGuid(String guid)
    {
        return dppFileRepository.findByGuid(guid);
    }

    @Override
    @Transactional
    public List<DPPFile> getFileByFilename(String filename)
    {
        return dppFileRepository.findByFilename(filename);
    }

    @Override
    @Transactional
    public List<DPPFile> getFilesByForceId(String forceId)
    {
        return dppFileRepository.findByForceID(forceId);
    }

    @Override
    @Transactional
    public DPPFile getFileByChecksum(String checksum)
    {
        return dppFileRepository.findByChecksum(checksum);
    }

    @Override
    @Transactional
    public List<DPPFile> getFileByChecksumAndFilenameAndForceID(String checksum, String filename, String forceID)
    {
        return dppFileRepository.findByChecksumAndFilenameAndForceID(checksum, filename, forceID);
    }

    @Override
    @Transactional
    public List<DPPFile> getFilesByPriorityLevel(String priorityLevel) {
        return dppFileRepository.findByPriorityLevel(priorityLevel);
    }

    @Override
    @Transactional
    public List<DPPFile> getFileByStatus(String status)
    {
        return dppFileRepository.findByStatus(status);
    }

    @Override
    @Transactional
    public List<DPPFile> getAllFiles() {
        return dppFileRepository.findAll();
    }

    @Override
    @Transactional
    public List<DPPFile> getAllFilesByFilepath(String filePath)
    {
        return dppFileRepository.findByFilepath(filePath);
    }

    @Override
    @Transactional
    public List<DPPFile> getAllFilesReceivedBetween(Date from, Date to)
    {
        return dppFileRepository.findByReceivedBetween(from, to);
    }

    @Override
    @Transactional
    public List<DPPFile> getAllFilesWithAudits(){

        EntityGraph graph = this.em.getEntityGraph("graph.DPPFile.audits");

        CriteriaQuery<DPPFile> qu = em.getCriteriaBuilder().createQuery(DPPFile.class);
        qu.from(DPPFile.class);

        TypedQuery<DPPFile> tp = em.createQuery(qu);
        tp.setHint("javax.persistence.fetchgraph", graph);

        List<DPPFile> files = tp.getResultList();

        return files;
    }

    @Override
    @Modifying
    @Transactional
    public DPPFile createFile(Date fileReceived, Date vsstart, Date vsfinish, String originalFilePath, String pathToFile,String status, String filename, String guid, long filesize, String checksum, String forceID, String priorityLevel)
    {
        DPPFile file = new DPPFile(fileReceived, vsstart, vsfinish, originalFilePath, pathToFile, status, filename, guid, filesize, checksum, forceID, priorityLevel);
        em.persist(file);
        return file;
    }

    @Override
    @Modifying
    @Transactional
    public DPPFile createFile(DPPFile file, Date fileReceived, Date vsstart, Date vsfinish, String originalFilePath, String pathToFile,String status, String filename, String guid, long filesize, String checksum, String forceID, String priorityLevel)
    {
        file.setReceived(fileReceived);
        file.setVsstart(vsstart);
        file.setVsfinish(vsfinish);
        file.setOriginalFilePath(originalFilePath);
        file.setFilepath(pathToFile);
        file.setStatus(status);
        file.setFilename(filename);
        file.setGuid(guid);
        file.setFilesize(filesize);
        file.setChecksum(checksum);
        file.setForceID(forceID);
        file.setPriorityLevel(priorityLevel);

        //DPPFile file = new DPPFile(fileReceived, vsstart, vsfinish, originalFilePath, pathToFile, status, filename, guid, filesize, checksum, forceID, priorityLevel);
        em.persist(file);
        return file;
    }

    @Override
    @Modifying
    @Transactional
    public DPPFile updateFile(DPPFile dppFile)
    {
        return em.merge(dppFile);
    }

}
