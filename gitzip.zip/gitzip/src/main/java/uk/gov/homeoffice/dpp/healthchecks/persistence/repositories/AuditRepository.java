package uk.gov.homeoffice.dpp.healthchecks.persistence.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.Audit;

import java.util.Date;
import java.util.List;

/**
 * Created by C.Barnes on 01/03/2017.
 */
public interface AuditRepository extends JpaRepository<Audit, Long> {

    Audit findById(Integer id);

    List<Audit> findByFileId(Long guid);

    List<Audit> findByFinishBetween(Date from, Date until);

    List<Audit> findByStartBetween(Date from, Date until);

    List<Audit> findByFileIdAndStatus(Long guid, String status);

    Audit findByFileIdAndCheckId(Long guid, Long id);

}
