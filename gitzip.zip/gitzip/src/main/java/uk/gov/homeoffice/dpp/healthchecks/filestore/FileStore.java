package uk.gov.homeoffice.dpp.healthchecks.filestore;

import java.io.File;

/**
 * Interface for FileStore classes, offering API functionality for storing and retrieving files
 *
 * Created by M.Koskinas on 30/05/2017.
 */
public interface FileStore
{
    /**
     * Stores the provided file in the provided sub-directory in the file store
     *
     * @param sourceFile the file to be stored
     * @param subdirectory an optional subdirectory
     * @param success identifies if the file was successfully processed. If not, it will be moved to a "FAILED" sub-directory
     *
     * @return <code>String</code> the final location of the file or null if the storing procedure failed
     * */
    String storeFile(File sourceFile, String subdirectory, boolean success);

    /**
     * Retrieves the file specified by the provided filepath from the file store
     *
     * @param filepath the filepath for the file to be retrieved
     *
     * @return <code>File</code>
     * */
    File retrieveFile(String filepath);
}
