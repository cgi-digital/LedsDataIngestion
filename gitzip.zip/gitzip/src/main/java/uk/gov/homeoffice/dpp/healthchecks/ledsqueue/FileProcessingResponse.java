package uk.gov.homeoffice.dpp.healthchecks.ledsqueue;

/**
 * Created by M.Koskinas on 25/07/2017.
 */
public class FileProcessingResponse
{
    private String uniqueFileName;
    private String originalFileName;
    private String dataLoadResult;
    private String errorDescription;
    private String errorCode;

    public FileProcessingResponse()
    {
        
    }

    public String getUniqueFileName() {
        return uniqueFileName;
    }

    public void setUniqueFileName(String uniqueFileName) {
        this.uniqueFileName = uniqueFileName;
    }

    public String getOriginalFileName() {
        return originalFileName;
    }

    public void setOriginalFileName(String originalFileName) {
        this.originalFileName = originalFileName;
    }

    public String getDataLoadResult() {
        return dataLoadResult;
    }

    public void setDataLoadResult(String dataLoadResult) {
        this.dataLoadResult = dataLoadResult;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
}
