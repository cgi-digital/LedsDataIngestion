package uk.gov.homeoffice.dpp.configuration.forces;

import uk.gov.homeoffice.dpp.configuration.forces.ForceLandingLocation;

import java.util.Map;

/**
 * Created by C.Barnes on 03/07/2017.
 */
public class ForceProperties {

    private String forceID;

    private String updategramResponse;

    private Map<String, ForceLandingLocation> ingest;

    public String getForceID() {
        return forceID;
    }

    public void setForceID(String forceID) {
        this.forceID = forceID;
    }

    public String getUpdategramResponse() {
        return updategramResponse;
    }

    public void setUpdategramResponse(String updategramResponse) {
        this.updategramResponse = updategramResponse;
    }

    public Map<String, ForceLandingLocation> getIngest() {
        return ingest;
    }

    public void setIngest(Map<String, ForceLandingLocation> ingest) {
        this.ingest = ingest;
    }
}
