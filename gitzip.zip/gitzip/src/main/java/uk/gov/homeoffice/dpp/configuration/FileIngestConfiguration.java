package uk.gov.homeoffice.dpp.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import uk.gov.homeoffice.dpp.configuration.forces.ForcesConfiguration;
import uk.gov.homeoffice.dpp.configuration.forces.ForceLandingLocation;
import uk.gov.homeoffice.dpp.configuration.priorities.PriorityProperties;
import uk.gov.homeoffice.dpp.fileingest.DirPoller;
import uk.gov.homeoffice.dpp.fileingest.DirProcessor;


/**
 * Created by C.Barnes on 12/07/2017.
 */
@Configuration
@ConfigurationProperties(prefix = "fileIngest.configuration")
public class FileIngestConfiguration {

    @Autowired
    ForcesConfiguration forcesConfiguration;

    private static int minFileAge;
    private static int sleepTime;
    private static boolean keepPolling = true;

    public static int getMinFileAge() {
        return minFileAge;
    }

    public static void setMinFileAge(int minFileAge) {
        FileIngestConfiguration.minFileAge = minFileAge;
    }

    public static int getSleepTime() {
        return sleepTime;
    }

    public static void setSleepTime(int sleepTime) {
        FileIngestConfiguration.sleepTime = sleepTime;
    }

    public static boolean isKeepPolling() {
        return keepPolling;
    }

    public static void setKeepPolling(boolean keepPolling) {
        FileIngestConfiguration.keepPolling = keepPolling;
    }

    @Bean("DirPoller")
    public DirPoller createDirPoller()
    {
        return new DirPoller(forcesConfiguration.getForceList(), minFileAge);
    }

    @Bean("DirProcessor")
    @Scope("prototype")
    public DirProcessor createDirProcessor(ForceLandingLocation forceDir, PriorityProperties priorityProperties, String forceID)
    {
        return new DirProcessor(forceDir, priorityProperties, forceID);
    }

}
