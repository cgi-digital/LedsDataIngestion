package uk.gov.homeoffice.dpp.filemonitoring.steps;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.DotFinishedHandler;
import uk.gov.homeoffice.dpp.filemonitoring.utilities.GUIDHandler;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * This step completes the metadata object
 * ({@link FileMetadata#originalFileName}, {@link FileMetadata#originalFileSize})
 * and in cases where the file has originated from a .tar it assigns a {@link FileMetadata#guid}. It
 * ensures file is renamed to guid and then generates the .properties file to sit alongside its counterpart
 * @author C.Barnes, M.Koskinas
 */
public class MetadataCreationStep implements Step {

    private static final Logger logger = LoggerFactory.getLogger(MetadataCreationStep.class);
    private boolean enabled;
    private String errorCode = null;

    /**
     * Constructor for MetadataCreationStep assigns the properties
     * attributed to this step in the yml properties file
     * @param stepSpecification information about the step from the properties file
     */
    public  MetadataCreationStep(StepSpecification stepSpecification)
    {
        this.enabled = stepSpecification.getStatus();
    }

    /**
     * Executes the step on the given file
     * @param fileMetadata The metadata object containing the file to be used in {@link FileMetadata#currentPath}
     * @return A {@link StepResult} object detailing whether it was successful, if there is an error code
     * and the current working metadata object
     */
    @Override
    public StepResult runStep(FileMetadata fileMetadata) {

        logger.info("Getting metadata for {}", fileMetadata.getCurrentPath());

        Path newFilepath = fileMetadata.getCurrentPath();
//        File file = newFilepath.toFile();
//
//        String origFilename = Paths.get(fileMetadata.getOriginalFilePath()).getFileName().toString();

        //TODO DELETE THIS ONCE VIRUS SCANNING IS PERMANENTLY IN PLACE
        if(!FTPManagerConfiguration.steps.get("virus_scanning").getStatus())
        {
            fileMetadata.setVSstart(new Date());
            fileMetadata.setVSfinish(new Date());
        }
//
//        if(origFilename.contains(".tar"))
//        {
//            fileMetadata.setGuid(GUIDHandler.guidGenerator());
//
//            fileMetadata.setOriginalFileName(DotFinishedHandler.removeDotFinished(file.getName()));
//        }
//        else{
//
//            fileMetadata.setOriginalFileName(DotFinishedHandler.removeDotFinished(origFilename));
//        }
//
//        fileMetadata.setOriginalFileSize(file.length());

        try{
            newFilepath = GUIDHandler.renameFileToGuid(fileMetadata.getCurrentPath(), fileMetadata.getGuid());
            fileMetadata.setCurrentPath(newFilepath);
        }
        catch (IOException ioException)
        {
            logger.error("Error when trying to rename file {} to the guid {}", newFilepath, fileMetadata.getGuid(), ioException);
            errorCode = "6";
        }

        //SET SUCCESFUL metadata
        fileMetadata.setState(FileMetadata.STATE_SUCCESFUL);
        fileMetadata.setErrorMessage(FileMetadata.SUCCESFUL_MESSAGE);

        fileMetadata.setFinalLocation(fileMetadata.getCurrentPath().toString());

        return new StepResult(true, errorCode, fileMetadata);
    }

    /**
     * Creates and populates the properties file based on the
     * contents of the Metadata object. The properties file is created in the same
     * directory as the file the properties file relates to ({@link FileMetadata#currentPath}).
     * @param metadata the object used to create the properties file
     * @return true if the properties file is successfully created, false otherwise
     */
    private boolean createMetadataFile(FileMetadata metadata)
    {
        List<String> lines = metadata.generatePropertyFileContent();

        String fileName = DotFinishedHandler.removeDotFinished(metadata.getCurrentPath().getFileName().toString());

        Path propertiesFile;

        if(metadata.getCurrentPath().getParent() == null) {
            propertiesFile = Paths.get("" + fileName + ".properties");
        }
        else{
            propertiesFile = Paths.get(metadata.getCurrentPath().getParent() + "/" + fileName + ".properties");
        }

        try {
            Files.write(propertiesFile, lines, Charset.forName("UTF-8"));
        } catch (IOException ioException) {
            logger.error("Error when creating properties file for file {}", metadata.getCurrentPath().toString(), ioException);
            errorCode = "1";
            return false;
        }
        return true;
    }

    @Override
    public String getName() {
        return "metadata_creation";
    }

    @Override
    public Map<String, String> properties() {
        return null;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }
}
