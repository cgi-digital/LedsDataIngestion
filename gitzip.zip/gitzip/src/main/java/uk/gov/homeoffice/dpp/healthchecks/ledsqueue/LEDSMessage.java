package uk.gov.homeoffice.dpp.healthchecks.ledsqueue;

import net.minidev.json.JSONObject;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPFile;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.UpdategramStats;

/**
 * Created by C.Barnes on 17/05/2017.
 */
public class LEDSMessage {

    DPPFile file = null;
    UpdategramStats stats = null;

    public LEDSMessage(DPPFile fileToBSent)
    {
        this.file = fileToBSent;
    }

    public LEDSMessage(DPPFile fileToBSent, UpdategramStats statsForFile)
    {
        this.file = fileToBSent;
        this.stats = statsForFile;
    }

    public String extractInfoIntoJSON()
    {
        JSONObject jsonMessage = new JSONObject();

        jsonMessage.put("GUID", file.getGuid());
        jsonMessage.put("OrigFileName", file.getFilename());
        jsonMessage.put("ForceAgency", file.getForceID());
        jsonMessage.put("ReceivedDateTime", file.getReceived());
        jsonMessage.put("Priority", file.getPriorityLevel());

        if(stats == null) {

            jsonMessage.put("FileType", "");
            jsonMessage.put("ForceSystem", "");
            jsonMessage.put("MessageCount", "");
            jsonMessage.put("TransactionList", "");
            jsonMessage.put("Recipient", "");
        }
        else{
            jsonMessage.put("FileType", stats.getBatchType());
            jsonMessage.put("ForceSystem", ""); //TODO Need to gather the forceSystem at some point
            jsonMessage.put("MessageCount", stats.getMessages());
            jsonMessage.put("TransactionList", stats.getTransactionList());
            jsonMessage.put("Recipient", stats.getRecipient());

        }

        return jsonMessage.toString();
    }

}
