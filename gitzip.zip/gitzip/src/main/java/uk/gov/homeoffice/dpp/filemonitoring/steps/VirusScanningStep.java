package uk.gov.homeoffice.dpp.filemonitoring.steps;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.configuration.FTPManagerConfiguration;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.filemonitoring.virusscanning.VirusScan;
import uk.gov.homeoffice.dpp.filemonitoring.virusscanning.VirusScanFactory;
import uk.gov.homeoffice.dpp.filemonitoring.virusscanning.VirusScan.VirusScanResultType;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/**
 * This step is to Virus Scan a file and then quarantine it
 * if it fails
 * @author C.Barnes, M.Koskinas
 */
public class VirusScanningStep implements Step {

    private static final Logger logger = LoggerFactory.getLogger(VirusScanningStep.class);
    boolean enabled;
    private Path quarantine_location;
    private Path reports_location;
    private boolean generateXMLReport;
    private boolean generateTextReport;
    private VirusScan scanner;
    private String errorCode = null;


    /**
     * Constructor for VirusScanningStep assigns the properties
     * attributed to this step in the yml properties file
     * @param stepSpecification information about the step from the properties file
     */
    public VirusScanningStep(StepSpecification stepSpecification)
    {
        this.enabled = stepSpecification.getStatus();
        this.quarantine_location = Paths.get(stepSpecification.getProperties().get("quarantine_location"));
        this.reports_location = Paths.get(stepSpecification.getProperties().get("report_location"));
        this.generateXMLReport = Boolean.parseBoolean(stepSpecification.getProperties().get("generate_xmlreport"));
        this.generateTextReport = Boolean.parseBoolean(stepSpecification.getProperties().get("generate_textreport"));

        String chosenOS = stepSpecification.getProperties().get("Windows/Unix");
        VirusScanFactory vsFact = new VirusScanFactory(chosenOS);
        this.scanner = vsFact.getVirusScanner(stepSpecification);

        if(this.scanner == null)
            logger.error("Windows/Unix option for virus scanning incorrect in properties file. (Only accept Unix or Windows - Found {})", chosenOS);
    }

    /**
     * Executes the step on the {@link FileMetadata#currentPath} attribute
     * of the metadata object passed in
     * @param fileMetadata Metadata object referring to the file to be virus scanned
     * @return A {@link StepResult} object detailing whether it was successful, if there is an error code
     * and the current working metadata object
     */
    @Override
    public StepResult runStep(FileMetadata fileMetadata)
    {
        logger.info("Virus Scanning {} file", fileMetadata.getCurrentPath().toString());
        fileMetadata.setVSstart(new Date());

        if(this.scanner == null)
        {
            logger.error("Could not virus scan {}, incorrect OS settings for Virus Scanning option in properties file", fileMetadata.getCurrentPath().toString());
            return new StepResult(false, "xx", fileMetadata);
        }

        this.scanner.runVirusScan(fileMetadata.getCurrentPath());

        fileMetadata.setVSfinish(new Date());

        boolean vscanResult = processVSResult(fileMetadata);

        if(!vscanResult)
        {
            return new StepResult(false, "1", fileMetadata);
        }

        return new StepResult(true, null, fileMetadata);
    }

    /**
     * Once a file has been scanned it should be passed into
     * this method to process the results and act appropriately
     * @param fileMetadata the {@link FileMetadata} object for the file that was just scanned
     * @return true if the file passed virus scanning, false otherwise
     */
    private boolean processVSResult(FileMetadata fileMetadata) {

        //TODO look through lines to see if any file > 0 returned as possibly infected/not scanned/ passed
        Map<VirusScanResultType, Integer> result = this.scanner.returnResultSummary();

        if(result.get(VirusScanResultType.POSSIBLY_INFECTED) > 0)
        {
            logger.info("VIRUS FOUND");
            virusFound(fileMetadata);

            return false;
        }

        if(result.get(VirusScanResultType.NOT_SCANNED) > 0)
        {
            logger.info("FILE NOT SCANNED");
            if(moveFileToQuarantine(fileMetadata))
            {
                virusFound(fileMetadata);
            }
            return false;
        }

        if(result.get(VirusScanResultType.CLEAN) > 0)
        {
            logger.info("FILE IS CLEAN");
            //cleanReport(file);

            return true;
        }

        return false;


    }

    /**
     * processes to take on a file if that
     * file is found to be infected with a virus
     * @param fileMetadata {@link FileMetadata} object of the infected file
     * @return true if all processes are successful, false otherwise
     */
    private boolean virusFound(FileMetadata fileMetadata) {

        boolean success;

        //success = renameReport(file.getCurrentPath().getFileName().toString(),  file.getOriginalFilePath());

        success = deleteVirus(fileMetadata.getOriginalFilePath());

        //SET FAILED metadata
        fileMetadata.setState(FileMetadata.STATE_VIRUS);
        fileMetadata.setErrorMessage(FileMetadata.VIRUS_MESSAGE);

        return success;
    }

    /**
     * Writes a standalone properties file for the virus infected
     * file so that the information that it failed virus scanned can be passed
     * onwards
     * @param fileMetadata the metadata object of the files that was scanned
     * @return true if the property file is successfully written, false otherwise
     */
    private boolean writePropertyFile(FileMetadata fileMetadata) {

        Path propLocation = Paths.get(FTPManagerConfiguration.getOutput_directory());
        propLocation = Paths.get(propLocation.toString() + "/" + fileMetadata.getCurrentPath().getFileName().toString() + ".properties");

        List<String> propFileContent = fileMetadata.generatePropertyFileContent();

        try {

            Files.write(propLocation, propFileContent, Charset.forName("UTF-8"));
        }
        catch (Exception e)
        {
            logger.error("Failed to write the virus' ({}) properties file to the output directory {}", fileMetadata.getOriginalFilePath(),
                    propLocation, e);
            return false;
        }

        return true;

    }

    /**
     * Deletes the original file (as the temporary copy
     * of the file is the one that's scanned)
     * @param originalFilePath The original file path of the virus (and therefore the one to be deleted)
     * @return true if the virus infected file was successfuly deleted, false otherwise
     */
    private boolean deleteVirus(String originalFilePath) {

        Path fileTDelete = Paths.get(originalFilePath);

        try {
            Files.delete(fileTDelete);
            logger.info("Virus {} moved to quarantine named as guid", originalFilePath);
        }
        catch (Exception e)
        {
            logger.error("Could not delete file {} that contained a virus", originalFilePath, e);
            return false;
        }

        return true;
    }

    /**
     * Renames a virus report to the original name of the file
     * instead of the GUID
     * @param guidFilename the current file name
     * @param originalFilePath the file path of the original virus scanned file
     * @return true if successfully changed, false otherwise
     */
    private boolean renameReport(String guidFilename, String originalFilePath) {

        if(!generateXMLReport && !generateTextReport)
            return true;

        String filename = Paths.get(originalFilePath).getFileName().toString();
        // Map<SOURCEPATH, NEWPATH>
        Map<Path, Path> nameChanges = new HashMap<>();

        if(generateXMLReport) {
            Path fileReportPath = Paths.get(reports_location + "/" + guidFilename + ".xml");
            Path newFileReportName = Paths.get(reports_location + "/" + filename + ".xml");
            nameChanges.put(fileReportPath, newFileReportName);
        }

        if(generateTextReport) {
            Path fileReportPath = Paths.get(reports_location + "/" + guidFilename + ".report");
            Path newFileReportName = Paths.get(reports_location + "/" + filename + ".report");
            nameChanges.put(fileReportPath, newFileReportName);
        }

        Path fileReportPath = null;
        Path newFileReportName = null;

        for (Map.Entry<Path, Path> nameChange: nameChanges.entrySet()) {
            try {
                fileReportPath = nameChange.getKey();
                newFileReportName = nameChange.getValue();

                if (fileReportPath.toFile().exists()) {
                    Files.move(fileReportPath, newFileReportName);
                } else {
                    logger.error("No report found for the Virus Scan for file {}", originalFilePath);
                }
            }
            catch (Exception e)
            {
                logger.error("Error when renaming report file from {} to {}", fileReportPath, newFileReportName, e);
                return false;
            }
        }


        return true;
    }

    /**
     * Removes reports that have been generated when scanning
     * the {@link FileMetadata} file
     * @param fileMetadata The {@link FileMetadata} object referring to the file that was just scanned
     * @return true if the reports are successfully deleted, false otherwise
     */
    private boolean cleanReport(FileMetadata fileMetadata) {

        if(!generateXMLReport && !generateTextReport)
            return true;

        Path fileReportPath = null;

        try{
            if(generateXMLReport) {
                fileReportPath = Paths.get(reports_location + "/" + fileMetadata.getGuid().toString() + ".xml");

                if (fileReportPath.toFile().exists()) {
                    Files.delete(fileReportPath);
                }
            }

            if(generateTextReport)
            {
                fileReportPath = Paths.get(reports_location + "/" + fileMetadata.getGuid().toString() + ".report");

                if (fileReportPath.toFile().exists()) {
                    Files.delete(fileReportPath);
                }
            }
        }
        catch (Exception e)
        {
            logger.error("Error when deleting report file {}", fileReportPath, e);
            return false;
        }



        return true;
    }

    /**
     * Moves file to the quarantine location specified in the properties file
     * @param fileMetadata metadata object relating to the file to be moved
     * @return true if file is successfully moved to quarantine, false otherwise
     */
    private boolean moveFileToQuarantine(FileMetadata fileMetadata) {

        Path quarantinePath = Paths.get(quarantine_location + "/" + fileMetadata.getCurrentPath().getFileName());

        boolean success = true;
        try {
            Files.move(fileMetadata.getCurrentPath(), quarantinePath);
        }
        catch (IOException e) {
            logger.error("Error when moving file {} to quarantine {}", fileMetadata.getCurrentPath().toString(), quarantine_location, e);
            success = false;
        }
        return success;
    }

    /**
     * Generates report on the virus scan when a file fails scanning
     * @param vs_report
     * @param filename
     * @return
     */
    private boolean generateQuarantineReport(String vs_report, String filename)
    {
        boolean success = true;
        List<String> lines = Arrays.asList("filename: " + filename, "virus scanner report: " + vs_report);
        Path metadataFile = Paths.get(quarantine_location+"/"+filename+".quarantine_report");
        try {
            Files.write(metadataFile, lines, Charset.forName("UTF-8"));
        } catch (IOException ioException) {
            logger.error("Error when creating quarantine report file for file {}", filename, ioException);
            errorCode = "1";
            success = false;
        }
        return success;
    }

    @Override
    public String getName() {
        return "virus_scanning";
    }

    @Override
    public Map<String, String> properties() {
        return null;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }
}
