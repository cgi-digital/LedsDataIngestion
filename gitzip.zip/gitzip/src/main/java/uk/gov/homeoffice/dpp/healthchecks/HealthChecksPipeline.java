package uk.gov.homeoffice.dpp.healthchecks;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.healthchecks.errorhandler.ErrorHandler;
import uk.gov.homeoffice.dpp.healthchecks.filestore.FileStore;
import uk.gov.homeoffice.dpp.healthchecks.functions.FileStatsUtilities;
import uk.gov.homeoffice.dpp.healthchecks.functions.UnzippingUtilities;
import uk.gov.homeoffice.dpp.healthchecks.ledsqueue.LEDSQueue;
import uk.gov.homeoffice.dpp.healthchecks.metadata.ValidationMetadata;
import uk.gov.homeoffice.dpp.healthchecks.metadata.models.LedsFtpsServer;
import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.*;
import uk.gov.homeoffice.dpp.healthchecks.persistence.services.*;
import uk.gov.homeoffice.dpp.healthchecks.steps.Step;
import uk.gov.homeoffice.dpp.healthchecks.steps.StepFactory;
import uk.gov.homeoffice.dpp.healthchecks.steps.StepResult;
import uk.gov.homeoffice.dpp.healthchecks.steps.StepSpecification;
import uk.gov.homeoffice.dpp.healthchecks.xmlparser.XMLParser;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by koskinasm on 09/02/2017.
 */
public class HealthChecksPipeline {

    private static final Logger logger = LoggerFactory.getLogger(HealthChecksPipeline.class);

    private List<Step> steps;

    private final String TIME_FORMAT = "EEE MMM dd HH:mm:ss zzz yyyy";

    @Autowired
    DPPFileService fileService;

    @Autowired
    AuditService auditService;

    @Autowired
    CheckService checkService;

    @Autowired
    FileErrorService fileErrorService;

    @Autowired
    UpdategramStatsService updategramStatsService;

    @Autowired
    LEDSQueue ledsQueue;

    @Autowired
    ErrorHandler errorHandler;

    @Autowired
    @Qualifier("FileStore")
    FileStore fileStore;

    public HealthChecksPipeline(Map<String,StepSpecification> checkOrder)
    {
        initializePipeline(checkOrder);
    }

    /**
     * Executes the list of configured Checks against the file specified in the provided properties file
     *
     * @param fileMetadata metadata object for the file to be tested
     * */
    public void runHealthChecks(FileMetadata fileMetadata)
    {
        boolean metadataPopulated = FileMetadata.areMetadataPopulated(fileMetadata);

        UpdategramStats stats = new UpdategramStats();

        if(metadataPopulated)
        {
            final String serverName = fileMetadata.getReceivedMachineName();
            List<LedsFtpsServer> servers = ValidationMetadata.getValidLedsFtpsServers().stream()
                    .filter(server -> server.getServername().equals(serverName))
                    .collect(Collectors.toList());

            DPPFile dppFile = new DPPFile();
            List<FileError> fileErrors = new ArrayList<>();

            Date landedTime = fileMetadata.getLandingDate();
            Date VSStartDate = fileMetadata.getVSstart();
            Date VSEndDate = fileMetadata.getVSfinish();

            boolean virusScanned = VSStartDate != null && VSEndDate != null;

            if(virusScanned)
            {
                if("VIRUS".equals(fileMetadata.getState()))
                {
                    dppFile = fileService.createFile(
                            landedTime,
                            VSStartDate,
                            VSEndDate,
                            fileMetadata.getOriginalFilePath(),
                            null,
                            "FAILED",
                            fileMetadata.getOriginalFileName(),
                            fileMetadata.getGuid().toString(),
                            Integer.valueOf(String.valueOf(fileMetadata.getOriginalFileSize())),
                            null,
                            fileMetadata.getForceID(),
                            fileMetadata.getPriorityLevel());

                    dppFile.setLastStatusUpdate(new Date());
                    fileService.updateFile(dppFile);

                    fileErrorService.createFileError(dppFile, fileMetadata.getGuid().toString(),"HC-0005");

                    ledsQueue.send(dppFile);
                }
                else if(servers.isEmpty())
                {
                    dppFile = fileService.createFile(
                            landedTime,
                            VSStartDate,
                            VSEndDate,
                            fileMetadata.getOriginalFilePath(),
                            null,
                            "FAILED",
                            fileMetadata.getOriginalFileName(),
                            fileMetadata.getGuid().toString(),
                            Integer.valueOf(String.valueOf(fileMetadata.getOriginalFileSize())),
                            null,
                            fileMetadata.getForceID(),
                            fileMetadata.getPriorityLevel());

                    dppFile.setLastStatusUpdate(new Date());
                    fileService.updateFile(dppFile);

                    fileErrorService.createFileError(dppFile, fileMetadata.getGuid().toString(),"HC-0008");

                    ledsQueue.send(dppFile);
                }
                else
                {

                    String referencedFilepath = fileMetadata.getFinalLocation();

                    boolean uncompressed = false;
                    List<String> filepaths = new ArrayList<>();

                    //Detect zip files and unzip nested files
                    try {
                        if(UnzippingUtilities.isZipped(referencedFilepath))
                        {
                            filepaths.addAll(UnzippingUtilities.unzip(new File(referencedFilepath), fileMetadata));
                            uncompressed = true;
                        }
                        else
                        {
                            filepaths.add(referencedFilepath);
                            uncompressed = true;
                        }
                    }
                    catch (IOException e)
                    {
                        logger.error("Failed to de-compress file {}", referencedFilepath,e);
                        uncompressed = false;
                    }

                    if(uncompressed && filepaths.size() == 1)
                    {
                        String channelName = servers.get(0).getChannelname();
                        stats.setSecurityChannel(channelName);

                        Map<String,String> gpmsLists = ValidationMetadata.getGPMSList();
                        if("PSNP-P".equals(channelName))
                        {
                            stats.setGpmsList("2");
                            stats.setProtectiveMarking(gpmsLists.get("2"));
                        }
                        else if("PSNP-S".equals(channelName))
                        {
                            stats.setGpmsList("3");
                            stats.setProtectiveMarking(gpmsLists.get("3"));
                        }

                        String filepath = filepaths.get(0);

                        String s[] = filepath.split("\\"+File.separator);
                        String physicalFileName = s[s.length-1];

                        boolean parsedForStats = true;

                        File file = new File(filepath);

                        String fileChecksum = null;

                        try
                        {
                            fileChecksum = FileStatsUtilities.getFileChecksum(file);
                        }
                        catch (IOException e)
                        {
                            parsedForStats = false;
                            logger.error("Error getting information for file: {}", file.getName(),e);
                            dppFile = fileService.createFile(
                                    landedTime,
                                    VSStartDate,
                                    VSEndDate,
                                    fileMetadata.getOriginalFilePath(),
                                    null,
                                    "FAILED",
                                    fileMetadata.getOriginalFileName(),
                                    fileMetadata.getGuid().toString(),
                                    Integer.valueOf(String.valueOf(fileMetadata.getOriginalFileSize())),
                                    null,
                                    fileMetadata.getForceID(),
                                    fileMetadata.getPriorityLevel());

                            dppFile.setLastStatusUpdate(new Date());
                            fileService.updateFile(dppFile);

                            fileErrorService.createFileError(dppFile, fileMetadata.getGuid().toString(),"HC-0002");
                        }

                        boolean isXML = XMLParser.isXMLFile(file);
                        //only generate non-XML error if the file has already been parsed for stats, in order to avoid re-creating
                        //the same DPPFile
                        if(parsedForStats && !isXML)
                        {
                            logger.error("File {} is not an XML file" , file.getName());
                            dppFile = fileService.createFile(
                                    landedTime,
                                    VSStartDate,
                                    VSEndDate,
                                    fileMetadata.getOriginalFilePath(),
                                    null,
                                    "FAILED",
                                    fileMetadata.getOriginalFileName(),
                                    fileMetadata.getGuid().toString(),
                                    Integer.valueOf(String.valueOf(fileMetadata.getOriginalFileSize())),
                                    null,
                                    fileMetadata.getForceID(),
                                    fileMetadata.getPriorityLevel());

                            dppFile.setLastStatusUpdate(new Date());
                            fileService.updateFile(dppFile);

                            fileErrorService.createFileError(dppFile, fileMetadata.getGuid().toString(),"HC-0003");
                        }

                        if(parsedForStats && isXML)
                        {
                            //Checking for duplicates in the database
                            if(fileService.getFileByChecksumAndFilenameAndForceID(fileChecksum, fileMetadata.getOriginalFileName(), fileMetadata.getForceID()).isEmpty())
                            {
                                dppFile = fileService.createFile(
                                        dppFile,
                                        landedTime,
                                        VSStartDate,
                                        VSEndDate,
                                        fileMetadata.getOriginalFilePath(),
                                        filepath,
                                        "RECEIVED",
                                        fileMetadata.getOriginalFileName(),
                                        fileMetadata.getGuid().toString(),
                                        Integer.valueOf(String.valueOf(fileMetadata.getOriginalFileSize())),
                                        fileChecksum,
                                        fileMetadata.getForceID(),
                                        fileMetadata.getPriorityLevel());

                                //TODO send message via LEDSQueue

                                errorHandler.createFileErrorsAndClearList(fileErrors);
                                logger.info("File {} successfully registered in the database", filepath);

                                boolean success = true;
                                for(int c = 0; c < steps.size() && success ; c++)
                                {
                                    Step step = steps.get(c);

                                    DPPCheck dbCheck = checkService.getCheckByID(step.getID());

                                    if(step.isEnabled())
                                    {
                                        Date startTime = new Date();
                                        Audit audit = new Audit(startTime, "IN_PROGRESS", dppFile, dbCheck);
                                        dppFile.addAudit(audit);

                                        if(!"HEALTH CHECKED".equals(dppFile.getStatus()))
                                        {
                                            dppFile.setStatus("HEALTH CHECKED");
                                            dppFile.setLastStatusUpdate(startTime);
                                        }

                                        logger.info("{} step started", step.getName());

                                        StepResult result = step.runCheck(file, dppFile.getId(),fileMetadata,stats);
                                        Date finishedTime = new Date();

                                        logger.info("{} step finished", step.getName());

                                        if(!result.isSuccess())
                                        {
                                            for(HashMap.Entry entry : result.getErrors().entrySet())
                                            {
                                                dppFile.addFileError(new FileError(dppFile.getGuid(),entry.getKey().toString(), dppFile));
                                            }
                                            success = false;
                                        }

                                        audit.setFinish(finishedTime);
                                        audit.setStatus(result.isSuccess() ? "SUCCESS" : "FAILED");
                                        audit.setError_msg(result.isSuccess() ? "" : "Failure");
                                        //auditService.updateAudit(audit);
                                    }
                                }

                                String finalLocation = fileStore.storeFile(file,fileMetadata.getForceID(),success);

                                if(success)
                                {
                                    dppFile.setStatus("PROCESSED");
                                    dppFile.setLastStatusUpdate(new Date());
                                    dppFile.setFilepath(finalLocation);
                                    dppFile = fileService.updateFile(dppFile);
                                    logger.info("File {} successfully processed",physicalFileName);
                                }
                                else
                                {
                                    dppFile.setStatus("FAILED");
                                    dppFile.setLastStatusUpdate(new Date());
                                    dppFile.setFilepath(finalLocation);
                                    dppFile = fileService.updateFile(dppFile);
                                }

                                updategramStatsService.createStats(stats,dppFile.getId());

                                ledsQueue.send(dppFile, stats);
                            }
                            else
                            {
                                logger.error("Duplicate file: {}, the file has already been received and processed", file.getName());

                                dppFile = fileService.createFile(
                                        dppFile,
                                        landedTime,
                                        VSStartDate,
                                        VSEndDate,
                                        fileMetadata.getOriginalFilePath(),
                                        null,
                                        "DUPLICATE",
                                        fileMetadata.getOriginalFileName(),
                                        fileMetadata.getGuid().toString(),
                                        Integer.valueOf(String.valueOf(fileMetadata.getOriginalFileSize())),
                                        fileChecksum,
                                        fileMetadata.getForceID(),
                                        fileMetadata.getPriorityLevel());

                                dppFile.setLastStatusUpdate(new Date());
                                fileService.updateFile(dppFile);

                                ledsQueue.send(dppFile);
                            }
                        }
                        else
                        {
                            //Failed to get the checksum for file
                            String finalLocation = fileStore.storeFile(file,fileMetadata.getForceID(),false);

                            dppFile.setFilepath(finalLocation);
                            dppFile.setLastStatusUpdate(new Date());
                            fileService.updateFile(dppFile);

                            ledsQueue.send(dppFile);
                        }
                    }
                    else
                    {
                        dppFile = fileService.createFile(
                                landedTime,
                                VSStartDate,
                                VSEndDate,
                                fileMetadata.getOriginalFilePath(),
                                null,
                                "FAILED",
                                fileMetadata.getOriginalFileName(),
                                fileMetadata.getGuid().toString(),
                                Integer.valueOf(String.valueOf(fileMetadata.getOriginalFileSize())),
                                null,
                                fileMetadata.getForceID(),
                                fileMetadata.getPriorityLevel());

                        dppFile.setLastStatusUpdate(new Date());
                        fileService.updateFile(dppFile);

                        logger.error("Error while attempting to locate/uncompress file {}", referencedFilepath);
                        fileErrorService.createFileError(dppFile, fileMetadata.getGuid().toString(),"HC-0001");

                        ledsQueue.send(dppFile);
                    }
                }
            }//TODO not virus scanned
        }
        //TODO invalid metadata
    }

    /**
     * Initializes the pipeline according to the provided CheckSpecifications by instantiating the respective tests
     *
     * @param checkOrder the Checks to be included in the pipeline
     * */
    private void initializePipeline( Map<String,StepSpecification> checkOrder)
    {
        steps = new ArrayList<>();
        for(String checkName : checkOrder.keySet())
        {
            if(checkOrder.get(checkName).getStatus())
            {
                steps.add(StepFactory.createCheck(checkName,checkOrder.get(checkName)));
            }
        }
    }

    public List<Step> getSteps()
    {
        return this.steps;
    }
}
