package uk.gov.homeoffice.dpp.filemonitoring.steps;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.DotFinishedHandler;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

/**
 * This step moves the file being worked on into the output directory
 * @author C.Barnes, M.Koskinas
 *
 */
public class FileForwardingStep implements Step {

    private static final Logger logger = LoggerFactory.getLogger(FileForwardingStep.class);

    private String fileDestination;
    private boolean enabled;
    private String errorCode = null;
    private FileMetadata currentMetadataFile;

    /**
     * Constructor for FileForwardingStep assigns the properties
     * attributed to this step in the yml properties file
     * @param stepSpecification information about the step from the properties file
     */
    public  FileForwardingStep(StepSpecification stepSpecification)
    {
        this.enabled = stepSpecification.getStatus();
        fileDestination = stepSpecification.getProperties().get("destination_dir");
    }

    /**
     * This method is called when the step is to be executed.
     * It takes in the Metadata object and uses it's {@link FileMetadata#currentPath} value
     * to move it to the output directory specified in the properties file
     * under FileForwarding Properties
     * @param fileMetadata This is the metadata object relating to the file that will be moved
     * @return A {@link StepResult} object detailing whether it was successful, if there is an error code
     * and the current working metadata object
     */
    @Override
    public StepResult runStep(FileMetadata fileMetadata) {
        currentMetadataFile = fileMetadata;
        Path path = fileMetadata.getCurrentPath();

        logger.info("Moving file {} to destination {}, in priority folder {} for collection"
        , path.toString(), fileDestination, fileMetadata.getPriorityLevel());



        if(!createPriorityFolder(fileMetadata.getPriorityLevel()))
        {
            return new StepResult(false, errorCode, currentMetadataFile);
        }


        if(!moveFiles(path, fileMetadata.getPriorityLevel())) {
            return new StepResult(false, errorCode, currentMetadataFile);
        }

        fileMetadata.setFinalLocation(fileMetadata.getCurrentPath().toString());

        return new StepResult(true, errorCode, currentMetadataFile);
    }

    private boolean createPriorityFolder(String priorityLevel) {

        File priorityFolder = new File(fileDestination + "/" + priorityLevel);

        if(priorityFolder.exists())
        {
            return true;
        }

        logger.info("Priority directory does not exist. Creating priority directory {}", priorityFolder.getPath());

        try {
            Files.createDirectory(priorityFolder.toPath());
        } catch (IOException e) {
            logger.error("Could not make priority directory {}", priorityFolder.getPath(), e);
            return false;
        }

        return true;
    }

    @Override
    public String getName() {
        return "file_forwarding";
    }

    @Override
    public Map<String, String> properties() {
        return null;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }

    /**
     * Moves the file (and it's properties file) from the path given
     * to the output directory specified in the properties file
     * @param fileTBMoved Path to the file that is to be moved
     * @return true if successful in moving file, false otherwise
     */
    private boolean moveFiles(Path fileTBMoved, String priorityLevel)
    {

        String fileLocation = fileDestination + "/" + priorityLevel + "/" + DotFinishedHandler.removeDotFinished(fileTBMoved.getFileName().toString());
        Path destination = Paths.get(fileLocation);
        Path destPropFile = Paths.get(DotFinishedHandler.removeDotFinished(fileLocation) + ".properties");

        try {
            Path propFile = Paths.get(DotFinishedHandler.removeDotFinished(fileTBMoved.toString()) + ".properties");
            Files.move(propFile, destPropFile);
            Files.move(fileTBMoved, destination);

            currentMetadataFile.setCurrentPath(destination);

        }
        catch (IOException ioe)
        {
            logger.error("File {} could not be moved to destination {}", fileTBMoved.toString(), destination.toString(), ioe);
            errorCode = "1";
            return false;
        }

        return true;
    }
}
