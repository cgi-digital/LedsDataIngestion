package uk.gov.homeoffice.dpp.filemonitoring.steps;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import uk.gov.homeoffice.dpp.filemonitoring.FileMetadata;
import uk.gov.homeoffice.dpp.DotFinishedHandler;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.util.HashMap;
import java.util.Map;

/**
 * This step renames the file in {@link FileMetadata#originalFilePath}
 * to have .finished on the end of it
 * @author C.Barnes, M.Koskinas
 */
@Component
public class RenameToFinishedStep implements Step {

    private static final Logger logger = LoggerFactory.getLogger(RenameToFinishedStep.class);

    private static final String FILE_APPENDER = ".finished";

    private boolean enabled;
    private String errorCode = null;
    private FileMetadata curFile;

    /**
     * Constructor for RenameToFinishedStep assigns the properties
     * attributed to this step in the yml properties file
     * @param stepSpecification information about the step from the properties file
     */
    public  RenameToFinishedStep(StepSpecification stepSpecification)
    {
        this.enabled = stepSpecification.getStatus();
    }

    /**
     * This method executes the RenameToFinished Step on the {@link FileMetadata#originalFilePath} file
     * @param fileMetadata {@link FileMetadata} object containing the {@link FileMetadata#originalFilePath} value
     *                                 that will be renamed
     * @return A {@link StepResult} object detailing whether it was successful, if there is an error code
     * and the current working metadata object
     */
    @Override
    public StepResult runStep(FileMetadata fileMetadata) {

        Map<String,String> errors = new HashMap<>();

        boolean success = DotFinishedHandler.rename(fileMetadata);

        if(success)
        {
            return new StepResult(true,null,fileMetadata);
        }
        else
        {
            errors.put(errorCode,"File doesn't exist");
            return new StepResult(false,DotFinishedHandler.errorCode,fileMetadata);
        }
    }

    @Override
    public String getName() {
        return "rename_to_finished";
    }

    @Override
    public Map<String, String> properties() {
        return null;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }

    /**
     * Renames the file passed to it to have .finished appended to it
     * @param pathToFile path to file that is to be renamed to .finished
     * @return true if successful in renaming, false otherwise
     */
    private boolean renameFile(Path pathToFile)
    {
        Path newFileName = Paths.get(DotFinishedHandler.appendDotFinished(pathToFile.toString()));
        try {
            Files.move(pathToFile, newFileName);
            curFile.setCurrentPath(newFileName);
            FileTime curTime = FileTime.fromMillis(System.currentTimeMillis());
            Files.setLastModifiedTime(newFileName, curTime);
        }
        catch(IOException ioe)
        {
            logger.error("Error when renaming file from {} to {}", pathToFile.toString(), newFileName.toString(), ioe);
            errorCode = "1";
            return false;
        }

        return true;
    }

    /**
     * Checks whether the path exists
     * @param pathToFile the path to be checked
     * @return true if the path exists, false if it doesn't
     */
    private boolean validateFile(Path pathToFile)
    {
       return pathToFile.toFile().exists();
    }
}
