package uk.gov.homeoffice.dpp.fileingest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import uk.gov.homeoffice.dpp.configuration.FileIngestConfiguration;
import uk.gov.homeoffice.dpp.configuration.forces.ForceLandingLocation;
import uk.gov.homeoffice.dpp.configuration.priorities.PriorityProperties;
import uk.gov.homeoffice.dpp.filemonitoring.FTPManagerPipeline;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.attribute.FileTime;
import java.util.*;

/**
 * This class processes a given directory based on the priority
 * of the directory and that priority's properties. It will process
 * a defined number of files by sending them to the FTPPipeline to be sent through the
 * process.
 * Created by C.Barnes on 06/07/2017.
 */
public class DirProcessor {

    private static final Logger logger = LoggerFactory.getLogger(DirProcessor.class);

    @Autowired
    ApplicationContext appContext;

    private ForceLandingLocation forceDirToProc;
    private PriorityProperties dirPriority;
    private String forceID;

    public DirProcessor(ForceLandingLocation forceDir, PriorityProperties priorityProperties, String forceID) {

        this.forceDirToProc = forceDir;

        this.dirPriority = priorityProperties;

        this.forceID = forceID;

    }

    /**
     * Get all valid files (defined by various properties) from a directory and send them through the FTPPipeline
     * @return
     */
    public boolean processDirectory()
    {
        List<File> filesToProcess = new ArrayList<>();

        File dirToProcess = new File(forceDirToProc.getLocation());

        List<File> filesInDir = getAllFilesInDir(dirToProcess);

        filesInDir.sort(Comparator.comparing(File::lastModified));

        // if no files in directory
        if(filesInDir.isEmpty())
            return false;

        //Grabs the specified number of files per loop for this priority level
        for (int i = 0; i < dirPriority.getFilesPerLoop(); i++)
        {
            if(i == filesInDir.size())
                break;

            if(isFileOldEnough(filesInDir.get(i)))
            {
                filesToProcess.add(filesInDir.get(i));
            }
        }

        //If any files have reached their maximum age (defined by priority level) then they are added to the list
        for(int i = dirPriority.getFilesPerLoop(); i < filesInDir.size(); i++)
        {
           if(i == filesInDir.size())
               break;

           if(isFileTooOld(filesInDir.get(i))) {

                filesToProcess.add(filesInDir.get(i));
           }
           else {
               break;
           }
        }


        // Process each of the files one by one
        for(File fileToProcess : filesToProcess)
        {
            processFile(fileToProcess);
        }

        if(filesToProcess.isEmpty())
            return false;

        return true;
    }

    private boolean isFileTooOld(File file) {

        Calendar fileTime = Calendar.getInstance();
        fileTime.setTime(new Date(file.lastModified()));

        Calendar maxAllowedTime = Calendar.getInstance();
        maxAllowedTime.add(Calendar.HOUR, -(dirPriority.getMaxFileAge()));

        return fileTime.before(maxAllowedTime);
    }

    private void processFile(File file) {

        //TODO process the file
        logger.info("Processing file: {}", file.getAbsolutePath());
        FTPManagerPipeline ftpManagerPipeline = (FTPManagerPipeline) appContext.getBean("FTPManagerPipeline");
        ftpManagerPipeline.runSteps(file.getPath(), forceID, Integer.toString(forceDirToProc.getPriority()));
        logger.info("Finished processing file: {}", file.getAbsolutePath());

    }

    private boolean isFileOldEnough(File file) {
        Calendar fileTime = Calendar.getInstance();
        fileTime.setTime(new Date(file.lastModified()));
        //Date fileTime = new Date(file.lastModified());
        Calendar minAllowedTime = Calendar.getInstance();
        minAllowedTime.add(Calendar.MINUTE, -(FileIngestConfiguration.getMinFileAge()));

        return fileTime.before(minAllowedTime);

    }

    private List<File> getAllFilesInDir(File directory)
    {

        List<File> fileList = new ArrayList<>();

        if(!directory.exists() || !directory.isDirectory())
            return fileList;

        FilenameFilter excludingDotFin = (dir, name) -> !name.toLowerCase().contains(".finished");

        File[] filesInDirectory = directory.listFiles(excludingDotFin);

        if(filesInDirectory == null || filesInDirectory.length < 1)
            return fileList;

        for(File file : filesInDirectory)
        {
            if(file.isDirectory())
            {
                fileList.addAll(getAllFilesInDir(file));
            }
            else{
                fileList.add(file);
            }

        }

        return fileList;

    }

    private File[] sortByOldestFirst(File[] fileList) {

        Arrays.sort(fileList, (f1, f2) -> {
            try {
                FileTime f1Time = Files.getLastModifiedTime(f1.toPath());
                FileTime f2Time = Files.getLastModifiedTime(f2.toPath());
                return f1Time.compareTo(f2Time);
            } catch (IOException e) {
                logger.error("Error when sorting files by oldest first", e);
                return 0;
            }
        });

        return fileList;
    }

    public ForceLandingLocation getForceDirToProc() {
        return forceDirToProc;
    }

    public void setForceDirToProc(ForceLandingLocation forceDirToProc) {
        this.forceDirToProc = forceDirToProc;
    }

    public PriorityProperties getDirPriority() {
        return dirPriority;
    }

    public void setDirPriority(PriorityProperties dirPriority) {
        this.dirPriority = dirPriority;
    }

    public String getForceID() {
        return forceID;
    }

    public void setForceID(String forceID) {
        this.forceID = forceID;
    }
}
