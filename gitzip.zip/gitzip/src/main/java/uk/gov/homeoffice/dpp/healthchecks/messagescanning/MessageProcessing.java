//package uk.gov.homeoffice.dpp.healthchecks.messagescanning;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.ApplicationContext;
//import org.springframework.stereotype.Component;
//import uk.gov.homeoffice.dpp.healthchecks.HealthChecksPipeline;
//
//import java.io.*;
//import java.nio.file.Files;
//import java.nio.file.InvalidPathException;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.nio.file.attribute.FileTime;
//import java.util.Arrays;
//
//import static uk.gov.homeoffice.dpp.healthchecks.messagescanning.MessageProcessing.MessageTypes.*;
//
//
///**
// * This class deals with the processing of messages.
// * It reads them and reacts to their content, either starting
// * the pipeline to process a file or shutting down the program
// * Created by C.Barnes on 20/04/2017.
// */
//@Component
//public class MessageProcessing {
//
//    private static final Logger logger = LoggerFactory.getLogger(MessageProcessing.class);
//
//    @Autowired
//    ApplicationContext context;
//
//    public static final String ERROR_FOLDER = "ErroredMessages";
//    public static final String FILE_TO_PROCESS_PROP = "FileToProcess:";
//
//    public enum MessageTypes{
//        PROCESS, EXIT, NONE
//    }
//
//    public MessageProcessing()
//    {
//
//    }
//
//    /**
//     * Reads a list of messages and acts appropriately.
//     * Either starting the pipeline for the {@link Message#fileToProcess}
//     * file or returning a shut down command.
//     * @param fileList List of message files relevant to this program
//     * @return true if program should continue to scan, false if an exit command was found
//     * and it should stop
//     */
//    public boolean processMessageList(File[] fileList)
//    {
//        boolean noExitMessage = true;
//
//        File[] sortedFileList = sortByOldestFirst(fileList);
//
//        for (File message: sortedFileList) {
//
//            if(!message.isFile())
//                continue;
//
//            switch (getMessageType(message))
//            {
//
//                case PROCESS:
//                    processMessage(message);
//                    break;
//                case EXIT:
//                    noExitMessage = false;
//                    break;
//                case NONE:
//                default:
//                    moveMessageToErrorFolder(message);
//                    break;
//            }
//
//            cleanUp(message);
//
//        }
//
//        return noExitMessage;
//    }
//
//    /**
//     * When a PROCESS message type is discovered it is
//     * sent to this method to process it's contents
//     * @param message The message of type PROCESS to be read
//     */
//    private void processMessage(File message) {
//
//        Message messageContents = readMessageContents(message);
//        if(!messageContents.isValid())
//        {
//            moveMessageToErrorFolder(message);
//        }
//        else{
//            startPipeline(messageContents);
//        }
//    }
//
//    /**
//     * Sorts all the message files by the oldest first
//     * @param fileList List of files to be sorted
//     * @return Array of sorted files
//     */
//    private File[] sortByOldestFirst(File[] fileList) {
//
//        Arrays.sort(fileList, (f1, f2) -> {
//            try {
//                FileTime f1Time = Files.getLastModifiedTime(f1.toPath());
//                FileTime f2Time = Files.getLastModifiedTime(f2.toPath());
//                return f1Time.compareTo(f2Time);
//            } catch (IOException e) {
//                logger.error("Error when sorting files by oldest first", e);
//                return 0;
//            }
//        });
//
//        return fileList;
//    }
//
//    /**
//     * Cleanup after reading a message. Deletes that
//     * message from the scanned directory if it exists
//     * @param message
//     */
//    private void cleanUp(File message) {
//
//        if(message.exists() && !message.getName().toUpperCase().startsWith(MessageScanning.ALL_EXIT_MESSAGE))
//        {
//            if(!message.delete())
//                logger.error("Unable to delete message {}", message.toPath());
//        }
//
//    }
//
//    /**
//     * Moves a message with invalid contents to an error
//     * folder for further inspection.
//     * @param message Message file to be moved to the error folder
//     */
//    private void moveMessageToErrorFolder(File message) {
//
//        logger.info("Moving message {} to errored message directory", message.getPath());
//
//        Path errorDirectory = Paths.get(message.toPath().getParent() + "/" + ERROR_FOLDER);
//
//        if(createMessageErrorFolder(errorDirectory))
//        {
//            try {
//                Files.move(message.toPath(), Paths.get(errorDirectory + "/" + message.getName()));
//            } catch (IOException e) {
//                logger.error("Could not move the invalid message {} to the errored messages directory {}",
//                        message.getPath(), errorDirectory, e);
//            }
//        }
//
//
//    }
//
//    /**
//     * This class creates the Directory for errored/invalid messages
//     * to be stored. If the directory already exists the method immediately
//     * returns true
//     * @param errorDirectory the path to errored messages directory
//     * @return true if the directory already exists or is created, false otherwise
//     */
//    public boolean createMessageErrorFolder(Path errorDirectory)
//    {
//
//
//        if(errorDirectory.toFile().exists())
//            return true;
//
//        try {
//            logger.info("Creating error directory {}", errorDirectory);
//            Files.createDirectory(errorDirectory);
//        } catch (IOException e) {
//            logger.error("Could not create the errored message directory {}", errorDirectory, e);
//            return false;
//        }
//
//        return true;
//
//    }
//
//    /**
//     * Reads through the contents of a message file and creates
//     * a Message object from it. It also ensures the contents are valid
//     * @param message message file to be read
//     * @return Message object stating whether it is valid, and if so it's contents
//     */
//    private Message readMessageContents(File message) {
//        boolean validMsg = true;
//
//        Path fileToProcess = null;
//        Message messageContents = new Message();
//
//        try(BufferedReader reader = new BufferedReader(new FileReader(message)))
//        {
//
//            String firstLine = reader.readLine().trim();
//            if(firstLine.contains(FILE_TO_PROCESS_PROP)) {
//
//                fileToProcess = Paths.get(firstLine.replace(FILE_TO_PROCESS_PROP, "").trim());
//                if (!fileToProcess.toFile().exists()) {
//                    logger.error("Path {} to be processed in message {} does not exist", fileToProcess, message);
//                    validMsg = false;
//                }
//
//            }
//            else{
//                validMsg = false;
//                logger.error("Expecting first line of message to be in format {}<pathToFile>", FILE_TO_PROCESS_PROP);
//            }
//
//
//        } catch (FileNotFoundException e) {
//            logger.error("Could not find the message file {}", message.getPath(), e);
//            validMsg = false;
//        } catch (IOException e) {
//            logger.error("Error when reading message file {}", message.getPath(), e);
//            validMsg = false;
//        } catch (InvalidPathException e) {
//            logger.error("Path for file to be processed {} is not valid", fileToProcess, e);
//            validMsg = false;
//        } catch (NullPointerException e) {
//            logger.error("There were no lines in the message file {}", message.getPath(), e);
//            validMsg = false;
//        }
//
//
//        messageContents.setFileToProcess(fileToProcess);
//        messageContents.setValid(validMsg);
//
//        return messageContents;
//    }
//
//    /**
//     * Starts the HealthChecks pipeline for the file contained in the message
//     * @param message message file that contains the file path of the file to be processed
//     */
//    private void startPipeline(Message message) {
//
//       HealthChecksPipeline pipeline = (HealthChecksPipeline) context.getBean("HealthChecksPipeline");
//       pipeline.runHealthChecks(message.getFileToProcess().toString());
//
//    }
//
//    /**
//     * Gets the type of message from the message name
//     * and returns the type.
//     * @param message message to discover the type for
//     * @return the message type
//     */
//    private MessageTypes getMessageType(File message) {
//
//        String[] splitFilename = message.getName().split("\\.");
//        String processType = splitFilename[1];
//
//        if("PROCESS".equalsIgnoreCase(processType))
//        {
//            return PROCESS;
//        }
//        else if("EXIT".equalsIgnoreCase(processType))
//        {
//            return EXIT;
//        }
//
//        logger.error("Message type could not be understood/accepted. ({})", processType);
//
//        return NONE;
//
//    }
//
//}
