package uk.gov.homeoffice.dpp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.ComponentScan;
import uk.gov.homeoffice.dpp.configuration.HealthChecksConfiguration;
import uk.gov.homeoffice.dpp.fileingest.DirPoller;
import uk.gov.homeoffice.dpp.healthchecks.ledsqueue.LEDSQueue;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.util.Properties;

@SpringBootApplication
@ComponentScan
public class DPPApplication
{
    private static final Logger logger = LoggerFactory.getLogger(DPPApplication.class);

    public static void main(String[] args)
    {
        String processID = getComputerName();

        System.setProperty("ProcessIDName",processID);

        SpringApplicationBuilder applicationBuilder = new SpringApplicationBuilder(DPPApplication.class).web(false);
        applicationBuilder.run(args);

        HealthChecksConfiguration.setProcessID(processID);

        final Properties properties = new Properties();
        try
        {
            properties.load(DPPApplication.class.getClassLoader().getResourceAsStream("project.properties"));
        }
        catch (IOException e)
        {
            logger.error("Error populating project version properties", e);
            e.printStackTrace();
        }

        logger.info("\n\n*** PROCESS ID: '"+processID+"' ***\n" +
                "*** APPLICATION NAME: '"+properties.getProperty("project.name")+"' ***\n" +
                "*** BUILD VERSION: '"+properties.getProperty("project.version")+"' ***\n\n");

        LEDSQueue ledsQueue = (LEDSQueue)applicationBuilder.context().getBean("LEDSQueue");

        if(ledsQueue.getConnection() != null)
        {
            DirPoller dirPoller = (DirPoller) applicationBuilder.context().getBean("DirPoller");

            try
            {
                dirPoller.startPolling();
            }
            catch (InterruptedException ie)
            {
                logger.error("Program '{}' interrupted. Now exiting.", processID, ie);
            }
            finally
            {
                ledsQueue.close();
            }
        }
        else
        {
            logger.error("Could not instantiate connection with the LEDS Output queue");
        }
    }

    private static String getComputerName()
    {
        return ManagementFactory.getRuntimeMXBean().getName();
    }

}
