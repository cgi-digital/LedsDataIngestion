package uk.gov.homeoffice.dpp.filemonitoring;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.nio.file.Files;

/**
 * Created by M.Koskinas on 14/03/2017.
 */

public class FileDetector {

    private static final Logger logger = LoggerFactory.getLogger(FileDetector.class);

    private boolean enabled;
    private String directory;
    private Long frequency;

    public FileDetector()
    {}

    public FileDetector(boolean enabled, String directory, Long frequency)
    {
        this.enabled = enabled;
        this.directory = directory;
        this.frequency = frequency;
    }


    public void monitor()
    {

    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getDirectory() {
        return directory;
    }

    public void setDirectory(String directory) {
        this.directory = directory;
    }

    public Long getFrequency() {
        return frequency;
    }

    public void setFrequency(Long frequency) {
        this.frequency = frequency;
    }
}
