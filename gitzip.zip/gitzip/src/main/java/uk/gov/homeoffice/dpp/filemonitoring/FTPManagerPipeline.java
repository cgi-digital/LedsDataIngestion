package uk.gov.homeoffice.dpp.filemonitoring;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.homeoffice.dpp.DotFinishedHandler;
import uk.gov.homeoffice.dpp.filemonitoring.steps.*;
import uk.gov.homeoffice.dpp.filemonitoring.utilities.FileIngestor;
import uk.gov.homeoffice.dpp.filemonitoring.utilities.FileandDirHandler;
import uk.gov.homeoffice.dpp.healthchecks.HealthChecksPipeline;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author M.Koskinas, C.Barnes
 */
public class FTPManagerPipeline {

    private static final Logger logger = LoggerFactory.getLogger(FTPManagerPipeline.class);

    private String original_source;
    private String output;

    private List<Step> steps;

    @Autowired
    HealthChecksPipeline healthChecksPipeline;

    public FTPManagerPipeline(String original_source, String output, Map<String,StepSpecification> checkOrder)
    {
        this.original_source = original_source;
        this.output = output;

        initializePipeline(checkOrder);
    }

    public void runSteps(String filepath, String forceID, String priorityLevel) {

        if(!FileandDirHandler.createTemporaryFolderStructure())
        {
            logger.error("Failed to create the temporary folder structure. Exiting with error for file {}", filepath);
            return;
        }

        FileMetadata fileMetadata = new FileMetadata(Paths.get(filepath), forceID, priorityLevel);

        FileIngestor.populateInitialMetadata(fileMetadata);
        if(!FileIngestor.prepareFileForLoading(fileMetadata))
        {
            logger.error("Could not prepare file {} for virus scanning. Exiting.", filepath);
            return;
        }

        executePipelineSteps(fileMetadata, 0);

    }

    private void initializePipeline(Map<String,StepSpecification> stepOrder)
    {
        this.steps = new ArrayList<>();
        for(Map.Entry<String, StepSpecification> step : stepOrder.entrySet())
        {
            steps.add(StepFactory.createStep(step.getKey(),step.getValue()));
        }
    }

    private void runSteps(String filepath, String forceID, String priorityLevel, int startStep)
    {
        if(!FileandDirHandler.createTemporaryFolderStructure()) {
            logger.error("Failed to create the temporary folder structure. Exiting with error for file {}", filepath);
            return;
        }

        FileMetadata fileMetadata = new FileMetadata(Paths.get(filepath), forceID, priorityLevel);

        FileIngestor.populateInitialMetadata(fileMetadata);
        if(!FileIngestor.prepareFileForLoading(fileMetadata))
        {
            logger.error("Could not prepare file {} for virus scanning. Exiting.", filepath);
            return;
        }

        executePipelineSteps(fileMetadata, startStep);

    }

    private void executePipelineSteps(FileMetadata file, int startStep)
    {
        FileMetadata fileMetadata = file;

        List<FileMetadata> currentFiles = new ArrayList<>();
        int currentStep = startStep;

        boolean success = true;
        boolean forked = false;
        for(int st = startStep ; st < steps.size() && success && !forked ; st++)
        {
            String filepath = fileMetadata.getCurrentPath().toString();
            Step step = steps.get(st);

            if(step.isEnabled())
            {
                //Skip untarring step if the file is not a .tar
                if("untarring".equals(step.getName()) && !filepath.contains(".tar"))
                    continue;

                logger.info("{} step started", step.getName());

                StepResult result = step.runStep(fileMetadata);

                if(result.getCurrentFiles().size() > 1)
                {
                    forked = true;
                    currentFiles = result.getCurrentFiles();
                    currentStep = st;
                }
                else
                {
                    fileMetadata.setCurrentPath(result.getCurrentFiles().get(0).getCurrentPath());
                }

                if(!result.isSuccess())
                {
                    success = false;
                }

                logger.info("{} step finished", step.getName());
            }
        }
        //TODO if success == false because of vs or other reason, then how do we inform LEDS? Do we pass the metadata to HC?

        if(forked && success)
        {
            //tar file passed VS, continue processing
            for (FileMetadata nextFile: currentFiles)
            {
                executePipelineSteps(nextFile, currentStep);
            }
        }
        else if(success)
        {
            healthChecksPipeline.runHealthChecks(fileMetadata);
            DotFinishedHandler.rename(fileMetadata);
        }
        else if(fileMetadata.getState().equals(FileMetadata.STATE_VIRUS))
        {
            healthChecksPipeline.runHealthChecks(fileMetadata);
            DotFinishedHandler.rename(fileMetadata);
        }

        cleanupTempFolder();

    }

    private void cleanupTempFolder() {

        for(Step step : steps)
        {
            if("untarring".equals(step.getName())) {
                ((UnTarStep) step).unTarCleanup();
            }
        }
    }




    public String getOriginal_source() {
        return this.original_source;
    }
    public String getOutput(){
        return this.output;
    }

    public List<Step> getSteps()
    {
        return this.steps;
    }
}
