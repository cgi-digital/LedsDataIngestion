package uk.gov.homeoffice.dpp.configuration.forces;

/**
 * Created by C.Barnes on 06/07/2017.
 */
public class ForceLandingLocation {


    private int priority;

    private String location;

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ForceLandingLocation that = (ForceLandingLocation) o;

        if (priority != that.priority) return false;
        return location != null ? location.equals(that.location) : that.location == null;
    }

    @Override
    public int hashCode() {
        int result = priority;
        result = 31 * result + (location != null ? location.hashCode() : 0);
        return result;
    }
}
