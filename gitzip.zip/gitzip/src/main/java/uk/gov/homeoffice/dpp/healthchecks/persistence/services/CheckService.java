package uk.gov.homeoffice.dpp.healthchecks.persistence.services;

import uk.gov.homeoffice.dpp.healthchecks.persistence.entities.DPPCheck;

import java.util.List;

/**
 * Created by C.Barnes on 01/03/2017.
 */
public interface CheckService {

    public List<DPPCheck> getAll();

    DPPCheck getCheckByID(Long id);

    List<DPPCheck> getChecksByActiveType(boolean isActive);

    List<DPPCheck> getChecksByName(String name);

    DPPCheck createCheck(Long id, boolean isActive, String checkName, String checkDesc);



}
